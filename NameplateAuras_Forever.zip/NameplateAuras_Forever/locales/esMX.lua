local L = LibStub("AceLocale-3.0"):NewLocale("NameplateAuras_Forever", "esMX");
L = L or {} -- luacheck: ignore L
--@non-debug@
--[[Translation missing --]]
L["< 1min"] = "< 1min"
--[[Translation missing --]]
L["< 5sec"] = "< 5sec"
--[[Translation missing --]]
L["> 1min"] = "> 1min"
--[[Translation missing --]]
L["Add spell"] = "Add spell"
--[[Translation missing --]]
L["Always show auras cast by myself"] = "Always show auras cast by myself"
--[[Translation missing --]]
L["Anchor point"] = "Anchor point"
--[[Translation missing --]]
L["Anchor to icon"] = "Anchor to icon"
--[[Translation missing --]]
L["anchor-point:bottom"] = "Bottom"
--[[Translation missing --]]
L["anchor-point:bottomleft"] = "Bottom left"
--[[Translation missing --]]
L["anchor-point:bottomright"] = "Bottom right"
--[[Translation missing --]]
L["anchor-point:center"] = "Center"
--[[Translation missing --]]
L["anchor-point:left"] = "Left"
--[[Translation missing --]]
L["anchor-point:right"] = "Right"
--[[Translation missing --]]
L["anchor-point:top"] = "Top"
--[[Translation missing --]]
L["anchor-point:topleft"] = "Top left"
--[[Translation missing --]]
L["anchor-point:topright"] = "Top right"
--[[Translation missing --]]
L["Any"] = "Any"
--[[Translation missing --]]
L["Aura type"] = "Aura type"
--[[Translation missing --]]
L["Border thickness"] = "Border thickness"
--[[Translation missing --]]
L["Buff"] = "Buff"
--[[Translation missing --]]
L["Check spell ID"] = [=[Check spell IDs
(comma-separated)]=]
--[[Translation missing --]]
L["Click to select spell"] = "Click to select spell"
--[[Translation missing --]]
L["Curse"] = "Curse"
--[[Translation missing --]]
L["Debuff"] = "Debuff"
--[[Translation missing --]]
L["Delete all spells"] = "Delete all auras"
--[[Translation missing --]]
L["Delete spell"] = "Delete aura"
--[[Translation missing --]]
L["Disabled"] = "Disabled"
--[[Translation missing --]]
L["Disease"] = "Disease"
--[[Translation missing --]]
L["Display auras on player's nameplate"] = "Display auras on player's nameplate"
--[[Translation missing --]]
L["Font"] = "Font"
--[[Translation missing --]]
L["Font scale"] = "Font scale"
--[[Translation missing --]]
L["Font size"] = "Font size"
--[[Translation missing --]]
L["General"] = "General"
--[[Translation missing --]]
L["Icon borders"] = "Icon borders"
--[[Translation missing --]]
L["Icon X-coord offset"] = "Icon X offset"
--[[Translation missing --]]
L["Icon Y-coord offset"] = "Icon Y offset"
--[[Translation missing --]]
L["icon-grow-direction:down"] = "Down"
--[[Translation missing --]]
L["icon-grow-direction:left"] = "Left"
--[[Translation missing --]]
L["icon-grow-direction:right"] = "Right"
--[[Translation missing --]]
L["icon-grow-direction:up"] = "Up"
--[[Translation missing --]]
L["icon-sort-mode:by-aura-type+by-expire-time"] = "By aura type + by expiration time"
--[[Translation missing --]]
L["icon-sort-mode:by-expire-time"] = "By expiration time"
--[[Translation missing --]]
L["icon-sort-mode:by-icon-size"] = "By icon size"
--[[Translation missing --]]
L["icon-sort-mode:custom"] = "Custom"
--[[Translation missing --]]
L["icon-sort-mode:none"] = "Without sorting"
--[[Translation missing --]]
L["instance-type:arena"] = "Arenas"
--[[Translation missing --]]
L["instance-type:none"] = "Open World"
--[[Translation missing --]]
L["instance-type:party"] = "5ppl dungeons"
--[[Translation missing --]]
L["instance-type:pvp"] = "Battlegrounds"
--[[Translation missing --]]
L["instance-type:pvp_bg_40ppl"] = "Epic Battlegrounds"
--[[Translation missing --]]
L["instance-type:raid"] = "Raid dungeons"
--[[Translation missing --]]
L["instance-type:scenario"] = "Scenarios"
--[[Translation missing --]]
L["instance-type:unknown"] = "Unknown dungeons (some quest scenarios)"
--[[Translation missing --]]
L["Magic"] = "Magic"
--[[Translation missing --]]
L["Options are not available in combat!"] = "Options are not available in combat!"
--[[Translation missing --]]
L["options:alpha:alpha"] = "Alpha of the icons (except the nameplate of your target)"
--[[Translation missing --]]
L["options:alpha:alpha-target"] = "Alpha of the icons on the nameplate of your target"
--[[Translation missing --]]
L["options:alpha:use-target-alpha-if-not-target-selected"] = "Display auras with target's alpha if no target selected"
--[[Translation missing --]]
L["options:animation-type:ICON_ANIMATION_TYPE_ALPHA"] = "Alpha"
--[[Translation missing --]]
L["options:apps:dispellable-spells"] = "Show dispellable/stealable auras on enemy nameplates"
--[[Translation missing --]]
L["options:apps:dispellable-spells:black-list-button"] = "Open blacklist"
--[[Translation missing --]]
L["options:apps:dispellable-spells:instance-types"] = "Set the instance types in which dispelable auras will be displayed"
--[[Translation missing --]]
L["options:apps:dispellable-spells:tooltip"] = "Show dispellable/stealable auras on nameplates of enemies. These auras have a dim glow and default size"
--[[Translation missing --]]
L["options:apps:dr"] = "Enable display of diminishing return (beta)"
--[[Translation missing --]]
L["options:apps:dr:pve"] = "PvE (stun only)"
--[[Translation missing --]]
L["options:apps:dr:pvp"] = "PvP"
--[[Translation missing --]]
L["options:apps:explosive-orbs:tooltip"] = [=[Show special aura above Fel Explosive's nameplates (M+ Explosive Affix)
This aura have a bright glow and default size]=]
--[[Translation missing --]]
L["options:apps:spiteful"] = "Highlight Spiteful Shade (Spiteful M+ affix)"
--[[Translation missing --]]
L["options:apps:spiteful:sound"] = "Sound"
--[[Translation missing --]]
L["options:auras:enabled-state:tooltip"] = [=[%s: aura will not be shown

%s: aura will be shown if you've cast it

%s: show all auras]=]
--[[Translation missing --]]
L["options:auras:enabled-state-all"] = "Enabled, show all auras"
--[[Translation missing --]]
L["options:auras:enabled-state-mineonly"] = "Enabled, show only my auras"
--[[Translation missing --]]
L["options:auras:show-on-npcs-1"] = "Show on NPCs"
--[[Translation missing --]]
L["options:auras:show-on-pets"] = "Show on pets"
--[[Translation missing --]]
L["options:auras:show-on-players-1"] = "Show on players"
--[[Translation missing --]]
L["options:borders:BORDER_TYPE_BUILTIN"] = "Built-in"
--[[Translation missing --]]
L["options:borders:BORDER_TYPE_CUSTOM"] = "Custom"
--[[Translation missing --]]
L["options:borders:border-file-path"] = "Border texture file path (starts with 'Interface\\')"
--[[Translation missing --]]
L["options:borders:border-type"] = "Border type"
--[[Translation missing --]]
L["options:category:alpha"] = "Alpha"
--[[Translation missing --]]
L["options:category:apps"] = "Apps"
--[[Translation missing --]]
L["options:category:dispel"] = "Purge/steal"
--[[Translation missing --]]
L["options:category:icon-groups"] = "Icon groups"
--[[Translation missing --]]
L["options:category:interrupts"] = "Interrupts"
--[[Translation missing --]]
L["options:category:size-and-position"] = "Style & position"
--[[Translation missing --]]
L["options:general:always-show-my-auras:tooltip"] = "This is top priority filter. If you enable this feature, your auras will be shown regardless of other filters"
--[[Translation missing --]]
L["options:general:always-show-my-auras-blacklist:button"] = "-> Blacklist"
--[[Translation missing --]]
L["options:general:always-show-my-auras-blacklist:button:tooltip"] = "Pay attention! If spell is added to `Spells` list AND this blacklist, it WILL be shown on nameplates"
--[[Translation missing --]]
L["options:general:current-icon-group"] = "Current icon group"
--[[Translation missing --]]
L["options:general:export-profile"] = "Export profile"
--[[Translation missing --]]
L["options:general:friendly-units-auras-instance-types"] = [=[Set the visibility of auras on allied HP bars
in different location types]=]
--[[Translation missing --]]
L["options:general:hide-blizz-frames"] = "Hide Blizzard's aura frames (except player)"
--[[Translation missing --]]
L["options:general:hide-player-blizz-frame"] = "Hide Blizzard's aura frames on player"
--[[Translation missing --]]
L["options:general:icon-grow-direction"] = "Icon growing direction"
--[[Translation missing --]]
L["options:general:import-profile"] = "Import profile"
--[[Translation missing --]]
L["options:general:instance-types"] = [=[Set the visibility of auras on enemy HP bars
in different location types]=]
--[[Translation missing --]]
L["options:general:masque-experimental"] = "Enable Masque support (experimental)"
--[[Translation missing --]]
L["options:general:npc-blacklist"] = "NPC blacklist"
--[[Translation missing --]]
L["options:general:npc-blacklist-add-button"] = "Add NPC"
--[[Translation missing --]]
L["options:general:npc-blacklist-editbox-add"] = "Please enter NPC name here"
--[[Translation missing --]]
L["options:general:show-aura-tooltip"] = "Show aura name when mouse is over auras icon"
--[[Translation missing --]]
L["options:general:show-cooldown-animation"] = "Show cooldown animation"
--[[Translation missing --]]
L["options:general:show-cooldown-text"] = "Show aura's remaining time"
--[[Translation missing --]]
L["options:general:show-on-ally-target-even-in-disabled-area-types"] = "Show auras on allied target's nameplate even in disabled types of zones"
--[[Translation missing --]]
L["options:general:show-on-enemy-target-even-in-disabled-area-types"] = "Show auras on enemy target's nameplate even in disabled types of zones"
--[[Translation missing --]]
L["options:general:show-on-target-even-in-disabled-area-types"] = "Show auras on target's nameplate even in disabled types of zones"
--[[Translation missing --]]
L["options:general:show-on-target-only"] = "Show auras on target's nameplate only"
--[[Translation missing --]]
L["options:general:show-stacks"] = "Show aura's stacks"
--[[Translation missing --]]
L["options:general:test-mode"] = "Test mode"
--[[Translation missing --]]
L["options:general:use-default-tooltip"] = "Show default Blizzard's aura tooltip"
--[[Translation missing --]]
L["options:glow-type"] = "Glow type"
--[[Translation missing --]]
L["options:glow-type:GLOW_TYPE_ACTIONBUTTON"] = "Action button"
--[[Translation missing --]]
L["options:glow-type:GLOW_TYPE_ACTIONBUTTON_DIM"] = "Action button (dim)"
--[[Translation missing --]]
L["options:glow-type:GLOW_TYPE_AUTOUSE"] = "Auto-use button"
--[[Translation missing --]]
L["options:glow-type:GLOW_TYPE_NONE"] = "None"
--[[Translation missing --]]
L["options:glow-type:GLOW_TYPE_PIXEL"] = "Pixel"
--[[Translation missing --]]
L["options:icon-groups:description"] = [=[
An icon group is a set of icons with independent settings. For example, you can create a separate icon group for debuffs, a separate icon group for interrupts, and a separate icon group for important boss buffs. Then you can place these icon groups around the nameplate independently. FYI addons can't distinguish buffs and debuffs, so populating groups with spells is, unfortunately, your responsibility. :)
The drop-down menu in the upper left corner of this window displays the icon group that you're currently editing.
Pay attention: spells are shared between icon groups, but you can create multiple spells with the same name but with different options, and then set links to different icon groups.]=]
--[[Translation missing --]]
L["options:icon-groups:dropdown-list"] = "Icon groups"
--[[Translation missing --]]
L["options:icon-groups:editbox-add-text"] = "Enter name and hit Enter key to add new icon group"
--[[Translation missing --]]
L["options:icon-groups:remove"] = "Delete"
--[[Translation missing --]]
L["options:interrupts:enable-interrupts"] = "Enable interrupt tracking"
--[[Translation missing --]]
L["options:interrupts:enable-only-during-pvp-battles"] = "Enable during PvP battles only"
--[[Translation missing --]]
L["options:interrupts:use-shared-icon-texture"] = "Use the same texture for all interrupt spells"
--[[Translation missing --]]
L["options:size-and-position:anchor-frame"] = "Anchor frame"
--[[Translation missing --]]
L["options:size-and-position:anchor-frame:healthbar"] = "Healthbar"
--[[Translation missing --]]
L["options:size-and-position:anchor-frame:nameplate"] = "The whole nameplate frame"
--[[Translation missing --]]
L["options:size-and-position:anchor-frame:tooltip"] = "Icons group will be placed relative to this frame"
--[[Translation missing --]]
L["options:size-and-position:anchor-point-of-frame"] = "Anchor point of icons group"
--[[Translation missing --]]
L["options:size-and-position:anchor-point-of-frame:tooltip"] = "'Group of icons' is collection of icons per nameplate"
--[[Translation missing --]]
L["options:size-and-position:anchor-point-to-nameplate"] = "Anchor point"
--[[Translation missing --]]
L["options:size-and-position:attach-to-addon-frame"] = "Attach to [%s]"
--[[Translation missing --]]
L["options:size-and-position:attach-to-addon-frame:tooltip"] = "Attach to third-party nameplate addon's nameplates instead of standard nameplate frames"
--[[Translation missing --]]
L["options:size-and-position:custom-sorting:tooltip"] = [=[Rules:
  - code must be an unnamed function with 2 arguments. These arguments are tables, representing auras to compare
  - this function must return true if the first aura should be placed before the second aura, and false otherwise
  - sorting is done quite often, so don't make sorting function too heavy
  - don't modify content of aura's table unless you REALLY know what you are doing
  - double-check any code you got from strangers

Aura's table content:
  - aura.duration - contains duration of aura in seconds. If aura is permanent, value of this field is 0. (type: number)
  - aura.expires - time when aura will finish. You can compare it with GetTime(). If aura is permanent, value of this field is 0. (type: number)
  - aura.stacks - number of stacks (type: number)
  - aura.spellID - ID of aura (type: number)
  - aura.spellName - name of aura (type: string)

Built-in sorting functions (result is a boolean value):
  - local result = sort_time(aura1, aura2) - sort by aura's remaining time
  - local result = sort_size(aura1, aura2) - sort by icon's size
]=]
--[[Translation missing --]]
L["options:size-and-position:icon-align"] = "Alignment of icons"
--[[Translation missing --]]
L["options:size-and-position:icon-align:bottom-left"] = "Horizontal: bottom / Vertical: left"
--[[Translation missing --]]
L["options:size-and-position:icon-align:center"] = "Center"
--[[Translation missing --]]
L["options:size-and-position:icon-align:top-right"] = "Horizontal: top / Vertical: right"
--[[Translation missing --]]
L["options:size-and-position:icon-height"] = "Default icon height"
--[[Translation missing --]]
L["options:size-and-position:icon-width"] = "Default icon width"
--[[Translation missing --]]
L["options:size-and-position:icon-zoom"] = "Icon zoom"
--[[Translation missing --]]
L["options:size-and-position:keep-aspect-ratio"] = "Keep aspect ratio of textures"
--[[Translation missing --]]
L["options:size-and-position:keep-aspect-ratio:tooltip"] = "If this option is checked and icon width and height are not equal, then texture of spell will be cropped in that way to save original image proportions"
--[[Translation missing --]]
L["options:size-and-position:nameplate-is-parent"] = "Attach icons directly to nameplates"
--[[Translation missing --]]
L["options:size-and-position:nameplate-is-parent:tooltip"] = "The icons will be deeply attached to the nameplates. This means that certain parameters of the icons (such as size, transparency, and even visibility) will be influenced by the parameters of the nameplates themselves. The icons will be positioned exactly at the same frame level as the nameplates."
--[[Translation missing --]]
L["options:size-and-position:non-target-strata"] = "Frame strata on non-target"
--[[Translation missing --]]
L["options:size-and-position:scale-target"] = "Scale of the icons on the nameplate of your target"
--[[Translation missing --]]
L["options:size-and-position:target-strata"] = "Frame strata on target"
--[[Translation missing --]]
L["options:spells:add-import-new-spell"] = "Add/import aura"
--[[Translation missing --]]
L["options:spells:add-new-spell"] = "Spell name/link/id or import string..."
--[[Translation missing --]]
L["options:spells:animation-relative:tooltip"] = [=[This option changes the meaning of slider on the left.

If this option is checked, animation will start when aura's remaining duration is less than the selected percent of maximum duration of this aura. It is useful, for example, if you want to know when you can safely re-apply your DoT spell without losing it's duration.

If this option is unchecked, animation will start when aura's remaining duration is less than absolute value of slider (in seconds)]=]
--[[Translation missing --]]
L["options:spells:animation-type"] = "Animation type"
--[[Translation missing --]]
L["options:spells:appropriate-spell-ids"] = "Appropriate aura IDs:"
--[[Translation missing --]]
L["options:spells:batch-actions"] = "Batch actions"
--[[Translation missing --]]
L["options:spells:consolidate"] = "Consolidate aura instances"
--[[Translation missing --]]
L["options:spells:consolidate:tooltip"] = "Combine multiple instances of this aura into one aura"
--[[Translation missing --]]
L["options:spells:disable-all-spells"] = "Disable all spells"
--[[Translation missing --]]
L["options:spells:enable-all-spells"] = "Enable all spells"
--[[Translation missing --]]
L["options:spells:export-spell"] = "Export aura"
--[[Translation missing --]]
L["options:spells:filter-tooltip"] = [=[You can use filters:

#group:[group index]
#enabled
#disabled
#buff
#debuff]=]
--[[Translation missing --]]
L["options:spells:glow-relative"] = "Use relative time"
--[[Translation missing --]]
L["options:spells:glow-relative:tooltip"] = [=[This option changes the meaning of slider on the left.

If this option is checked, glow will appear when aura's remaining duration is less than the selected percent of maximum duration of this aura. It is useful, for example, if you want to know when you can safely re-apply your DoT spell without losing it's duration.

If this option is unchecked, glow will appear when aura's remaining duration is less than absolute value of slider (in seconds)]=]
--[[Translation missing --]]
L["options:spells:icon-animation"] = "Icon animation"
--[[Translation missing --]]
L["options:spells:icon-animation-always"] = "Show animation all the time"
--[[Translation missing --]]
L["options:spells:icon-animation-threshold"] = "Show animation if aura's remaining time is less than"
--[[Translation missing --]]
L["options:spells:icon-border:builtin"] = "Border: Built-in"
--[[Translation missing --]]
L["options:spells:icon-border:custom"] = "Border: Custom"
--[[Translation missing --]]
L["options:spells:icon-border:disabled"] = "Border: Disabled"
--[[Translation missing --]]
L["options:spells:icon-glow"] = "Show glow"
--[[Translation missing --]]
L["options:spells:icon-glow-always"] = "Show glow all the time"
--[[Translation missing --]]
L["options:spells:icon-glow-threshold"] = "Show glow if aura's remaining time is less than"
--[[Translation missing --]]
L["options:spells:icon-height"] = "Icon height"
--[[Translation missing --]]
L["options:spells:icon-width"] = "Icon width"
--[[Translation missing --]]
L["options:spells:override-size"] = "Override aura size"
--[[Translation missing --]]
L["options:spells:override-size:tooltip"] = "Set custom size for aura. Pay attention: this applies to all icon groups!"
--[[Translation missing --]]
L["options:spells:please-push-once-more"] = "Please push once more"
--[[Translation missing --]]
L["options:spells:set-all-spells-to-my-auras-only"] = "Set all spells to 'show only my auras'"
--[[Translation missing --]]
L["options:spells:spell-tooltip"] = [=[Spell tooltip
must contain text]=]
--[[Translation missing --]]
L["options:style-and-position:show-cooldown-swipe-edge"] = "Show cooldown swipe edge"
--[[Translation missing --]]
L["options:style-and-position:show-cooldown-swipe-edge:tooltip"] = "Show/hide bright line on cooldown animation's edge"
--[[Translation missing --]]
L["options:timer-text:min-duration-to-display-tenths-of-seconds"] = "Minimum duration to display tenths of seconds"
--[[Translation missing --]]
L["options:timer-text:relative-color"] = "Use gradient color"
--[[Translation missing --]]
L["options:timer-text:relative-color:tooltip"] = [=[Timer text's color will be calculated dynamically,
based on aura's duration and remaining time.]=]
--[[Translation missing --]]
L["options:timer-text:scale-font-size"] = "Scale font size according to icon size"
--[[Translation missing --]]
L["options:timer-text:text-color-note"] = [=[Text colour will change
depending on the time remaining:]=]
--[[Translation missing --]]
L["Other"] = "Other"
--[[Translation missing --]]
L["Please reload UI to apply changes"] = "Please reload UI to apply changes"
--[[Translation missing --]]
L["Poison"] = "Poison"
--[[Translation missing --]]
L["Profiles"] = "Profiles"
--[[Translation missing --]]
L["Reload UI"] = "Reload UI"
--[[Translation missing --]]
L["Show border around buff icons"] = "Show border around buff icons"
--[[Translation missing --]]
L["Show border around debuff icons"] = "Show border around debuff icons"
--[[Translation missing --]]
L["Show this aura on nameplates of allies"] = "Show this aura on nameplates of allies"
--[[Translation missing --]]
L["Show this aura on nameplates of enemies"] = "Show this aura on nameplates of enemies"
--[[Translation missing --]]
L["Sort mode:"] = "Sort mode:"
--[[Translation missing --]]
L["Space between icons"] = "Space between icons"
--[[Translation missing --]]
L["Spell seems to be nonexistent"] = "Spell seems to be nonexistent"
--[[Translation missing --]]
L["Spells"] = "Spells"
--[[Translation missing --]]
L["Stack text"] = "Stack text"
--[[Translation missing --]]
L["Text color"] = "Text color"
--[[Translation missing --]]
L["Timer text"] = "Timer text"
--[[Translation missing --]]
L["Value must be a number"] = "Value must be a number"
--[[Translation missing --]]
L["X offset"] = "X offset"
--[[Translation missing --]]
L["Y offset"] = "Y offset"

--@end-non-debug@
