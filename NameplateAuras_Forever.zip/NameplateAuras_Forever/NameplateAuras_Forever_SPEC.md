# NameplateAuras_Forever SPEC

## 0. 文档控制与使用约定

| 项目 | 基线 |
|---|---|
| SPEC 版本 | `1.0` |
| 建立日期 | `2026-11-08` |
| 对应插件版本 | `16001.1-forever` |
| 对应配置 schema | `DBVersion = 34`，迁移编号 `0..33` |
| 目标客户端 | WoW Forever / Camelot，`1.60.1.70862`，Interface `16001` |
| 文档性质 | 当前实现的逆向基线、后续变更的规格入口；不是新增功能授权或游戏内验收报告 |
| 本次变更范围 | 仅建立本 SPEC；不改变 Lua、TOC、XML、库、打包配置或原 TBC 项目 |
| 当前验证状态 | 项目回归 `91/91` 通过；真实客户端待测；通用 SDD 预检仍为 `INCONCLUSIVE`，原因见 §13 |

本文件是本项目的中文规格入口。后续开发先更新相应的需求、边界与验收，再修改实现和测试。不要以本文件的存在代替运行时证据。

### 0.1 四种陈述必须分开

- **当前实现**：从本次读取的代码、配置和实际命令输出得到的事实。
- **强制不变量**：所有后续迭代必须遵守的约束；用 `INV-*` 标识。
- **客户端限制 / 未验证**：官方策略、静态工具覆盖不到的行为，或当前实现的已知边界。
- **候选迭代**：需要另行确认、源码验证与验收的方向；不能解释成已经实现。

“已实现”不等于“已游戏内实测”；“测试通过”也不等于所有输入、法术和第三方库组合均已验证。

### 0.2 路径与证据约定

- `PKG`：本文件所在目录，即 `wow-plugins/NameplateAuras_Forever/`。
- `LEGACY`：同级 `wow-plugins/NameplateAuras/`，只读。
- `SRC`：同级 `wow-plugins/wow-ui-source/`。
- `API`：`SRC/Interface/AddOns/Blizzard_APIDocumentationGenerated/`。
- `BAC`：`SRC/Interface/AddOns/Blizzard_AuraContainer/`。
- 实现路径相对 `PKG`；`API/`、`BAC/` 按上述路径展开。行号是本次定位点，后续变化必须更新。
- `tests/runtime_contract.json` 是机器可检查的运行时约束子集，不是本 SPEC 的完整替代品。

证据优先级：目标分支本地 Blizzard 源码与生成 API 文档 → 插件最终 TOC/加载图/实现 → 实际测试输出与游戏内记录 → 第三方插件线索。Plater、旧 TBC 实现、网络文章或历史会话不能覆盖目标客户端限制。

若 SPEC、代码、JSON 契约或测试不一致，必须登记差异；不能通过放宽测试、默默扩大显示范围或把候选功能写成现状来消除差异。

### 0.3 阅读导航

- 需求与不可破坏约束：§1–3。
- 安全架构、筛选与显示规则：§4–6。
- 配置字段、存档与迁移：§7–8。
- 生命周期、性能、UI 和命令：§9–11。
- API 证据、自动化与游戏内验收：§12–14。
- 已知边界与后续迭代规约：§15–17。

---

## 1. 概述、范围与非目标

### 1.1 产品目标

在不依赖 Plater、不修改原 TBC 插件的前提下，让独立的 `NameplateAuras_Forever` 使用 Forever 官方安全光环容器，在姓名板附近展示用户配置的增益/减益、图标、层数、冷却动画和剩余时间。

保留原项目的设置组织、翻译、媒体与配置导入/导出编码链；对客户端不允许的能力明确显示限制，而不是绕过限制或用伪造结果模拟真实光环。

### 1.2 典型使用场景

1. 只安装本插件、没有 Plater，配置敌对 NPC 姓名板的指定减益。
2. 为玩家、宠物、NPC，友方/敌方及不同副本/战场分别设定显示范围。
3. 为同一姓名板建立多个图标组，使用不同位置、尺寸、字体与透明度。
4. 使用显式法术 ID 或同名全等级规则；元数据未就绪时保留规则并安全等待。
5. 在官方允许的范围内显示“我的光环”和可净化/偷取增益。
6. 显式导入旧 TBC 导出配置，完成迁移与命名空间隔离；失败不破坏当前配置。
7. 使用合成预览调整组级外观，再以真实客户端完成光环与战斗限制验收。

### 1.3 明确不做

- 不创建/替换姓名板本体，不改血条、仇恨、施法条或客户端姓名板 CVar。
- 不依赖、修改或运行时 hook Plater；不把 Plater 可用当成本插件已验证。
- 不使原 `NameplateAuras` 成为依赖，不自动读取或改写 `NameplateAurasAceDB`。
- 不由普通插件代码读取受限光环、恢复 GUID 追踪或接管安全容器内部 `UNIT_AURA`。
- 不实现旧版战斗日志打断计时、DR、Explosive、Spiteful、secret 层数累计、同法术合并、自定义 Lua 光环排序。
- 不保证敌方增益/友方减益的任意精确身份筛选，也不保证所有地图允许显示相同光环。
- 不声称当前默认法术集是经过 Forever 实测的完整职业/技能库。
- 不把模拟预览、Lua mock 或静态 UI 结构测试当成游戏内成功。

---

## 2. 运行时、包结构与依赖

### 2.1 当前运行时事实

| 事实 | 依据 / 结果 |
|---|---|
| Blizzard 源码分支 | `forever`，建立本 SPEC 时工作树干净 |
| Blizzard 源码提交 | `9dc84f0`，提交说明 `1.60.1 (70862)` |
| 源码版本真源 | `SRC/version.txt:1` = `1.60.1.70862` |
| Interface 推导 | `1 * 10000 + 60 * 100 + 1 = 16001` |
| 插件 TOC | `NameplateAuras_Forever.toc:1-17` |
| 插件版本 | `16001.1-forever` |
| 必需客户端模块 | `Blizzard_AuraContainer` |
| 可选外部插件依赖 | TOC 未声明；Plater、Masque 均不是运行必需项 |
| SavedVariables | `NameplateAurasForeverAceDB`，账号级；无 PerCharacter 声明 |
| 当前 schema | `src/database.lua:24-573,687`，34 条迁移 |
| 原 TBC 包声明 | `LEGACY/NameplateAuras.toc` 为 Interface `20505`、Version `20505.1-release`、SV `NameplateAurasAceDB`；只描述历史包，不定义 Forever 运行时 |

### 2.2 客户端门禁

`src/NameplateAuras.lua:7-17` 获取 `GetBuildInfo()` 第四个返回值，要求：

- `16001 <= interfaceVersion < 20000`；
- `C_XMLUtil.GetTemplateInfo("CustomAuraContainerTemplate")` 有结果。

失败时打印不支持客户端说明，将 `ShowGUI`、`SwitchTestMode` 替换为提示函数，然后核心早退。后续初始化、核心事件和容器不建立。

**边界**：这个范围是防误装门禁，不代表测试过范围内的全部客户端。当前证据仅覆盖 `forever / 1.60.1.70862 / 16001`。门禁位于最后加载的核心文件；前面的常量、库和 UI 定义仍执行，不能写成“错误客户端不会执行任何顶层代码”。必需模块缺失可能由加载器提前阻止加载，而不是触发这段提示。

### 2.3 加载图

TOC 直接加载顺序：

1. `src/consts.lua`：常量、标识、独立媒体路径。
2. `embeds.xml`：嵌入库及递归 XML/Lua 图。
3. `locales/localizations.xml`：项目 AceLocale 语言表。
4. `src/utils.lua`：工具、公开法术缓存与异步目录。
5. `src/spells.lua`：历史默认法术批次与保留的打断表。
6. `src/options-dialog.lua`：GUI、回调入口、导入/导出、LDB 对象。
7. `src/database.lua`：迁移、校验、归一化、默认规则导入。
8. `src/NameplateAuras.lua`：容器、生命周期、初始化与命令。

当前递归加载图为 **57 个 Lua 文件、0 个内联 XML Script**。这是快照数量，不是文件配额。新增文件必须纳入实际图和检查，不能仅检查直接 TOC 行。

### 2.4 嵌入库与隔离

`embeds.xml:4-17` 加载：`LibStub`、`CallbackHandler-1.0`、`LibSharedMedia-3.0`、`AceGUI-3.0`、`AceConfig-3.0`（含 Registry/Dialog/Cmd）、`AceDB-3.0`、`AceDBOptions-3.0`、`AceLocale-3.0`、`LibButtonGlow.lua`、私有 dropdown、`LibCustomGlow`、`LibDataBroker-1.1`、`LibDeflate`、`LibSerialize`。

- `LibRedDropdown-Forever-1.0` 注册 revision `24`；目录仍为 `libs/LibRedDropdown-1.0/`。
- 颜色纹理使用 `SetColorTexture(1,1,1,1)`，不调用旧 RGB `SetTexture` 重载。
- 私有库不注册/升级旧名 `LibRedDropdown-1.0`，不替换原 TBC 库。
- 标准 Ace/LibStub 等仍用标准注册名，参与版本仲裁；并非全部嵌入库完全私有。其他插件加载更高版本库的组合需兼容测试。
- 磁盘存在但不在加载图中的历史库不算运行依赖；不为整理规格顺手删除。
- 加载旧 glow 库不表示真实图标使用这些库；真实图标用客户端显示动画。

### 2.5 打包与发布对象

`pkgmeta.yaml` 使用 `package-as: NameplateAuras_Forever`、`enable-nolib-creation: no`，不再自动拉 `externals: latest` 替换本地私有修复；排除 `tests`、`_curseforge`，保留许可证声明。

本 SPEC 不进入 TOC，不在游戏内执行。本次不修改打包脚本。安装目录、TOC 名与媒体路径必须保持一致，不能多套一层目录。

### 2.6 从旧 TBC 到当前 Forever 的行为差异

| 能力 | 旧实现基线 | 当前 Forever |
|---|---|---|
| 光环更新 | 直接 `UNIT_AURA`、AuraUtil/C_UnitAuras 与按 GUID 缓存（`LEGACY/src/NameplateAuras.lua:41-42,120-121,346-349,1601-1606`）。 | 官方安全容器负责真实更新，普通核心仅姓名板/配置事件。 |
| 时间 | `IconSetCooldown` 在 Lua 中格式化剩余秒数（旧 core:612 起）。 | 客户端 NumericRuleFormatter/DurationTextBinding；不读取真实时间。 |
| 来源 | 旧逐光环来源/身份过滤。 | 官方 `PLAYER` 包含玩家相关宠物/载具；受授权边界约束，不完全等价。 |
| 图标排序/合并 | 旧 Lua 可处理真实 aura 与合并/自定义排序。 | 公开样式分组、客户端组内排序；合并/用户脚本不执行。 |
| 打断/DR | 旧 combat log 入口（旧 core:1727-1729）。 | 不可用，保留配置但不执行。 |
| 配置/库 | 旧 SV/slash/locale/media 与标准 dropdown 名。 | 业务命名空间独立、dropdown私有修复，标准 Ace 库仍仲裁。 |

旧代码仅用于说明迁移取舍，不授权 Forever 继续使用其 API；本次没有改动旧项目。

---

## 3. 强制不变量

| ID | 所有后续迭代必须保持 |
|---|---|
| `INV-001` | 原 TBC 项目只读；不改代码、TOC、媒体、库、存档或文档。 |
| `INV-002` | Forever 项目、SV、AceLocale、slash、LDB、自有命名帧隔离；不自动覆盖旧配置。 |
| `INV-003` | Plater 仅作线索，缺席也可加载；第三方集成需新规格与证据。 |
| `INV-004` | 普通核心不得注册 UNIT_AURA/COMBAT_LOG_EVENT_UNFILTERED，不读取受限光环/战斗日志，不按 UnitGUID 建显示索引。 |
| `INV-005` | 光环匹配、真实层数/身份/时间、按钮分配与受限可见性归客户端；Lua 只编译公开配置。 |
| `INV-006` | 身份拒绝 fail-closed；不得删除 includeSpellIDs、扩大到全量或用 pcall 重试绕过。 |
| `INV-007` | 已收养按钮/后代的样式访问仅在非战斗且 aura 非 secret 时执行；创建回调例外不授权后续自由访问。 |
| `INV-008` | 真实时间不得在 Lua 中算术/格式化/比较，真实堆叠不得在 Lua 累计。 |
| `INV-009` | 移除/回收/组删除清旧 token、禁用容器、隐藏；迟到旧事件不清新绑定。 |
| `INV-010` | false 是有效配置；导入失败不污染有效配置；合法未解析规则不因暂缺元数据而删除。 |
| `INV-011` | 不可实现的旧选项诚实标记仅存档；不得用合成图标、常量或死代码冒充能力。 |
| `INV-012` | Timer/扫描/缓存/Frame 有所有者和终止/复用策略；不无限轮询真实 aura，不保存瞬态对象。 |
| `INV-013` | 新能力从目标源码取得路径、行号、签名、返回值、保护边界；TOC/mock 不替代 Gate。 |
| `INV-014` | Lua 5.1、UTF-8 无 BOM、Lua 注释英文、用户文本直接 UTF-8；不执行用户排序脚本。 |
| `INV-015` | 规格、JSON、测试、源码、验证状态同步；未执行游戏内测试不能写通过。 |

---

## 4. 架构与安全访问模型

### 4.1 职责分层

| 层 | 所有者 | 职责 |
|---|---|---|
| 配置与目录 | 插件 Lua | 图标组、规则、公开 ID/name、样式、候选参数、对象/区域策略。 |
| 姓名板状态 | 插件 Lua | states[plate][index]、visibleByUnit[unit]、容器挂接、绑定/回收。 |
| 安全容器 | Blizzard | 真实事件/允许的数据读取、候选匹配、排序、Frame 分配、布局、受限显示。 |
| 按钮委托 | Blizzard | 图标、count、duration cooldown/text、dispel texture、动画、系统 tooltip。 |
| 合成预览 | 插件自有 Frame | 自有时间/层数，演示部分组级样式。 |

`CustomAuraContainerTemplate` / `CustomAuraButtonTemplate` 的 `secureDelegates="true"` 不会让普通插件进入安全环境，而是由官方 inbound delegate 验证执行配置。

### 4.2 受限对象生命周期

- `CreateState()` 创建 `AuraContainer`，使用 `CustomAuraContainerTemplate`。
- `AddAuraGroup()` 的 `initializeFrame` 创建视觉对象并初次设样式。
- 官方 FrameProvider 先回调再施加 `DenyTaintedAccessWhenAurasAreSecret`；当前按钮批次大小为 10。
- 不从回调次数/帧池大小推断真实 aura 数量，不以 GetAuraGroupFrameCount 探测战斗信息。
- 收养对象需是按钮自身或后代；会禁止更改父级、解除 secret aspects 等；动画还有额外限制。
- `slot.Buttons[button]=visuals` 仅用于许可期重设样式，不保存真实光环身份。

### 4.3 访问门禁与延迟更新

`CanRestyleButtons()` = `not InCombatLockdown() and not C_Secrets.ShouldAurasBeSecret()`。

公开配置可更新；已有按钮重皮标记 `NeedsSkin`，许可后统一处理。不能借 GetFrameLevel、读取子对象/动画或修改 FontString 绕过门禁。

新按钮 `initializeFrame` 按官方创建契约允许初次配置，仅限创建阶段。解除限制后的延迟恢复路径调用 `UpdateAllAuras()`，让客户端重建显示绑定。

### 4.4 视觉层级

`src/NameplateAuras.lua:315-423`：Texture、边框、Cooldown、Overlay 都是按钮后代；Overlay 初始层级为 Cooldown + 1；count/time/glow 在 Overlay 上。文字锚定按钮，收养后不通过 reparent 抬层。

真实按钮用 SetIcon、SetApplicationCount、SetDurationCooldown、SetDurationText 等官方委托。传入 DurationTextBinding 是配置模板，由按钮内部复制配置，不是跨按钮共享同一个真实倒计时。

### 4.5 禁止的替代实现

不能以“只在战斗外”“缓存下来”“加 pcall”“Plater 也这样”新增：普通真实 aura 枚举、combat log 数据源、secret expiration/duration/applications 算术、GUID/spellID→真实按钮分配、用户 Lua 排序、旧 glow/Masque/tooltip 动态访问已收养真实按钮。

### 4.6 模块间调用契约

这些是项目内部函数，不是第三方可依赖的稳定公共 API。后续改签名要同步所有调用方和测试。

| 接口 | 所有者 / 输入输出 | 约束与副作用 |
|---|---|---|
| `GetIconGroupDefaultOptions(name)` | core，返回独立组默认表。 | 配置真源；不能把 false 默认与历史迁移结果混同。 |
| `SpellCatalog:Add/Seed/Start` | utils，公开spell信息/无参。 | 不查询单位光环；Start幂等、有界；Seed仅补公开条目。 |
| `UpdateAllNameplates()` | core，无参数语义。 | invalidates公开spec、revision+1、合并timer；现有true/false实参被忽略。 |
| `RebuildSpellCache/RebuildAuraSortFunctions` | core，无参。 | Seed/刷新或仅刷新，均不建立真实 aura 缓存/执行用户Lua。 |
| `PrepareProfileImport(profile)` | database，候选表或 `nil,message`。 | 深拷贝验证/迁移，恢复当前db引用；不是提交入口。 |
| `PrepareSpellImport(entry)` | database，独立规则或 `nil,message`。 | 用当前组副本验证，不修改live profile。 |
| `ImportProfile(profile)` | core，`true` 或 `false,message`。 | 整配置替换与reload失败内容回滚；不能代替保存/GT。 |
| `PrepareForeverProfile/MigrateDB/NormalizeForeverProfile/RecoverUnresolvedSpells` | database，操作addonTable.db。 | 前置修复/历史转换/现代归一化/公开ID恢复，职责不要互换。 |
| `ReloadDB()` | core，读取当前aceDB.profile。 | 停预览、迁移/补全、目录启动、GUI回读、补state/刷新。 |
| `OnSpellInfoCachesReady/OnSpellCatalogUpdated` | options定义空ready入口，core追加。 | 公开目录通知，不是每个真实aura变化通知；不得重复hook。 |
| `GuiOnProfileChanged/OnIconGroupChanged` | options，无参。 | 当前组回1/控件回读、重建下拉、请求刷新；不替代数据归一化。 |
| `ShowGUI/SwitchTestMode` | options/core，无参。 | 许可期打开GUI/切合成预览；真实显示与预览分离。 |

---

## 5. 功能规格：筛选与图标组

### 5.1 功能标识

| ID | 功能 | 当前能力边界 |
|---|---|---|
| `F-001` | 独立加载与初始化 | 幂等初始化，独立 SV/命令，无 Plater 依赖。 |
| `F-002` | 姓名板绑定/回收 | 每个 plate × 图标组一个可复用容器；token 移除/复用防串板。 |
| `F-003` | 容器显示策略 | 自身、仅目标、敌友区域、目标区域例外、NPC 名称黑名单。 |
| `F-004` | 显式法术规则 | 名称、ID 集、启用状态、光环类型、对象类型与组成员编译为候选。 |
| `F-005` | 同名全等级目录 | 公开目录异步构建；未完成时可能已有部分 ID，不承诺完整。 |
| `F-006` | 我的光环 fallback | 官方 PLAYER；有黑名单时按身份权限与目录就绪关闭不可靠组。 |
| `F-007` | 净化/偷取 fallback | 敌对 helpful + isStealable；不是任意友方驱散或职业净化判断。 |
| `F-008` | 布局与目标样式 | 四向流式布局、组/规则尺寸、位置、锚点、alpha、目标 scale/strata。 |
| `F-009` | 排序 | 客户端在同一安全样式组内排序；组间仅按公开配置排组。 |
| `F-010` | 时间/堆叠/冷却 | 官方 duration/count 绑定；NumericRuleFormatter 向上取整。 |
| `F-011` | 边框/动画/tooltip | 客户端 dispel texture、统一永久 glow/always 闪烁、系统 tooltip。 |
| `F-012` | 配置与规则导入/导出 | 原编码链；整配置校验、隔离迁移、reload 失败回滚。 |
| `F-013` | 历史迁移 | 0..33、false 保留、路径修正、稀疏组重映射、未解析规则恢复。 |
| `F-014` | GUI 与 Profiles | 12 页、嵌入库构造器、目录进度、正确的 Settings 父分类。 |
| `F-015` | 合成预览 | 4 个自有示例图标；与真实过滤、限制和单规则外观分离。 |
| `F-016` | 旧能力限制提示 | 保存兼容字段，明确不可用，不执行。 |

### 5.2 容器级显示条件

`ShouldShowState()`（`src/NameplateAuras.lua:124-140`）依次判断：

1. 图标组、unit token 存在，UnitExists(unit) 为真。
2. 若安全确认是自身，要求 ShowAurasOnPlayerNameplate=true。
3. 若 ShowOnlyOnTarget=true，必须安全确认是当前目标。
4. UnitIsFriend(player,unit) 选择友方/敌方实例类型开关。
5. 区域禁用时，仅对应敌/友目标例外开关且确认是目标才放行。
6. 非玩家单位且 NPC 黑名单有启用项时：身份 secret、名字 secret/nil 或名字命中均不显示。
7. 全局预览开启时真实容器禁用/隐藏，预览独立显示。

目标比较先验证 CanCompareUnitTokens 与 ShouldUnitComparisonBeSecret，再对 UnitIsUnit 结果检查 issecretvalue；无法确认目标则 fail-closed。

UnitIsFriend 用于友敌条件；UnitCanAssist 用于官方身份授权，二者不可互换。实例键为 none、unknown、pvp、pvp_bg_40ppl、arena、party、raid、scenario；GetInstanceInfo 的第 2/8 值用于类型/ID。大规模战场映射来自 `src/consts.lua:86-93`，不等于全部 Forever 地图已实测。

### 5.3 单规则编译

规则同时满足：entry.iconGroups[index] 启用、enabledState 非 DISABLED、友/敌开关匹配、玩家/宠物/NPC 类型开关匹配。

分类：UnitIsPlayer → 玩家；UnitIsOtherPlayersPet 或安全确认是 pet → 宠物；否则 NPC。不是按 GUID 解析所有 guardian/vehicle。

| ID 输入 | 当前行为 |
|---|---|
| checkSpellID=nil | 取目录中该名称当前已有的全部公开 ID。 |
| 显式非空表 | 仅启用的数值 ID，且其公开名称与规则名称完全相同。 |
| 显式空表/全 false/无有效 ID | 不产生候选，不扩大为所有同名等级。 |
| 旧 number/string/list 表示 | 归一化为 ID→boolean；无效值转空集合并在部分路径保留 Raw。 |
| 名称/ID 尚未解析 | 保留规则，不凭空生成全量候选。 |

过滤串：减益 HARMFUL|INCLUDE_NAME_PLATE_ONLY；增益 HELPFUL|INCLUDE_NAME_PLATE_ONLY；MYAURAS 追加 |PLAYER；ANY 分别生成 helpful/harmful。

**PLAYER 官方语义含玩家本人及其宠物/载具来源**，不是再追加 PET，也不是旧版 sourceUnit==player 的完全等价实现。

### 5.4 身份权限矩阵

官方策略 `BAC/Blizzard_AuraContainerUtil.lua:52-111` 由安全容器按每条光环执行：

| 光环 / 单位策略 | 精确身份 include/exclude |
|---|---|
| NeverSecret 法术光环 | 客户端授权例外；插件不能自行标记。 |
| harmful 且 UnitCanAssist(player,unit,true,true) 为真 | 一般身份筛选拒绝；非例外 include 光环不显示。 |
| harmful 且不能 assist | 一般允许，仍受客户端其他策略约束。 |
| helpful 且玩家控制/组成员等官方识别单位 | 官方优先授权分支，含部分 assist=false 的边界。 |
| helpful 且可 assist | 一般允许。 |
| helpful 且不能 assist、又无上述例外 | 一般身份筛选拒绝；非例外 include 光环不显示。 |

- includeSpellIDs 存在时不可过滤身份的光环默认拒绝，不能改成全量显示。
- 身份过滤拒绝时仅 excludeSpellIDs 不能保证排除，该字段可能被忽略。
- 身份策略由光环类型/单位授权决定，不只在 ShouldAurasBeSecret=true 时成立；不能承诺战斗外敌方增益任意精确筛选。
- 普通代码不读取真实 aura 来判断 NeverSecret，交给客户端。

### 5.5 我的光环 fallback

AlwaysShowMyAuras 默认 **false**。开启后分别尝试 helpful/harmful PLAYER 组：

- 用户名称黑名单展开公开 ID，与同光环类型显式规则 ID 合并到 excludeSpellIDs。
- 全 false 不算启用黑名单。
- 有启用的名称黑名单时，必须对应 broad identity 权限成立且 SpellCatalog.Ready=true，才建立 fallback。
- harmful 权限为 not canAssist；helpful 为 canAssist 或 UnitIsPlayerControlledOrGroupMember 的真值。
- 无用户黑名单时可保留 broad fallback，但避免显式重复的 exclude 集不是全单位有效的保证。
- 净化 fallback 在当前单位/区域实际启用（`showDispel` 为真）时，helpful 我的 fallback 才增加 `isStealable=false`。只开启净化配置开关不足以触发此谓词。

### 5.6 净化/偷取 fallback

同时要求 Additions_DispellableSpells=true、单位非 friendly、区域允许、净化黑名单无启用项。

候选为 HELPFUL|INCLUDE_NAME_PLATE_ONLY + isStealable=true，exclude 当前 helpful 显式规则 ID；使用净化尺寸与统一永久 glow。

限制：有净化黑名单时整个 fallback 关闭；isStealable 不是当前职业可净化判定，也不是任意友方驱散/激怒驱散；与 mine 互斥靠官方 false/true 谓词，Lua 不读 auraData。与任意显式规则的全局唯一显示不是保证。

### 5.7 合并、重叠与排序

编译键为过滤串 + 宽高/边框/颜色/glow/blink 样式签名 + 来源 suffix。

- 同过滤/样式/来源的显式 ID 可合并进一组。
- 同名不同 rank 规则不删除。
- 同 ID 在不同样式/过滤/图标组可多次显示；当前无跨组优先级/全局去重。
- consolidate 不执行，不合并真实光环或层数。

| SortMode | 当前语义 |
|---|---|
| 1 NONE | 每个安全组 AuraInstanceIDOnly；非旧 Lua 插入顺序保证。 |
| 2 EXPIRETIME | 每组 ExpirationOnly，Normal。 |
| 4 ICONSIZE | 公开样式组按 min(width,height) 升序排，组内仍 expiration。 |
| 6 AURATYPE_EXPIRE | harmful 组在 helpful 前；组内 expiration。 |
| 7 CUSTOM 或其他继承值 | 不执行用户 Lua；核心组内走 expiration 分支。 |

**不承诺跨安全样式组按真实剩余时间全局排序**；table.sort(specs) 只处理公开配置。

---

## 6. 视觉、时间与交互规格

### 6.1 布局与挂接

- 官方 FlowLayout，四向生长；IconSpacing 同时是 elementSpacing/groupSpacing。
- 元素尺寸用组默认或规则明确开启的 overrideSize。
- MaximumLineSize=math.huge，当前单线，无图标配额/自动换行。
- IconAnchor 映射见 `src/NameplateAuras.lua:299-313`。
- NAMEPLATE 挂 plate；HEALTHBAR 尝试非 forbidden UnitFrame.HealthBarsContainer，否则 plate。
- NameplateIsParent=false 时容器以 UIParent 为父并锚在 plate/healthbar；true 时以 anchor 为父。
- 历史 TPTP 选项没有 Forever 特定 ThreatPlates 实现，核心退回 plate。
- alpha：是目标，或无目标且 UseTargetAlphaIfNotTargetSelected，使用目标 alpha；否则普通 alpha。
- scale：目标 IconScaleTarget，否则 1；strata：目标/非目标独立。
- 目标比较受限时按非目标处理；target-only 不放行。

### 6.2 图标与字体

IconZoom 裁切，KeepAspectRatio 按公开宽高校正。时间相对字号 ceil(min(W,H)/2*FontScale)，绝对用 TimerTextSize；count 字号 ceil(min(W,H)/4*StacksFontScale)。字体、锚点、偏移独立；时间 outline+黑影。

内置字体为 NAurasForever_TeenBold / NAurasForever_TexGyreHerosBold。存在字体文件不证明所有中文字形或不同 UI scale 实际效果。

### 6.3 真实时间显示

NumericRuleFormatter → DurationTextBinding → 官方 duration text 委托。真实时间由客户端计算，Lua 只配置公开断点。令 T=MinTimeToShowTenthsOfSeconds：

| 条件 | 规则 | 期望 |
|---|---|---|
| T>0 | threshold=0、step=0.1、Up | %.1f 向上十分位。 |
| T<60 | threshold=T、step=1、Up | %.0f 向上整秒。 |
| 总是 | threshold=60、component div=60、step=1、Up | %dm 向上分钟。 |
| 总是 | threshold=3600.000001 | 空文本。 |

绑定 0.1s 更新，zero/expired 空，不伪造永久光环时间。以下是待游戏验证的期望：

| T | 剩余时间 | 期望 |
|---|---|---|
| 0 | 2.1 / 2.0 / 0.5 秒 | 3 / 2 / 1 |
| 10 | 2.31 / 0.01 秒 | 2.4 / 0.1 |
| 10 | 9.91 / 10.0 秒 | 10.0 / 10 |
| 任意 | 60 / 61 秒 | 1m / 2m |
| 任意 | 960 / 961 秒 | 16m / 17m |
| 任意 | 3600 / 3601 秒 | 60m / 空 |
| 任意 | 到期 / 零时长 | 空，不显示假 0 |

3600.000001 是当前精确边界；不能把 epsilon 窗口简写成所有 >3600 均隐藏。调整需同步规则与测试。

历史向上取整意图参考 `LEGACY/Timer_Ceil_Fix_SPEC.md`；只继承显示意图，不复制真实 Lua 时间算术。

### 6.4 颜色与独立开关

- 绝对色：RemainingDuration + Step，0/5/60 节点。
- 相对色：RemainingPercent + Linear，0/1 节点。
- 客户端评估，不以 Lua 比较真实秒数/百分比；整点、零时长、刷新百分比实测。

| 开关 | 作用 |
|---|---|
| ShowCooldownAnimation | swipe；与 ShowCooldownSwipeEdge 一起决定 edge，不隐藏独立时间数字。 |
| ShowCooldownText | 绑定/清除 duration text，显隐 v.Time。 |
| ShowStacks | 绑定/清除 count，显隐 v.Count。 |

Cooldown 始终隐藏自带数字并设 noCooldownCount=true；独立时间绑定提供数字，外部计时插件组合仍待测。

### 6.5 边框、动画与 tooltip

- 内置 1..5px 或自定义媒体；规则边框开启覆盖组边框。
- 增减益独立；dispel map 为 None/Magic/Curse/Disease/Poison/Enrage/Bleed，后两者用 other 色。
- PreserveAsset，真实类型与着色由安全委托。
- showGlow=GLOW_TIME_INFINITE 且 glowType 非 NONE 时统一橙色脉动，不复现旧库模式。
- always blink 为 alpha 1→0.35、0.5 秒、BOUNCE；时间阈值/相对阈值仅存档。
- 点击禁用，motion 由 ShowAuraTooltip 控制，使用系统 tooltip、ANCHOR_RIGHT。
- 请求战斗不主动隐藏 tooltip，不代表可见任意受限数据。

---

## 7. 配置数据字典

### 7.1 顶层模型

账号 SV 由 AceDB 管理，业务读取 aceDB.profile，不是整个 SV 或角色级文件。

| 对象/字段 | 类型与含义 |
|---|---|
| NameplateAurasForeverAceDB | 唯一声明的业务 SV；非表时建立空表。 |
| profileKeys / profiles | AceDB 的角色键→profile 名、profile 名→配置。New 未指定共享默认 profile，遵循已有映射/角色键。 |
| aceDB.profile / addonTable.db | 当前业务配置，整配置导入导出对象。 |
| DBVersion | 非负整数，当前 34。 |
| DefaultSpellsLastSetImported | 已处理批次数，当前 4；非成功导入条数。 |
| CustomSpells2 | 法术规则集合，GUI 使用列表；历史 ID-key 表迁移转换。 |
| IconGroups | 归一化后的稠密数组，至少一组。 |
| 其他兼容字段 | 除规定迁移删除项外，不无依据清除，不自动执行。 |

Frame、timer、真实 aura、states、compiledSpecs、目录和运行期绑定不写 SV。

### 7.2 组字段：身份、显示、布局

当前默认来自 GetIconGroupDefaultOptions；旧迁移后取值可能不同。

| 字段 | 类型 | 默认 / 语义 |
|---|---|---|
| IconGroupName | string | IG+日期时间；旧迁移可用 First Icon Group。 |
| ShowAurasOnPlayerNameplate | boolean | false，自身姓名板。 |
| ShowOnlyOnTarget | boolean | false，仅目标。 |
| FriendlyUnitsAurasEnabledZoneTypes / EnemyUnitsAurasEnabledZoneTypes | string→boolean | 8 类型均 true。 |
| ShowAurasOnEnemyTargetEvenInDisabledAreas / ShowAurasOnAlliedTargetEvenInDisabledAreas | boolean | false / false，目标区域例外。 |
| NpcBlacklist | string→boolean | 空，非玩家名字过滤。 |
| AlwaysShowMyAuras / AlwaysShowMyAurasBlacklist | boolean / map | false / 空，mine fallback。 |
| IconXOffset / IconYOffset | number | 0 / 50。 |
| FrameAnchor / FrameAnchorToNameplate | anchor | CENTER / CENTER。 |
| AttachType / NameplateIsParent | enum / boolean | 1 NAMEPLATE / false；2 healthbar、3 历史 TPTP。 |
| DefaultIconSizeWidth / DefaultIconSizeHeight | number | 45 / 45。 |
| IconSpacing | number | 1，元素与组间距。 |
| IconAnchor | enum | 1 bottom-left；2 top-right、3 center。 |
| IconGrowDirection | enum | 1 right；2 left、3 up、4 down。 |
| SortMode / CustomSortMethod | enum / string | 2 expiration / 历史名称排序字符串；custom 不执行。 |
| IconZoom / KeepAspectRatio | number / boolean | 0.07 / true。 |
| IconAlpha / IconAlphaTarget | number | 1 / 1。 |
| IconScaleTarget | number | 1，范围至 10。 |
| UseTargetAlphaIfNotTargetSelected | boolean | false。 |
| TargetStrata / NonTargetStrata | strata | HIGH / MEDIUM。 |

### 7.3 组字段：时间、堆叠、边框

| 字段 | 类型 | 默认 / 语义 |
|---|---|---|
| Font / StacksFont | media key | NAurasForever_TeenBold。 |
| FontScale / StacksFontScale | number | 1 / 1。 |
| TimerTextUseRelativeScale / TimerTextSize | boolean / number | true / 20。 |
| TimerTextAnchor / TimerTextAnchorIcon | anchor | CENTER / CENTER。 |
| TimerTextXOffset / TimerTextYOffset | number | 0 / 0。 |
| TimerTextSoonToExpireColor | RGBA | {1,0.1,0.1,1}，0 秒节点。 |
| TimerTextUnderMinuteColor | RGBA | {1,1,0.1,1}，5 秒节点。 |
| TimerTextLongerColor | RGBA | {0.7,1,0,1}，60 秒节点。 |
| TimerTextUseRelativeColor | boolean | false。 |
| TimerTextColorZeroPercent / TimerTextColorHundredPercent | RGBA | {1,0.1,0.1,1} / {0.1,1,0.1,1}。 |
| MinTimeToShowTenthsOfSeconds | number | 10。 |
| StacksTextAnchor / StacksTextAnchorIcon | anchor | BOTTOMRIGHT / BOTTOMRIGHT。 |
| StacksTextXOffset / StacksTextYOffset | number | -3 / 5。 |
| StacksTextColor | RGBA | {1,0.1,0.1,1}。 |
| ShowStacks / ShowCooldownText / ShowCooldownAnimation / ShowCooldownSwipeEdge | boolean | 均 true，四个独立/组合开关。 |
| BorderType | enum | 1 builtin；2 custom、3 disabled。 |
| BorderThickness / BorderFilePath | number / string | 2 / Forever media/custom-example.tga。 |
| ShowBuffBorders / ShowDebuffBorders | boolean | true / true。 |
| BuffBordersColor | RGBA | {0,1,0,1}。 |
| DebuffBordersMagicColor | RGBA | {0.1,1,1,1}。 |
| DebuffBordersCurseColor | RGBA | {1,0.1,1,1}。 |
| DebuffBordersDiseaseColor | RGBA | {1,0.5,0.1,1}。 |
| DebuffBordersPoisonColor | RGBA | {0.1,1,0.1,1}。 |
| DebuffBordersOtherColor | RGBA | {1,0.1,0.1,1}。 |
| ShowAuraTooltip | boolean | false，系统 tooltip。 |
| UseDefaultAuraTooltip / MasqueEnabled | boolean | true / false，旧字段不执行。 |

### 7.4 组字段：净化与保留能力

| 字段 | 默认 | 当前语义 |
|---|---|---|
| Additions_DispellableSpells | false | 净化 fallback。 |
| Additions_Dispel_InstanceTypes | 8 类型 true | 净化区域。 |
| Additions_DispellableSpells_Blacklist | 空 | 启用项存在则关闭 fallback。 |
| DispelIconSizeWidth / DispelIconSizeHeight | 45 / 45 | 净化尺寸。 |
| Additions_DispellableSpells_GlowType | 4 PIXEL | 非 NONE 启用统一 glow，不复现旧像素模式。 |
| InterruptsEnabled | false | 不执行。 |
| InterruptsIconSizeWidth / InterruptsIconSizeHeight | 45 / 45 | 保留。 |
| InterruptsGlowType / InterruptsUseSharedIconTexture / InterruptsShowOnlyOnPlayers | 5 / false / true | 保留。 |
| Additions_ExplosiveOrbs / Additions_DRPvP / Additions_DRPvE | false | 不执行。 |
| AffixSpiteful / AffixSpitefulSound | false / 5274 | 保留，不执行声音提醒。 |

### 7.5 关键范围：UI 与归一化不能混同

| 字段 | GUI 范围 | 载入策略 |
|---|---|---|
| 默认/规则图标宽高 | 1..75 | clamp 1..75，MAX_AURA_ICON_SIZE=75。 |
| 组/规则边框粗细 | 1..5 | clamp、取整数。 |
| IconScaleTarget | 0.1..10 | clamp 0.1..10，不退回旧错误上限 5。 |
| IconZoom | 0..0.3 | clamp 0..0.49。 |
| FontScale / StacksFontScale | 0.3..3 | clamp 0.1..5。 |
| TimerTextSize | 6..96 | clamp 1..100。 |
| 十分位阈值 | 0..10 | clamp 0..60。 |
| IconAlpha / IconAlphaTarget | 0..1 | 类型/有限值补默认，当前没有额外 0..1 clamp。 |
| IconSpacing | 0..50 | 当前没有额外范围 clamp。 |
| IconXOffset / IconYOffset | -200..200 | 当前没有额外范围 clamp。 |
| 时间/count 偏移 | -100..100 | 当前没有额外范围 clamp。 |
| anchor / strata | 下拉枚举 | 九种 anchor / 八种 strata，非法回默认。 |
| RGBA | 拾色器 | 补缺失、已知数值有限性校验；非所有通道统一 0..1 clamp。 |

UI 范围不是导入拒绝范围。修复/clamp 后可使用不代表原输入完整合法。

### 7.6 法术规则字段

| 字段 | 类型 / 默认 | 边界 |
|---|---|---|
| spellName | string | 单条导入非空；显式 ID 名称需完全匹配。 |
| checkSpellID | nil 或 ID→boolean | nil 同名目录；空/全 false 不匹配。 |
| enabledState | 1 disabled / 2 all / 3 mine，缺失 2 | 旧字符串转换；非法保留 Raw 并禁用。 |
| auraType | 1 buff / 2 debuff / 3 any，缺失 3 | 旧字符串转换；非法转 any 并禁用。 |
| iconGroups | index→boolean，缺失/空通常 {1=true} | 随组索引映射。 |
| showOnFriends / showOnEnemies | boolean，缺失 true | 友敌条件。 |
| showOnPlayers / showOnNpcs / showOnPets | boolean，现代缺失 true | 旧 playerNpcMode 迁移可给不同值。 |
| iconSizeWidth / iconSizeHeight | number，通常 45 | 缺失补全，范围 1..75。 |
| overrideSize | boolean，归一化缺失 false | true 才覆盖，旧尺寸迁移可推导 true。 |
| showGlow | nil / 非负时间 / 2592000 | 仅等于 GLOW_TIME_INFINITE 才永久；有限阈值只保存；旧 false→nil。 |
| glowType | 1..5，缺失 3 | 1 关闭，其他作为统一 glow 信号。 |
| animationType | 2 ALPHA | 非法关闭动画；不执行旧 scale 动画。 |
| animationDisplayMode | 1 none / 2 always / 3 threshold，缺失 1 | 仅 always 执行。 |
| animationTimer | number，缺失/非法补 10 | 阈值不执行。 |
| useRelativeGlowTimer / useRelativeAnimationTimer | 可缺失 boolean | 不执行。 |
| customBorderType | 1 builtin / 2 custom / 3 disabled，缺失 3 | 3 不覆盖组；1/2 覆盖。 |
| customBorderSize / customBorderColor / customBorderPath | number / RGBA / string | 默认组粗细或2 / {1,0.1,0.1,1} / 空；旧路径转换。 |
| consolidate / spellTooltip | 兼容字段 | 不合并真实层数，不恢复旧自绘 tooltip。 |
| unresolvedSpellID | number | 历史法术 ID 恢复标记，非真实 auraInstanceID。 |
| spellNameRaw / checkSpellIDRaw / showGlowRaw / enabledStateRaw / auraTypeRaw | 诊断字段 | 部分修复保留原值，非完整损坏配置备份。 |

枚举真源 `src/consts.lua`。GUI 新规则默认第一组 membership；复制当前图标组不自动给所有规则加新组成员。

---

## 8. SavedVariables、迁移与导入/导出

### 8.1 载入流水线

ReloadDB：停止预览 → 取 aceDB.profile → PrepareForeverProfile → MigrateDB → NormalizeForeverProfile → ImportNewSpells → 清编译缓存 → 目录 Start/Seed → GUI 回读 → 补可见姓名板 state 并刷新。

- 迁移前仅建最低结构前提，不提前填旧 schema 的 nil 哨兵。
- 类型错误、NaN/±Inf、坏组 key/规则结构按局部修复逻辑处理。
- 默认项按类型/缺失补齐，不能以 value or default 抹掉 false。
- 稠密组重排时成员按旧→新 index 同步。
- 同名合法 rank 规则保留，不能按名称简单去重用户规则。
- 此修复流程不是任意恶意/损坏 Lua SV 的无损恢复系统。

### 8.2 历史迁移登记

DBVersion 表示下一个应执行编号；34 表示 0..33 全执行。后续 schema 变化原则上追加迁移，不能改老迁移语义来隐式变更已发布存档。

| 编号 | 职责 |
|---|---|
| 0 | 清指定废弃字段；旧 timer/sort/十分位表示转换；ID 表转换；boolean glow true→永久、false→关闭。 |
| 1 | 旧 spellID-key 规则转列表，暂缺名字保留真实历史 ID 与占位。 |
| 2 | 删除 CustomSpells3、allowMultipleInstances。 |
| 3 | UseDimGlow 转规则 glowType，清旧 dim 字段。 |
| 4 | InterruptsGlow 转 InterruptsGlowType。 |
| 5 | 从 FrameAnchor 建 FrameAnchorToNameplate。 |
| 6 | TOPLEFT/LEFT/BOTTOMLEFT 字符串转 IconAnchor 枚举。 |
| 7 | TimerStyle 2/3 转新 style；先保存旧 3 的布尔意图，再设 ShowStacks/ShowCooldownText。 |
| 8 | TimerStyle 转 ShowCooldownAnimation 并删除。 |
| 9 | 旧降序排序转左增长与对应模式。 |
| 10 | IgnoreNameplateScale/FullOpacityAlways 转目标 scale/alpha。 |
| 11 | 删除 IconScale。 |
| 12 | 时间颜色补 alpha。 |
| 13 | 单尺寸转宽高。 |
| 14 | 打断/净化尺寸转宽高。 |
| 15 | 旧 scale 动画转 alpha。 |
| 16 | count 颜色补 alpha。 |
| 17 | 各边框颜色补 alpha。 |
| 18 | 删除 pvpCombat。 |
| 19 | 删除 customBorderEnabled，建 customBorderType。 |
| 20 | 建 mine 黑名单。 |
| 21 | 删除旧顶层 MaxAuras。 |
| 22 | 已列出的顶层组设置迁入第一 IconGroup。 |
| 23 | 补组名。 |
| 24 | 补组颜色缺失通道。 |
| 25 | 按规则/组尺寸差异推导 overrideSize。 |
| 26 | 补 ShowCooldownSwipeEdge。 |
| 27 | 建友方区域开关。 |
| 28 | 若 ShowAboveFriendlyUnits 仍存在，将真实布尔值转区域开关，保留 false。 |
| 29 | EnabledZoneTypes 转敌方区域开关。 |
| 30 | 旧目标区域例外转敌方例外，建友方例外 false。 |
| 31 | AttachToAddonFrame 转 AttachType；TPTP 历史值非已实现挂接。 |
| 32 | 补净化区域表。 |
| 33 | playerNpcMode 转玩家/NPC/宠物布尔，并删除。 |

归一化另负责旧包媒体路径/字体 key 转 Forever、参数修复、稀疏组重映射、非法状态禁用。未解析规则恢复由 `MigrateDB()` 和目录更新回调触发，见 §8.3。实现真源为 `src/database.lua:24-980`。

### 8.3 未解析规则

- 历史真实 ID 无名称时保留 unresolvedSpellID 与 Unknown spell #ID。
- RecoverUnresolvedSpells 在迁移/目录更新中用公开元数据尝试恢复。
- SpellNameByID 查询 nil 不产生有效缓存条目，后续可重新查询；rawset(t,key,nil) 不是永久缓存 nil。
- 现代规则无名字/无可信历史 ID 时，当前补全可能以集合 key 当恢复标记；不能保证那是法术 ID，见 K-006。
- 没有通用元数据抵达事件监听；扫描结束后的任意晚到元数据不保证自动恢复。

### 8.4 编码链与对象

整配置/单条：LibSerialize Serialize → LibDeflate CompressDeflate → EncodeForPrint；逆向 DecodeForPrint → DecompressDeflate → Deserialize → 验证/隔离迁移 → 应用。

输入不是可执行 Lua，不经 loadstring。整配置导出当前 addonTable.db，不是 AceDB 的整个 profileKeys/profiles；保留兼容字段，不自动读取原 TBC SV。

### 8.5 整配置事务

PrepareProfileImport：

1. 表结构与版本 0..34 整数；缺失按旧 0；较新拒绝。
2. 已知组/规则字段类型与有限值；黑名单 string→boolean；membership 正整数→boolean。
3. legacy SortMode（version<1）与 IconAnchor（version<7）字符串先由迁移转换。
4. showGlow 旧 boolean 仅 version<1；animationType=3 仅 version<16。
5. 深复制，在候选上 Prepare/Migrate/Normalize；失败恢复原 db 引用不提交。
6. ImportProfile 快照原配置，在同一活动表整体替换内容；pcall(ReloadDB) 失败恢复快照并尝试 reload，返回错误信息。

事务边界是配置内容与应用失败恢复，不是 ACID 系统；二次 reload 也失败时不能声称 GUI/提示弹窗/所有瞬态状态恢复完整。

checkSpellID 部分历史形状仍修复转换，不是所有原形状严格拒绝；未知字段并非完整白名单。测试通过不代表任意畸形/恶意输入被完整验证。

### 8.6 单条导入

要求非空 spellName。PrepareSpellImport 用当前组副本包装当前 schema profile，复用验证，返回独立规则；成功后 GUI 追加并更新列表。

没有旧 profile DBVersion，现代 showGlow=false 会拒绝，不承诺所有历史单条直接兼容。单条后续 GUI 应用不是整配置 reload 回滚事务；扩展需另行规格。

### 8.7 默认批次

`src/spells.lua:32-218` 当前 4 个历史批次、177 条（162/6/1/8），包含不同版本来源 ID。

- 首次/强制处理从 0 开始，只添加当时有公开名称且未被用户名称集合占用的规则。
- 后续新增批次询问是否追加，处理计数仍推进。
- 同批次同名项不是已验证的全局唯一策略。
- 名称在文件加载时查询，nil 项跳过；处理计数不代表成功导入数。
- 不能因部分 ID 较新断言全部无效，也不能断言全部可用；逐项公开元数据/游戏验证。
- 旧账号迁移仅从用户显式导出/导入开始。

### 8.8 较新 schema

显式导入 >34 拒绝。已有较新 SV 不重跑 0/1、不降版本，但仍经历部分补全/归一化；这不是未来 schema 无损向后兼容保证。真正未来版只读/拒绝策略需要后续定义。

---

## 9. 生命周期、事件与所有权

### 9.1 初始化

PLAYER_LOGIN、ENTERING_WORLD 幂等 Initialize；IsLoggedIn 已真则立即初始化/同步。initialized 防重复 DB/分类/slash。AceDB profile Changed/Copied/Reset 均 ReloadDB。OnSpellInfoCachesReady 在 options 先定义，核心以 hooksecurefunc 追加，不替换。

### 9.2 核心事件

`src/NameplateAuras.lua:749-780`：

| 事件 | 官方 payload / 使用 | 动作 |
|---|---|---|
| PLAYER_LOGIN | 不依赖额外值 | Initialize。 |
| PLAYER_ENTERING_WORLD | isInitialLogin,isReloadingUi，当前忽略 | Initialize、停预览、更新区域、全姓名板同步。 |
| NAME_PLATE_UNIT_ADDED | unitToken | 字符串/plate 检查，清旧映射，绑定、重编译。 |
| NAME_PLATE_UNIT_REMOVED | unitToken | 防 nil/非字符串/迟到，解绑隐藏。 |
| PLAYER_TARGET_CHANGED | 不依赖 payload | 立即刷新目标显示/样式。 |
| ZONE_CHANGED_NEW_AREA | 不依赖 payload | 更新区域、清编译规格、合并刷新。 |
| PLAYER_REGEN_DISABLED | 不依赖 payload | 停预览，不读真实 aura。 |
| PLAYER_REGEN_ENABLED | 不依赖 payload | 尝试延迟重皮；若仍 secret 继续等。 |
| ADDON_RESTRICTION_STATE_CHANGED | type,state，仅用 state | 非 Inactive 停预览，合并刷新。 |
| UNIT_FACTION / UNIT_FLAGS | unitTarget | 仅可见 unit 或 player 时 invalidate/刷新。 |

GUI 另监听战斗事件隐藏/恢复；官方容器内部自行处理 UNIT_AURA，插件不接管。源码说明不代替实际 payload/时序验收。

### 9.3 回收

states 按 plate/组保留；visibleByUnit 是当前映射。token 指向新 plate 先 detach；plate 被新 token 复用清旧映射；迟到旧 removed 不清新状态。missing/forbidden 跳过；删组/规则停用旧组；删组清 token；重新加入复用但必须用当前 spec。按钮通常不销毁，不以受限按钮计数实施回收。

### 9.4 所有权

| 对象 | 所有者 / 数量 | 终止与复用 |
|---|---|---|
| eventFrame / aceDB | 核心，会话一个 | 不重复初始化；profile 回调重载引用。 |
| states[plate][index] | 核心，plate 池×历史组高水位，无硬配额 | detach 清 token，组删停用。 |
| state.Slots | state，历史 spec 高水位 g1..gN | 多余安全组禁用。 |
| slot.Buttons | 官方池+插件视觉引用 | 仅许可期重皮，不读真实分配。 |
| compiledSpecs | 核心，当前 revision 公开缓存 | 配置更新/ReloadDB 清。 |
| pendingUpdate | 核心，最多一个零延迟 timer | 执行/立即刷新 Cancel、置 nil。 |
| SpellCatalog / scanFrame | utils，会话有界扫描 | 完成删 OnUpdate，限制时暂停。 |
| GUIFrame / hooks | options，惰性一个 | 隐藏复用，不重复 hook。 |
| GUI 进度 OnUpdate | options，GUI 可见且未 Ready | 关闭/完成移除。 |
| previewTicker | 核心，最多一个 0.5s ticker | StopPreview Cancel、置 nil。 |
| state.Preview | 每 state 一个 root+4 示例 | detach/stop 禁用绑定、隐藏复用。 |
| Binding 模板 | 编译 spec，公开样式配置 | 按钮内部复制；非共享真实时钟。 |

---

## 10. 性能与公开目录

### 10.1 扫描契约

`src/utils.lua:140-203` 扫描 1..2,000,000，Seed 先加默认/用户公开 ID。每帧循环在 debugprofilestop 差达到 **2 毫秒**让出；合作式预算，单 API 不保证小于 2ms。战斗/secret 暂停 nextID。每 5% 通知，结束 Ready=true/Running=false，移除 OnUpdate/触发 ready hook。

ByName[name][id] 保存 iconID（缺则134400），不保存单位 aura。Seed 可加范围外明确 ID，但不自动覆盖其全部同名等级。Ready 仅表示该有界扫描结束，不保证全部元数据已抵达/名称永久不变。

### 10.2 刷新与规模

- UpdateAllNameplates 清缓存、增 revision，至多一个 NewTimer(0)。
- GUI 传 true/false 在 Forever 无不同含义，不能说快/慢两条路径。
- 缓存键是组、单位类别、friendly、assist、helpful 授权信号、区域；仅公开数据。
- 当前无组数/规则数/样式数/Frame 池/配置大小硬限制。
- 扫描总耗时、raid CPU/内存、反复改样式高水位尚无游戏基准。
- 不新增每帧真实 aura 枚举、每 aura 普通 timer、GUID 无限缓存、重复 GUI hook/ticker、默认无限日志；限额必须说明是否丢弃规则，不能静默减功能。

---

## 11. UI、命令与模拟预览

### 11.1 GUI

惰性 `NAurasForever.GUIFrame`，709×445、DIALOG、中心上移80、可拖/约束屏幕；重开复用并回综合页。战斗不准 ShowGUI；已可见时自动隐藏，离战恢复。法术区有 UIPanelScrollFrameTemplate，不代表所有页面整体滚动；中文/缩放/长文本实测。拾色确认/透明度/取消写回与恢复，不用旧 RGB 重载。

### 11.2 页面

| 页 | 名称 / 构建函数 | 内容 |
|---|---|---|
| 1 | 综合 / GUICategory_1 | 自身、mine/黑名单、动画、仅目标、tooltip、敌友区域/例外、NPC；旧 tooltip/Masque 禁用。 |
| 2 | 大小和位置 / GUICategory_StyleAndPosition | 宽高/裁切、间距/偏移、挂接/父级/锚点/生长/排序、strata、目标 scale。 |
| 3 | 透明度 / GUICategory_Alpha | alpha、目标 alpha、无目标策略。 |
| 4 | 计时器文字 / GUICategory_Fonts | 显示/字体/字号/锚点/偏移/颜色/十分位阈值。 |
| 5 | 堆叠文字 / GUICategory_AuraStackFont | count、字体/大小/锚点/偏移/色。 |
| 6 | 图标边框 / GUICategory_Borders | 类型/路径/粗细、增减益色。 |
| 7 | 法术 / GUICategory_4 | 搜索/多选/导入/三态/对象/ID/组/尺寸/边框/glow/blink/导出/删除。 |
| 8 | 打断 / GUICategory_Interrupts | 不可用公告。 |
| 9 | 净化/偷取 / GUICategory_Dispel | fallback、尺寸/glow、黑名单、区域。 |
| 10 | 附加 / GUICategory_Additions | DR/Explosive/Spiteful 不可用公告。 |
| 11 | Icon groups / GUICategory_IconGroups | 复制当前组新增/删除；至少一组，不复制规则 membership。 |
| 12 | Forever 限制 / GUICategory_Forever | 安全/筛选/黑名单/目录/旧能力说明。 |

法术搜索：名称、#group:<整数>、#enabled、#disabled、#buff、#debuff。目录未就绪时新增/依赖目录控件禁用，未解析现有规则仍可显示/选中，ID 允许 nil。ChatEdit_InsertLink 安全 hook 只对可见聚焦输入填名称，不替换聊天函数，不读取 aura。

### 11.3 Profiles / Settings

主表 NameplateAuras_Forever 显示 NameplateAuras Forever；子表 NameplateAuras_Forever.profiles。AddToBlizOptions 的 Profiles 父名必须是 addonTable.DISPLAY_NAME，不能传内部 addonName 导致父分类不存在。Profiles 按钮打开 AceConfigDialog 后隐藏自有 GUI。

### 11.4 命令与 LDB

| 入口 | 行为 |
|---|---|
| /naurasf / /nameplateaurasforever | 打开 GUI。 |
| /naurasf test | 开/关合成预览。 |
| /naurasf ver | 打印插件版本、Interface、安全容器说明。 |
| /naurasf import-default-spells | 强制处理默认批次、Seed/刷新，不覆盖用户同名规则。 |
| 其他文本 | 首词大小写精确分支，未知打开 GUI；非多参数 CLI。 |
| LDB 左键 / 右键 | 开关 GUI / 开关预览。 |

LDB 对象名 NameplateAuras_Forever，不自行绘制独立小地图按钮，宿主决定展示。

### 11.5 不可用控件

打断/DR/Explosive/Spiteful 公告；旧 tooltip/Masque/consolidate 禁用；custom Lua 排序正常入口不可执行，字符串保留；glow/blink 阈值隐藏并跳过三态阈值，旧模式不复现。官方新 API 真正解锁后需新证据/验收再恢复控件。

### 11.6 合成预览

- 非战斗/非 secret 才准开启；已开启总可请求停止。
- 每有 unit 的 state 4 个普通自有 Frame，示例法术 ID 为 139/118/122/642；纹理由公开法术缓存取得，缺失时使用 134400；count 空/2/3/4，时长15/30/45/60秒。
- 0.5s ticker，13 秒重启时间循环，非13秒自动关闭。
- 反映部分组级尺寸/间距/位置/字体/count/time/边框/目标 scale。
- 不读当前编辑规则、不演示规则 override/自定义边框/glow/blink/真实匹配/层数；root 固定 HIGH，alpha/父级/区域不完全同真实容器。
- 停止：再次 test、ReloadDB/profile/整导入、ENTERING_WORLD、REGEN_DISABLED、restriction 非 Inactive、ticker发现许可失败。
- StopPreview 取消 ticker、禁用绑定、隐藏 root、恢复真实刷新；单 plate 移除不停止全局 ticker。

**GUI Close/Profiles/LDB 左键隐藏当前不关闭预览**。没有姓名板时全局预览也可保持。若要求关 GUI 自动停，属于需确认/测试的行为变更。

---

## 12. 运行时能力源码验证

本次仅写文档，无新增/变更 API、事件、模板、Timer、hook 或 UI 调用。以下为关键基线证据，不是所有嵌入库动态路径均完整审计的声明。

`core` 指 `src/NameplateAuras.lua`，`utils` 指 `src/utils.lua`；API/BAC 前缀按 §0.2 展开。

### 12.1 核心与安全边界

| 能力 | 实际位置 | 目标源码证据 | 签名/返回/保护前提 | 游戏验收 |
|---|---|---|---|---|
| GetBuildInfo | core:7 | `API/BuildDocumentation.lua:10-21` | 第四值 Interface；门禁不是范围内全测试。 | GT-01 |
| C_XMLUtil.GetTemplateInfo | core:10 | `API/XMLUtilDocumentation.lua:11-25` | name 字符串，可能无结果。 | GT-01 |
| IsLoggedIn | core:780 | `API/PlayerScriptDocumentation.lua:1389-1397` | bool；已登录加载仍幂等。 | GT-02 |
| GetNamePlateForUnit / GetNamePlates | core:563,590 | `API/NamePlateDocumentation.lua:10-45` | missing/forbidden 跳过；不是 aura 读取授权。 | GT-03 |
| plate.unitToken | core:592 | `SRC/Interface/AddOns/Blizzard_NamePlates/Blizzard_NamePlateBase.lua:29-39` | 公开绑定字段；备用 UnitFrame.unit 使用前检查。 | GT-03 |
| 模块与安全全局导出 | TOC:7 | `BAC/Blizzard_AuraContainer.toc:7-32`；`BAC/Blizzard_AuraContainerShared.lua:250-273` | SecureEnvironment/global inbound 导出不让插件进入安全环境。 | GT-01 |
| CustomAuraContainerTemplate / CustomAuraButtonTemplate | core:426 / 官方 FrameProvider | `BAC/Blizzard_CustomAuraContainer.xml:4-17`；`BAC/Blizzard_CustomAuraButton.xml:4-10` | secureDelegates / inbound partition。 | GT-01,GT-10 |
| SetUnit / SetEnabled | core:425-429,546-583 | `BAC/Blizzard_AuraContainer.lua:22-48` | 空 token 解绑；禁用不销毁。 | GT-03 |
| AddAuraGroup / SetAuraGroupFilterString / CandidateFilters / SortMethod / Layout / Enabled | core:445-468 | `BAC/Blizzard_CustomAuraContainer.lua:286-415` | 唯一 key、合法 filter、公开候选，不查询真实计数。 | GT-05..07 |
| initializeFrame / 分批创建 / 访问限制 | core:447-451 | `BAC/Blizzard_AuraContainerFrameProviders.lua:75-99`；`BAC/Blizzard_AuraContainerShared.lua:101-108` | 回调先于限制；batch=10 不代表真实数量。 | GT-10,GT-11 |
| Inbound 后代/父级/动画验证 | core:315-423 | `BAC/Blizzard_AuraContainerUtil.lua:311-419` | 禁 protected/forbidden；收养后不 reparent/解除 secret。 | GT-10,GT-11 |
| 官方候选身份与谓词 | core:230-284 的配置 | `BAC/Blizzard_AuraContainerUtil.lua:52-172` | include 拒绝、exclude 可能忽略、NeverSecret 例外、isStealable。 | GT-05,GT-06 |
| FlowLayout 配置方法 | core:305-313 | `BAC/Blizzard_AuraContainerFlowLayout.lua:7-65` | Axis/AnchorPoint/GrowthDirection/MaximumLineSize；公开布局。 | GT-07 |
| AuraContainerSortMethod / Direction | core:446,459-460 | `BAC/Blizzard_AuraContainerShared.lua:40-57`；`BAC/Blizzard_CustomAuraContainer.lua:401-407` | ExpirationOnly/AuraInstanceIDOnly，Normal，组内排序。 | GT-07 |
| UpdateAllAuras | core:498 | `BAC/Blizzard_ManagedAuraContainer.lua:63-67` | 延迟重皮恢复后的客户端刷新。 | GT-11 |
| SetIcon / ApplicationCount / DurationCooldown / DurationText / DispelTypeTexture 及清除 | core:364-408 | `BAC/Blizzard_CustomAuraButton.lua:87-249` | 后代对象合法；binding 配置复制到内部。 | GT-08,GT-09 |
| AddAuraShownAnimation / ClearAuraShownAnimations | core:409-421 | `BAC/Blizzard_CustomAuraButton.lua:327-338` | 收养动画/目标仍受限制。 | GT-09,GT-11 |
| 系统 tooltip | core:367-370 | `BAC/Blizzard_AuraButton.lua:22-88` | motion/click/anchor 公共选项，受限信息不保证。 | GT-09 |
| CanCompareUnitTokens / ShouldUnitComparisonBeSecret / ShouldUnitIdentityBeSecret / ShouldAurasBeSecret | core:90-98,134-138；utils:183 | `API/SecretPredicateAPIDocumentation.lua:12-26,119-127,272-319` | 目标/身份/样式门禁，不绕过身份策略。 | GT-10,GT-11 |
| UnitIsUnit | core:96 | `API/UnitDocumentation.lua:2410-2426` | ComparableTokens/SecretWhenComparisonRestricted，结果再验 secret。 | GT-04,GT-10 |
| UnitIsFriend / UnitCanAssist / UnitIsPlayerControlledOrGroupMember | core:130,232-234 | `API/UnitDocumentation.lua:1977-1990,745-761,2287-2301` | 三者文档返回 bool；传入公开 unit token。assist 的 immune/uninteractable 均 true，group-member 按布尔真值使用；不能由 SecretArguments 标签推断此公开调用返回单位字符串或必为 secret。 | GT-05,GT-06 |
| UnitIsPlayer / UnitIsOtherPlayersPet | core:113-117 | `API/UnitDocumentation.lua:2271-2285,2193-2206` | 公开类型谓词，不解析 GUID。 | GT-04 |
| UnitExists / UnitName | core:126,136,484 | `API/UnitDocumentation.lua:1191-1205,2488-2504` | UnitExists返回bool；UnitName有身份限制标签，先guard再检查secret/nil，不比较受限名字。 | GT-03,GT-04,GT-10 |
| InCombatLockdown | core:91；utils:183；options:5949 | `API/RestrictedActionsDocumentation.lua:44-53` | bool，战斗门禁不代替独立aura secret检查。 | GT-10,GT-11 |
| GetInstanceInfo | core:108 | `API/InstanceDocumentation.lua:103-117` | 第2/8值类型/ID，不假定历史映射完备。 | GT-04 |
| 过滤串 token | core:258-283 | `SRC/Interface/AddOns/Blizzard_FrameXMLUtil/AuraUtil.lua:270-320` | HELPFUL/HARMFUL/PLAYER/INCLUDE_NAME_PLATE_ONLY；PLAYER 含宠物/载具。 | GT-05,GT-06 |
| C_Spell.GetSpellInfo / GetSpellTexture | utils:11-35,149-175；spells | `API/SpellDocumentation.lua:416-430,595-612` | 公开 spellIdentifier，找不到 nil/nothing；非单位 aura。 | GT-12,GT-13 |
| issecretvalue | core:97,137 | `API/FrameScriptDocumentation.lua:286-302` | bool 检查，不格式化原 secret。 | GT-10 |
| debugprofilestop | utils:184-188 | `API/FrameScriptDocumentation.lua:532-541` | 毫秒计时，合作式预算。 | GT-12 |
| 禁普通 aura 读取 | INV-004/008 | `API/SecretPredicatesDocumentation.lua:48-52`；`API/UnitAuraDocumentation.lua:645-655` | RequiresUnitAuraAccess 失败 Error；UNIT_AURA 可 secret。 | GT-10 |
| 禁普通 combat log | INV-004/011 | `API/CombatLogDocumentation.lua:130-136`；`API/CombatLogSecureDocumentation.lua:1-9` | COMBAT_LOG_EVENT_UNFILTERED 标记 HasRestrictions；C_CombatLogSecure 为 SecureOnly。项目禁止注册/读取这些路径，不能拿其中一项证明另一项完整权限规则。 | GT-10 |

### 12.2 时间、Frame 与 UI 支撑

本表列出实际调用点和对应证据；未列出的标准库动态路径不因注册点存在而自动通过 Gate。

| 能力 | 实际调用点 | 目标/库证据 | 边界与用途 |
|---|---|---|---|
| `CreateNumericRuleFormatter/SetBreakpoints` | core:147,155 | `API/StringUtilDocumentation.lua:21-29`；`API/NumericRuleFormatterAPIDocumentation.lua:60-69`；`API/NumericRuleFormatterSharedDocumentation.lua:6-42` | threshold/step/div/Up 公开配置。 |
| `CreateDuration/CreateDurationTextBinding` | core:171,684 | `API/DurationUtilDocumentation.lua:10-29` | 工厂返回自有 Duration/Binding；真实 aura duration 由按钮内部取得。 |
| Binding formatter/color/update/zero/expired | core:171-176 | `API/DurationTextBindingObjectAPIDocumentation.lua:271-378` | 0.1秒是插件显式配置，不是客户端默认；不读 secret。 |
| `Assign/SetDuration/SetFontString/SetEnabled/Disable` | core:555,703-706,728,379 | `API/DurationTextBindingObjectAPIDocumentation.lua:10-20,73-81,249-292`；`BAC/Blizzard_CustomAuraButton.lua:178-217,397-399,598-613` | 真路径用按钮内部 Binding；自有预览直接设自有 duration/fontstring。 |
| `SetTimeFromEnd/GetTime` | core:703,739,743 | `API/LuaDurationObjectAPIDocumentation.lua:431-443`；`API/SystemTimeDocumentation.lua:56-64` | 公开 endTime/duration、可选modRate默认1；GetTime为number，仅自有预览时间基，非真实 aura 算术。 |
| `DurationTextBindingProperty` | core:163,169 | `API/DurationTextBindingSharedDocumentation.lua:6-21` | RemainingDuration=0、RemainingPercent=1；代码使用枚举名。 |
| `CreateColorCurve/LuaCurveType` | core:157-168 | `API/CurveUtilDocumentation.lua:10-29`；`API/LuaCurveObjectConstantsDocumentation.lua:6-16` | 相对Linear/绝对Step，整点实测。 |
| `PreserveAsset` | core:386 | `API/AuraContainerSharedDocumentation.lua:18-31` | 保留现有纹理资产的dispel样式枚举。 |
| `CooldownFrameTemplate` | core:321 | `SRC/Interface/AddOns/Blizzard_FrameXMLUtil/Mainline/Cooldown.xml:3-10` | 按钮后代，初始hidden由绑定管理。 |
| `SetCooldownFromDurationObject/SetDrawSwipe/SetDrawEdge/SetHideCountdownNumbers/SetReverse` | core:322,361,704,377 | `API/FrameAPICooldownDocumentation.lua:307-318,400-421,460-469,491-500`；`BAC/Blizzard_CustomAuraButton.lua:159-173,598-606` | 样式setter在新建/许可期直接配置自有Cooldown；真实duration经SetDurationCooldown委托；带protected标记的duration直接调用只用于自有预览，需实测。 |
| FrameLevel/strata/alpha/scale | core:324,485-487 | `API/SimpleFrameAPIDocumentation.lua:421-433,1134-1147,1281-1306,1472-1484` | 新overlay/容器样式，不能借getter访问secret后代。 |
| Font/TextColor/Shadow | core:327,347-352 | `API/SimpleFontStringAPIDocumentation.lua:500-521,620-645,675-687` | 新对象/许可期样式。 |
| TexCoord/VertexColor | core:331,358,700 | `API/SimpleTextureBaseAPIDocumentation.lua:579-592`；`API/SimpleRegionAPIDocumentation.lua:190-203` | 公开裁切/色；动画target仍有secret aspect。 |
| mouse/parent/allpoints/point/size | core:317-330,345,367-370,480-482 | `API/SimpleScriptRegionAPIDocumentation.lua:630-663`；`API/SimpleScriptRegionResizingAPIDocumentation.lua:110-122,134-149,162-173` | layout方法有protected标记，调用上下文/对象前提要实测；收养对象不换父。 |
| `IsForbidden` | core:101,564,591 | `API/SimpleFrameScriptObjectAPIDocumentation.lua:241-255` | bool，ObjectSecurity aspect可使返回受限；当前在plate/UnitFrame仅条件判断，不格式化结果。不能当作所有对象始终公开的证明。 |
| AnimationGroup/Alpha | core:335-341,414-419 | `API/SimpleAnimatableObjectAPIDocumentation.lua:10-23`；`API/SimpleAnimGroupAPIDocumentation.lua:10-24,316-328`；`API/SimpleAnimAlphaAPIDocumentation.lua:38-60`；`API/SimpleAnimAPIDocumentation.lua:308-338` | BOUNCE、1→0.35、0.5秒，由客户端收养播放。 |
| `C_Timer.After/NewTicker/NewTimer` 与句柄 Cancel | core:506,526,723,741,768；options延迟处理 | `API/UITimerDocumentation.lua:10-37,54-69`；`SRC/Interface/AddOns/Blizzard_SharedXMLBase/TimedCallback.lua:7-21`；`SRC/Interface/AddOns/Blizzard_SharedXMLBase/ObjectUpdater.lua:5-12,26-29` | 生成文档不单列Cancel；后两者证明Blizzard使用返回timer/ticker的Cancel模式，非插件使用这些Mixin；实际取消/重复回调仍GT验收。 |
| Settings Canvas | core:655-657 | `SRC/Interface/AddOns/Blizzard_Settings_Shared/Blizzard_Settings.lua:134-173`；`libs/AceConfig-3.0/AceConfigDialog-3.0/AceConfigDialog-3.0.lua:1987-2045` | 父名按显示名解析，重复/错父名报错。 |
| 颜色拾取器 | dropdown库颜色构造/回调、options拾色控件 | `API/SimpleTextureBaseAPIDocumentation.lua:403-415`；`SRC/Interface/AddOns/Blizzard_ColorPickerFrame/Mainline/ColorPickerFrame.lua:96-102,158-174` | ColorTexture、RGB/alpha、confirm/cancel；库完整路径非单行证明。 |
| dropdown/scroll模板 | options:2322,5607,5932 | `SRC/Interface/AddOns/Blizzard_Menu/Mainline/MenuTemplates.xml:3-10`；`SRC/Interface/AddOns/Blizzard_SharedXML/Mainline/UIDropDownMenuTemplates.xml:146-154`；`SRC/Interface/AddOns/Blizzard_SharedXML/SecureScrollTemplates.xml:44-50` | 继承GUI，Classic/Mainline具体路由/滚动仍实测。 |
| BackdropTemplate | options:5700,5744 | `SRC/Interface/AddOns/Blizzard_SharedXML/Backdrop.xml:5-11` | 普通GUI后景。 |
| `ChatEdit_InsertLink` hook | options:301,2372,5383 | `SRC/Interface/AddOns/Blizzard_DeprecatedChatInfo/Deprecated_ChatFrame.lua:32-48`；`SRC/Interface/AddOns/Blizzard_ChatFrameBase/Mainline/ChatFrameUtilOverrides.lua:14-78` | 旧全局是ChatFrameUtil.InsertLink别名，非生成API；参数text，nil返回false；只安全追加观察。别名加载/Family和Camelot覆盖路径仍实测，不代表未来版本必保留。 |
| AceDB profile/回调 | core:646-649 | `libs/AceDB-3.0/AceDB-3.0.lua:267-288` | 角色键/已有映射，非共享Default。 |
| 私有dropdown注册 | options:8 | `libs/LibRedDropdown-1.0/LibRedDropdown-1.0.lua:7-9` | 独立rev24；注册不证明全部动态行为。 |

`options` 指 `src/options-dialog.lua`。普通 GUI 的其他继承控件/历史延迟路径、聊天模块加载路由与标准库动态分支须按后续涉及范围补证；不能把本表或 inventory 当成完整形式化证明。`ChatEdit_InsertLink` 已有别名/函数源码，不能因生成API无条目而说源码不存在。

### 12.3 事件 payload 源码

| 事件组 | 官方文件 |
|---|---|
| LOGIN / ENTERING_WORLD | `API/SystemDocumentation.lua:133-155` |
| ADDED / REMOVED | `API/NamePlateManagerDocumentation.lua:117-147` |
| REGEN_DISABLED / ENABLED | `API/UnitDocumentation.lua:3884-3895` |
| TARGET_CHANGED | `API/UnitDocumentation.lua:3973-3978` |
| FACTION / FLAGS | `API/UnitDocumentation.lua:4256-4275` |
| ZONE_CHANGED_NEW_AREA | `API/MapDocumentation.lua:662-667` |
| RESTRICTION_STATE_CHANGED | `API/RestrictedActionsDocumentation.lua:96-106` |

---

## 13. 自动化验收与当前结果

### 13.1 已执行基线

建立本 SPEC 实际执行：

```bash
python3 -B -m unittest discover -s '/Users/zhangtong09/catpaw desk/wow-plugins/NameplateAuras_Forever/tests' -p 'test_*.py' -v
```

结果 `Ran 91 tests ... OK`：

| 套件 | 数量 | 覆盖 | 不证明 |
|---|---|---|---|
| test_package.py | 12 | 加载图/边界/循环/编码，57文件真实Lua5.1编译，分支/版本、literal证据、隔离/库媒体。 | secret引擎、真实事件、全部法术/UI。 |
| test_runtime.py + lua | 68 | 各例独立Lua5.1进程；参数mock、生命周期、候选配置、迁移/回滚、延迟重皮、预览/目录。 | 私有匹配/taint/保护执行/绘制。 |
| test_ui.py + lua | 11 | 真实嵌入库构造、12页、拾色/dropdown/进度、Profiles父类、私有库仲裁。 | 真实字体/屏幕/全部点击滚动/战斗。 |

编译器 `$HOME/.local/bin/luac5.1` 报 Lua 5.1.5。编译不执行顶层；runtime/UI 在隔离mock执行所需代码，非客户端。

另对 core/utils/database 三文件执行无配置/无缓存 `luacheck --std lua51` 并显式允许其 WoW 全局，结果 **0 warnings / 0 errors**。不包含整旧 GUI/全部库，不能称整个插件零 warning。

原 TBC 指纹与上次交付一致。本次无实现改动。指纹口径为各文件 shasum 输出按固定 locale 排序后再 SHA-256。

### 13.2 通用预检的真实限制

本次版本画像/预检：Interface 匹配、TOC 文件无缺；但：

- runtime_game_type=tbc / target=WoW TBC Anniversary 是通用工具默认标签，不能将 Forever 解读为 TBC。
- `wow-plugins/api_changes_index.json` 仍为 classic_anniversary / 2.5.x，与 Forever 1.60 不匹配。
- 通用依赖查找器未在普通插件根解析 Blizzard_AuraContainer；它实际在 SRC/Interface/AddOns 下，按官方源码另核。
- preflight 报 API_INDEX_UNVERIFIED、REQUIRED_DEPENDENCY_UNVERIFIED、继承 GUI/库 lint warning，最终 **INCONCLUSIVE**。

不修改 TBC 索引/Skill/白名单伪造 PASS。项目套件通过不覆盖这些项，也不是新的整插件正式发布审计结论。

### 13.3 需求到现有测试

名称取自真实套件；Lua 用例的 test_ 前缀由 Python 添加。

| 需求 | 代表现有用例 | 游戏 |
|---|---|---|
| F-001 / 隔离 | test_runtime_version_interface_and_git_branch、test_blizzard_dependency_and_no_plater、test_saved_variables_slash_locale_and_media_isolation、saved_variables_are_independent_and_defaults_retained | GT-01,02,19 |
| F-002 / 回收 | unit_added_removed_reuses_state_without_real_aura_reads、late_old_unit_removed_cannot_clear_reused_plate、same_unit_token_reassigned_to_new_plate_detaches_previous、deleted_group_container_clears_unit_token、group_readd_reuses_state_and_replaces_current_spec | GT-03,17 |
| F-003 / 显示 | target_filter_and_secret_comparison_fail_closed、friendly_enemy_and_zone_predicate_filters、actor_player_pet_npc_and_membership_predicates、npc_blacklist_secret_nil_and_secret_name_fail_closed | GT-04,10 |
| F-004/005 | `all_explicit_name_rules_include_ranks_and_dynamic_index_updates`、`two_legal_same_name_rank_rules_are_not_deleted`、`check_spell_id_number_never_expands`、`check_spell_id_string_never_expands`、`check_spell_id_empty_table_never_expands`、`check_spell_id_all_false_never_expands`、`check_spell_id_invalid_string_never_expands` | GT-05,12,13 |
| F-006/007 | only_mine_rules_use_player_not_pet_candidate、all_rules_do_not_add_player_filter、all_false_blacklists_do_not_block_mine_or_dispel、nonempty_mine_blacklist_has_no_identity_fallback、nonempty_dispel_blacklist_fails_closed、mine_and_dispel_candidates_are_disjoint_for_stealable_buffs、blacklist_permission_uses_assist_not_friendliness | GT-06 |
| F-008/009 | group_add_delete_reorder_reuses_state_without_stale_units、removed_rule_disables_all_old_aura_groups；布局/排序配置mock | GT-07 |
| F-010 | client_formatter_preserves_ceil_and_tenths_contract、disabled_stacks_clear_the_client_application_binding、time_and_stacks_render_above_cooldown_without_reparenting | GT-08 |
| F-011 / 安全 | secret_style_refresh_never_touches_existing_buttons、new_secret_group_initialization_callback_is_allowed、combat_style_refresh_defers_and_recovers_once、secret_recovery_coalesces_and_skins_only_once、secret_skin_recovery_requests_client_assignment_rebuild、runtime_events_never_read_unit_aura_guid_or_combat_log | GT-09..11 |
| F-012 | damaged_profile_import_is_rejected_before_mutating_live_db、single_spell_import_validates_shape_and_preserves_live_profile、profile_import_rolls_back_when_reload_fails、valid_profile_import_keeps_false_and_independent_input、malformed_optional_spell_fields_are_rejected、malformed_blacklist_keys_are_rejected_without_commit | GT-14,15 |
| F-013 | `migration_0_preserves_values_and_is_repeatable`、`migration_22_preserves_values_and_is_repeatable`、`migration_34_preserves_values_and_is_repeatable`、`migration_35_preserves_values_and_is_repeatable`、`future_db_does_not_rerun_zero_or_one_migration`、`sparse_groups_and_membership_are_remapped`、`legacy_sort_and_anchor_strings_migrate_before_modern_validation`、`legacy_false_glow_does_not_become_permanent_glow`、`unknown_spell_id_recovers_when_public_metadata_arrives`、`ui_valid_target_scale_eight_survives_import_and_reload` | GT-13..15 |
| F-014 | gui_real_initialization_twelve_categories、gui_catalog_progress_ready_and_show_hide_lifecycle、gui_unready_spell_rule_page_and_unresolved_name、gui_real_colorpicker_callback_updates_and_restores_profile、aceconfigdialog_real_parent_registration_and_wrong_parent_rejection | GT-16,18 |
| F-015 | preview_start_blocked_in_combat_or_secret、preview_close_cancels_ticker_and_bindings、preview_auto_stops_on_player_entering_world、preview_auto_stops_on_player_regen_disabled、profile_reload_stops_preview、preview_secret_transition_stops_without_button_access | GT-18 |
| F-016 / 旧能力标签 | `test_core_forbidden_events_and_apis` 覆盖核心禁用路径；12页UI初始化不证明每个禁用控件交互，需GT补足。 | GT-21 |
| 性能/语法/编码 | config_changes_coalesce_at_most_one_timer、catalog_scans_only_limited_budget_and_pauses_when_restricted、test_lua51_syntax_loaded_graph_only、test_loaded_files_exist_utf8_without_bom | GT-12,20 |
| 私有库/颜色 | test_copied_libraries_and_media_byte_identical、colorpicker_real_constructor_confirm_opacity_cancel、mock_rejects_rgb_texture_overload_and_missing_methods、private_dropdown_library_cannot_replace_original_registration | GT-16,19 |

`only_mine_rules_use_player_not_pet_candidate` 只检查 `PLAYER` 不拼额外 `PET`，不能推出不含宠物。`preview_close_cancels_ticker_and_bindings` 只检查 `test` 关闭预览，不证明 GUI Close 停预览。迁移用例名的 34/35 是输入 `DBVersion`，不表示存在编号 34/35 的迁移函数。

### 13.4 可复现命令

主要回归：

```bash
cd '/Users/zhangtong09/catpaw desk/wow-plugins/NameplateAuras_Forever'
python3 -B -m unittest discover -s tests -p 'test_*.py' -v
```

单套定位：

```bash
python3 -B tests/test_package.py -v
python3 -B tests/test_runtime.py -v
python3 -B tests/test_ui.py -v
```

版本/通用检查，当前未确证原因不能省略：

```bash
git -C '/Users/zhangtong09/catpaw desk/wow-plugins/wow-ui-source' status --short --branch
git -C '/Users/zhangtong09/catpaw desk/wow-plugins/wow-ui-source' log -1 --format='%h %s'
python3 '/Users/zhangtong09/catpaw desk/.catpaw/skills/wow-tbc-plugin-sdd/scripts/addon_runtime_profile.py' '/Users/zhangtong09/catpaw desk/wow-plugins/NameplateAuras_Forever'
python3 '/Users/zhangtong09/catpaw desk/.catpaw/skills/wow-tbc-plugin-sdd/scripts/addon_capability_inventory.py' '/Users/zhangtong09/catpaw desk/wow-plugins/NameplateAuras_Forever'
python3 '/Users/zhangtong09/catpaw desk/.catpaw/skills/wow-tbc-plugin-sdd/scripts/addon_preflight.py' '/Users/zhangtong09/catpaw desk/wow-plugins/NameplateAuras_Forever' --lua51 "$HOME/.local/bin/luac5.1"
```

工作区路径可按实际替换。缺真实 Lua5.1、错分支、缺证据必须失败/INCONCLUSIVE，不 skip 为成功，不改 mock 以放宽约束。

---

## 14. 游戏内验收矩阵

**本会话未执行以下游戏内验收**。实际栏在有客户端版本、操作、结果及必要截图/完整错误栈之前保持待测。

### 14.1 环境与记录

先用目标 `1.60.1.70862 / Interface 16001`、仅本插件的环境，再做其他 addon 组合。记录实际 GetBuildInfo；备份 Forever 和原 TBC SV，不为测试删除原配置。需要真实姓名板与真实 aura，不能只用 test。示例 ID 若游戏不可用先记录，不能以未经验证的“类似法术”替代证据。

可启用 Lua 错误提示并 reload；blocked action、secret 错误与完整栈不能隐藏。测试记录格式：用例 ID、插件/客户端版本、配置摘要、对象/区域/战斗状态、最小步骤、期望、实际、错误/截图、测试日期。

### 14.2 操作 → 期望 → 实际

| ID | 最小操作 / 场景 | 期望与判定 | 实际 |
|---|---|---|---|
| GT-01 | 仅装 Forever、Plater 缺席，登录检查版本/Settings。 | 无加载错误；版本与模块正确，不要求原 TBC 包。 | 待测 |
| GT-02 | 首次/重复进入世界、reload、重复开关配置。 | 幂等、存档稳定，无重复 slash/分类/ticker。 | 待测 |
| GT-03 | 姓名板出入距离、同 plate/token 复用、快速消失。 | 不串单位、不残留；迟到旧 token 不清新状态。 | 待测 |
| GT-04 | NPC/玩家/宠物/自身、目标/敌友切换、世界/副本/战场。 | 对象/区域/目标例外按配置；受限比较不扩大显示。 | 待测 |
| GT-05 | 敌方减益/友方增益显式 ID 和同名多等级，再试友方减益/敌方增益。 | 授权范围按规则；不可身份筛选非例外不显示，不全量替代；NeverSecret 仅官方例外。 | 待测 |
| GT-06 | mine+净化、玩家/宠物来源、可/不可偷取、黑名单、控制队友。 | PLAYER 官方来源语义，mine/dispel 互斥；不可靠黑名单关闭 broad 组，无假净化。 | 待测 |
| GT-07 | 多组/样式、四向、目标 scale=8/10、父级/healthbar、各排序。 | 布局/层级正确；组内排序，不声称跨样式时间全排序；无旧组残留。 | 待测 |
| GT-08 | 刷新/到期/永久、堆叠变化、T=0/10、颜色与秒/分钟/3600边界。 | §6期望；正数不假零；count/time 高于遮罩；动画/数字/count 独立。 | 待测 |
| GT-09 | 内置/自定义边框、驱散类型、永久 glow、always blink、tooltip。 | 统一安全外观，无旧阈值效果，无 reparent/blocked action，tooltip按官方许可。 | 待测 |
| GT-10 | 战斗/地牢/PvP 新 aura/新姓名板，启用 target-only/NPC blacklist。 | 无 secret 读取/算术/普通 aura事件或保护违规；允许显示的安全 aura 继续。 | 待测 |
| GT-11 | 限制前改样式，限制中经可能的公开配置/profile路径更新，解除观察。 | 已有按钮受限不访问；延迟恢复不丢失，不重复动画/绑定。 | 待测 |
| GT-12 | 新会话目录扫描，进入/退出战斗，GUI关/开。 | 扫描暂停/恢复；GUI进度关闭停更新；完成不重复；记录总耗时。 | 待测 |
| GT-13 | 未解析历史 ID、同名 rank、显式空/全 false、默认批次。 | 保留用户规则，空ID不扩大；可信 ID 公开元数据抵达能恢复；逐项登记默认有效性。 | 待测 |
| GT-14 | 当前有效 profile 导出→导入→reload，Profiles复制/切换/重置。 | 可用设置稳定，false/scale=8保留，profile互不共享，旧 SV 不变。 | 待测 |
| GT-15 | 真实旧TBC导出、三通道色/旧sort/anchor/ID表示；坏编码/畸形结构/未来版本。 | 已支持旧表示按schema迁移；失败明确且有效配置不污染；未知兼容性不假称成功。 | 待测 |
| GT-16 | 逐页点击、长法术列表搜索滚动、字体、拾色透明度与取消。 | 12页可达、文本/控件无裁切；拾色取消恢复；战斗开窗拒绝。 | 待测 |
| GT-17 | 新增/删除/重加组、规则跨组、多次调整、reload。 | 成员与组索引一致，已删容器清token，当前组选择有效。 | 待测 |
| GT-18 | test 开/关、关闭GUI、Profiles、LDB、进战斗/区域/restriction。 | 仅4合成图，不宣称真实匹配；按§11.6停止；GUI关闭目前仍预览，重开不新建多ticker。 | 待测 |
| GT-19 | 旧dropdown宿主先/后加载、标准Ace不同版本、可选Masque有/无。 | 私有修复不替换旧注册；自身SV/命令独立，无加载顺序副作用。 | 待测 |
| GT-20 | 多姓名板/多规则，反复进出距离/改样式，观察 CPU/内存。 | 不新增重复timer/每帧真实读取；记录规模/高水位，不凭目测宣称性能达标。 | 待测 |
| GT-21 | 导入启用打断/DR/阈值glow/合并/custom sort/Masque等旧配置。 | 明确不可用、存档可保留；不执行旧脚本/伪造图标或未授权效果。 | 待测 |

### 14.3 通过条件与回退

- 受本次变更影响的 GT 项必须有实际记录，无新增加载/保护/secret错误、串板或存档破坏。
- 因官方禁止显示而不显示是边界，不能以绕过限制“修复”；与源码授权条件不符则登记缺陷。
- 新版本若迁移配置，回退旧插件前先恢复匹配的备份；不假定旧版本无损读取未来 schema。
- 仅替换 Forever 包，不修改原 TBC 包。不可恢复数据、未证实API、真实保护错误属于发布阻断。

---

## 15. 已知限制、差异与候选迭代

下面是当前风险/设计边界登记，不表示本次已修复或用户已授权开发。

| ID | 类型 | 当前事实 / 证据 | 下一步判定 |
|---|---|---|---|
| K-001 | 官方身份限制 | include非例外拒绝、exclude可能忽略；`BAC/Blizzard_AuraContainerUtil.lua:52-111`。 | 保持fail-closed；需新官方API证据才能扩展。 |
| K-002 | 默认目录未验证 | 177条历史默认包含多版本ID；名称加载时求值，nil跳过，计数仍推进；spells:32-218/db:935-979。 | 按实际公开元数据/职业场景建验证清单，不断言全部无效/有效。 |
| K-003 | 全等级/晚到元数据 | 有界扫描2,000,000、部分提前生效，Ready非所有信息已就绪；utils:140-203。 | 实测总耗时、扫描完成后晚到信息/范围外ID；必要时新扫描策略。 |
| K-004 | 预览有限 | 不模拟规则glow/blink、区域/alpha/strata不完全同真；core:672-747。 | 可另设计组级/规则级预览，但始终自有合成。 |
| K-005 | GUI关闭不停止预览 | options Close/Profiles/LDB仅Hide；core test才StopPreview。 | 若要自动停止，明确需求并加GUI关闭路径回归。 |
| K-006 | 无可信ID的损坏规则 | FillInMissing用集合key填 unresolvedSpellID，现代列表key不一定是法术ID；db:575-582,820-831。 | 不据此猜名称/恢复任意规则；后续明确来源/隔离损坏条目。 |
| K-007 | 未来schema容错 | 已有 >34 SV不重跑老迁移，但仍补全/归一化；db:711-818。 | 定义明确只读/拒绝/备份机制，不能承诺无损向后。 |
| K-008 | 全局排序/重复 | 样式分组，跨组无全真实时间排序，显式重复无全局优先级；core:230-297。 | 若改优先级先限制为公开规则编译，不能读secret去重。 |
| K-009 | 第三方挂接缺口 | TPTP UI有历史选项，核心仅plate/healthbar；core:100-105。 | 若需要真正集成，单独TOC/版本/hook/回收证据。 |
| K-010 | 输入防护不完整 | 部分ID形状修复、未知字段保留，无完整深度/大小/循环/范围校验；db:833-933。 | 新安全输入策略要列拒绝/修复兼容边界与无污染反例。 |
| K-011 | 资源/性能未量化 | 多组/规则/Frame高水位无硬配额；目录合作式预算非硬实时。 | 客户端测CPU/内存/总耗时，再设计不静默丢规则的限额。 |
| K-012 | UI/标准库组合 | 私有dropdown隔离，Ace标准名仍仲裁；全部GUI/字体/不同库版本未游戏验证。 | GT-16/19，修改加载图或库必须新证据/回归。 |
| K-013 | 工具适用性 | 通用TBC索引/依赖定位导致INCONCLUSIVE；§13.2。 | 有单独需求再适配Forever工具链，不改老索引伪造通过。 |
| K-014 | 单条/整配置事务不同 | 单条只准备后追加，整profile包含reload回滚；db:927-933/core:598-614。 | 如需原子单条UI应用，单独定义事务及失败测试。 |
| K-015 | 中性/控制单位与区域时序 | hostile/friendly授权并非同一谓词；缓存依赖配置revision与单位事件；core:230-239,753-773。 | GT-04/06/10覆盖控制/区域切换，必要时补明确invalidate触发。 |

保留旧功能：打断/DR/Explosive/Spiteful、合并、custom Lua排序、阈值glow/blink、旧tooltip模式、Masque动态皮肤。要恢复须通过新API Gate，不以UI文案或历史表证明能力。

---

## 16. 后续持续迭代规约

### 16.1 三种版本不要混同

- 插件 Version：用户可见发布版本；TOC与core版本打印同步。
- DBVersion：数据迁移版本；仅持久化结构/迁移变化推进，当前34。
- SPEC版本：规格修订版本；可以仅更新文档而不动插件/DB。

目标源码分支/版本变化时重读 version.txt，重新核API、事件、保护策略；不通过只改TOC来宣称支持。

### 16.2 每次变更流程

1. 在本SPEC登记 `CHG-*`、关联F/INV/K、目的和不做什么。
2. 先列输入/输出、状态、失败路径、UI/字段/schema、性能与最小GT验收；缺需求只做最小可回答澄清。
3. API/事件/模板/hook/依赖变化先目标源码Gate，更新§12与JSON证据；不凭memory选API。
4. 先加失败/边界回归再实现；缺实际引擎模拟时明确静态覆盖限制。
5. 只改Forever必要文件；涉及新文件/依赖同步TOC/XML/加载图、私有库打包策略。
6. 重跑实际回归、Lua5.1、lint/预检，记录原始命令/输出；不降低不变量来得绿。
7. 正式功能变化委派独立只读对抗审计，提供最终SPEC/源码、画像、原始结果、API证据、旧/新配置样本。
8. 受影响GT逐项操作→期望→实际；无法执行保留待测。
9. 更新文档版本/变更登记/状态。用户未请求不提交git、不发布/同步知识库、不改Skill/原TBC。

### 16.3 变更等级

| 等级 | 例子 | 要求 |
|---|---|---|
| 文档澄清 | 本次逆向SPEC、补事实或验证记录 | 事实核对；不据此扩展实现/发布结论。 |
| 机械小修 | 不改变行为的拼写/确定常量错误 | 局部依据与回归，别顺带重构。 |
| 正式行为变更 | 新规则/默认/格式/UI/Timer/schema/API/依赖 | 完整SPEC→证据→实现/回归→独立审计→GT。 |
| 探索实验 | 用户明确先试试、能力无完整证据 | 不进正式TOC/正式声明；先隔离最小实验，成功再正式规格。 |

### 16.4 完成定义

- [ ] 已写CHG、F/INV/K关系、边界与可执行验收。
- [ ] 实际涉及能力均有当前源码路径/行号/签名/保护前提。
- [ ] 新加载/依赖/schema/版本与SPEC一致，原TBC未改。
- [ ] 受影响回归和Lua5.1实际通过；warn/INCONCLUSIVE不隐藏。
- [ ] 有迁移样本：首次/当前/旧版/损坏/未来/false/稀疏/重载/回滚。
- [ ] 没有新增secret读取、算术、普通UNIT_AURA、GUID、重复ticker或自定义排序执行。
- [ ] UI变化包含真实点击/滚动/颜色取消/战斗恢复，不只截图。
- [ ] 独立审计范围与证据完整；BLOCK/INCONCLUSIVE不当成通过。
- [ ] 实际GT记录或GAME_TEST_REQUIRED清单，不写假实测。
- [ ] 更新SPEC/JSON/测试映射/已知问题；不遗留临时文件。

### 16.5 发布结论语义

| 状态 | 语义 |
|---|---|
| PASS | 相关证据/检查/审计完整，无未处理阻断；不自动意味着所有游戏组合已实测。 |
| GAME_TEST_REQUIRED | 静态审计范围可成立，但指定真实行为需GT；必须带待测清单。 |
| BLOCK | 明确错误、不支持API、保护/加载/存档问题，不发布。 |
| INCONCLUSIVE | 缺输入、目标版本/工具不适用或证据不足，不宣称通过。 |

本次是文档交付，记录项目回归通过与通用预检未确证，并保留游戏待测；不重新宣布整个插件获得PASS/GAME_TEST_REQUIRED发布Gate。

---

## 17. 变更与验收记录

### 17.1 已登记变更

| ID | 日期 | SPEC / 插件 / DB | 内容 | 验证 |
|---|---|---|---|---|
| CHG-001 | 2026-11-08 | 1.0 / 16001.1-forever / 34 | 建立当前功能/安全/配置/迁移/事件/性能/UI/证据/回归/GT/迭代完整基线，未改实现。 | 91/91回归、57 Lua5.1编译、核心3文件lint零warn；通用preflight INCONCLUSIVE；GT未执行。 |

后续记录按本表追加真实条目；不要用候选路线替代变更历史，也不虚构既往发布/实测。

### 17.2 每次变更必须补齐的字段

| 字段 | 内容要求 |
|---|---|
| ID / 日期 / 版本 | 唯一CHG、实际日期、SPEC/插件/DB/目标客户端版本。 |
| 目的与非目标 | 用户要求、关联F/INV/K，不顺带做的事项。 |
| 行为差异 | 前后输入/输出、边界、失败/回退；是否改变默认/显示范围。 |
| 数据与兼容 | 新旧字段、迁移编号、false/nil/未来版本策略、旧样本。 |
| API/事件/资源 | §12新增证据、payload、限制、Timer/缓存所有权。 |
| 自动化 | 真实命令与原始输出位置、用例名、范围、结论。 |
| 独立审计 | 日期/范围/输入/发现/结论，非开发者自批通过。 |
| 游戏记录 | GT用例、环境、步骤、期望/实际、错误栈/截图；没跑写待测。 |
| 发布/回退 | 安装范围、备份与schema回退风险、尚未关闭的K项。 |

### 17.3 当前未关闭的验收状态

| 项目 | 状态 |
|---|---|
| 当前功能/安全/配置基线规格 | 已建立 |
| 项目回归与Lua5.1 | 已执行通过 |
| 核心三文件lint | 已执行零warning；非全插件lint结论 |
| 通用TBC preflight对Forever适用性 | INCONCLUSIVE，K-013 |
| 真实光环匹配/secret引擎/保护执行 | 待游戏验收 |
| 12页真实布局/字体/全部交互 | 待游戏验收 |
| 真实旧SV/Profile跨reload | 待游戏验收 |
| 默认ID有效性/目录总耗时/性能 | 待专项验证 |
| 候选K项 | 登记边界，不等于已获准开发 |

本SPEC是后续协作基线；事实变化时修订对应章节与证据，不靠会话记忆维持兼容性。
