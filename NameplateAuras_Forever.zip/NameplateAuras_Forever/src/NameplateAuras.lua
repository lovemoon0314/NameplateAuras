-- luacheck: no max line length
-- luacheck: globals LibStub CreateFrame UIParent C_NamePlate C_Spell C_Secrets C_Timer C_XMLUtil C_StringUtil C_CurveUtil C_DurationUtil Enum AnchorUtil
-- luacheck: globals GameTooltip GetBuildInfo GetTime GetInstanceInfo UnitExists UnitIsUnit UnitIsFriend UnitIsPlayer UnitIsOtherPlayersPet UnitCanAssist UnitIsPlayerControlledOrGroupMember UnitName InCombatLockdown issecretvalue CreateColor IsLoggedIn
-- luacheck: globals SlashCmdList SLASH_NAMEPLATEAURASFOREVER1 SLASH_NAMEPLATEAURASFOREVER2 date AuraContainerSortMethod AuraContainerSortDirection hooksecurefunc

local addonName, addonTable = ...;
local interfaceVersion = select(4, GetBuildInfo());
local version = "16001.1-forever";
local L = LibStub("AceLocale-3.0"):GetLocale(addonName);

if (interfaceVersion < 16001 or interfaceVersion >= 20000 or not C_XMLUtil.GetTemplateInfo("CustomAuraContainerTemplate")) then
	local function UnsupportedClient()
		addonTable.Print("此版本仅支持 Forever 客户端及其官方安全光环容器。TBC 请使用原版 NameplateAuras。");
	end
	addonTable.ShowGUI, addonTable.SwitchTestMode = UnsupportedClient, UnsupportedClient;
	UnsupportedClient();
	return;
end

local SML = LibStub("LibSharedMedia-3.0");
local DISABLED, MINE = addonTable.CONST_SPELL_MODE_DISABLED, addonTable.CONST_SPELL_MODE_MYAURAS;
local BUFF, DEBUFF, ANY = addonTable.AURA_TYPE_BUFF, addonTable.AURA_TYPE_DEBUFF, addonTable.AURA_TYPE_ANY;
local db, aceDB, initialized;
local states, visibleByUnit = {}, {};
local configRevision = 0;
local compiledSpecs = {};
local pendingUpdate;
local previewTicker, previewActive, previewStarted;
local previewContextRevision = 0;
local instanceType = addonTable.INSTANCE_TYPE_NONE;
local RefreshState, ConfigureState, StopPreview, RefreshPreview, HidePreview;
addonTable.Nameplates = states;
addonTable.AllAuraIconFrames = {};

function addonTable.GetIconGroupDefaultOptions(name)
	return {
		IconGroupName = name or L["Icon group"] .. " " .. date("%Y-%m-%d-%H-%M-%S"),
		ShowAurasOnPlayerNameplate = false,
		IconXOffset = 0, IconYOffset = 50,
		Font = "NAurasForever_TeenBold", SortMode = addonTable.AURA_SORT_MODE_EXPIRETIME,
		FontScale = 1, TimerTextUseRelativeScale = true, TimerTextSize = 20,
		TimerTextAnchor = "CENTER", TimerTextAnchorIcon = "CENTER", TimerTextXOffset = 0, TimerTextYOffset = 0,
		TimerTextSoonToExpireColor = {1, 0.1, 0.1, 1}, TimerTextUnderMinuteColor = {1, 1, 0.1, 1}, TimerTextLongerColor = {0.7, 1, 0, 1},
		StacksFont = "NAurasForever_TeenBold", StacksFontScale = 1,
		StacksTextAnchor = "BOTTOMRIGHT", StacksTextAnchorIcon = "BOTTOMRIGHT", StacksTextXOffset = -3, StacksTextYOffset = 5,
		StacksTextColor = {1, 0.1, 0.1, 1},
		ShowBuffBorders = true, BuffBordersColor = {0, 1, 0, 1}, ShowDebuffBorders = true,
		DebuffBordersMagicColor = {0.1, 1, 1, 1}, DebuffBordersCurseColor = {1, 0.1, 1, 1},
		DebuffBordersDiseaseColor = {1, 0.5, 0.1, 1}, DebuffBordersPoisonColor = {0.1, 1, 0.1, 1}, DebuffBordersOtherColor = {1, 0.1, 0.1, 1},
		IconSpacing = 1, IconAnchor = addonTable.ICON_ALIGN_BOTTOM_LEFT,
		OnlyShowMyAuras = false, AlwaysShowMyAuras = false, AlwaysShowMyAurasBlacklist = {}, NpcBlacklist = {},
		BorderThickness = 2, FrameAnchor = "CENTER", FrameAnchorToNameplate = "CENTER", MinTimeToShowTenthsOfSeconds = 10,
		InterruptsEnabled = false, InterruptsIconSizeWidth = 45, InterruptsIconSizeHeight = 45,
		InterruptsGlowType = addonTable.GLOW_TYPE_ACTIONBUTTON_DIM, InterruptsUseSharedIconTexture = false, InterruptsShowOnlyOnPlayers = true,
		Additions_ExplosiveOrbs = false, ShowAuraTooltip = false, Additions_DispellableSpells = false,
		Additions_Dispel_InstanceTypes = {
			[addonTable.INSTANCE_TYPE_NONE] = true, [addonTable.INSTANCE_TYPE_UNKNOWN] = true,
			[addonTable.INSTANCE_TYPE_PVP] = true, [addonTable.INSTANCE_TYPE_PVP_BG_40PPL] = true,
			[addonTable.INSTANCE_TYPE_ARENA] = true, [addonTable.INSTANCE_TYPE_PARTY] = true,
			[addonTable.INSTANCE_TYPE_RAID] = true, [addonTable.INSTANCE_TYPE_SCENARIO] = true,
		},
		Additions_DispellableSpells_Blacklist = {}, DispelIconSizeWidth = 45, DispelIconSizeHeight = 45,
		Additions_DispellableSpells_GlowType = addonTable.GLOW_TYPE_PIXEL,
		IconGrowDirection = addonTable.ICON_GROW_DIRECTION_RIGHT,
		ShowStacks = true, ShowCooldownText = true, ShowCooldownAnimation = true,
		IconAlpha = 1, IconAlphaTarget = 1, IconScaleTarget = 1, TargetStrata = "HIGH", NonTargetStrata = "MEDIUM",
		BorderType = addonTable.BORDER_TYPE_BUILTIN,
		BorderFilePath = "Interface\\AddOns\\NameplateAuras_Forever\\media\\custom-example.tga",
		DefaultIconSizeWidth = 45, DefaultIconSizeHeight = 45, IconZoom = 0.07,
		CustomSortMethod = "function(aura1, aura2) return aura1.spellName < aura2.spellName; end",
		Additions_DRPvP = false, Additions_DRPvE = false, ShowOnlyOnTarget = false,
		UseTargetAlphaIfNotTargetSelected = false, AffixSpiteful = false, AffixSpitefulSound = 5274,
		TimerTextUseRelativeColor = false, TimerTextColorZeroPercent = {1, 0.1, 0.1, 1}, TimerTextColorHundredPercent = {0.1, 1, 0.1, 1},
		KeepAspectRatio = true, UseDefaultAuraTooltip = true, MasqueEnabled = false, NameplateIsParent = false, ShowCooldownSwipeEdge = true,
		FriendlyUnitsAurasEnabledZoneTypes = {
			[addonTable.INSTANCE_TYPE_NONE] = true, [addonTable.INSTANCE_TYPE_UNKNOWN] = true,
			[addonTable.INSTANCE_TYPE_PVP] = true, [addonTable.INSTANCE_TYPE_PVP_BG_40PPL] = true,
			[addonTable.INSTANCE_TYPE_ARENA] = true, [addonTable.INSTANCE_TYPE_PARTY] = true,
			[addonTable.INSTANCE_TYPE_RAID] = true, [addonTable.INSTANCE_TYPE_SCENARIO] = true,
		},
		EnemyUnitsAurasEnabledZoneTypes = {
			[addonTable.INSTANCE_TYPE_NONE] = true, [addonTable.INSTANCE_TYPE_UNKNOWN] = true,
			[addonTable.INSTANCE_TYPE_PVP] = true, [addonTable.INSTANCE_TYPE_PVP_BG_40PPL] = true,
			[addonTable.INSTANCE_TYPE_ARENA] = true, [addonTable.INSTANCE_TYPE_PARTY] = true,
			[addonTable.INSTANCE_TYPE_RAID] = true, [addonTable.INSTANCE_TYPE_SCENARIO] = true,
		},
		ShowAurasOnEnemyTargetEvenInDisabledAreas = false, ShowAurasOnAlliedTargetEvenInDisabledAreas = false,
		AttachType = addonTable.ATTACH_TYPE_NAMEPLATE,
	};
end

local function CanRestyleButtons()
	return not InCombatLockdown() and not C_Secrets.ShouldAurasBeSecret();
end

local function IsUnit(unit, other)
	if (not C_Secrets.CanCompareUnitTokens(unit, other) or C_Secrets.ShouldUnitComparisonBeSecret(unit, other)) then return false; end
	local result = UnitIsUnit(unit, other);
	return not issecretvalue(result) and result == true;
end

function addonTable.GetNameplateAddonFrame(plate, iconGroup)
	if (iconGroup.AttachType == addonTable.ATTACH_TYPE_HEALTHBAR and plate.UnitFrame and not plate.UnitFrame:IsForbidden()) then
		return plate.UnitFrame.HealthBarsContainer or plate;
	end
	return plate;
end

local function UpdateInstanceType()
	local _, kind, _, _, _, _, _, id = GetInstanceInfo();
	if (kind == "pvp" and addonTable.EPIC_BG_ZONE_IDS[id]) then kind = addonTable.INSTANCE_TYPE_PVP_BG_40PPL; end
	instanceType = kind or addonTable.INSTANCE_TYPE_UNKNOWN;
end

local function UnitKind(unit)
	if (UnitIsPlayer(unit)) then return addonTable.UNIT_TYPE_PLAYER; end
	if (UnitIsOtherPlayersPet(unit) or IsUnit(unit, "pet")) then return addonTable.UNIT_TYPE_PET; end
	return addonTable.UNIT_TYPE_NPC;
end

local function HasEnabledValue(values)
	for _, enabled in pairs(values) do if (enabled) then return true; end end
	return false;
end

local function ShouldShowState(state)
	local unit, group = state.Unit, db.IconGroups[state.Index];
	if (not group or not unit or not UnitExists(unit)) then return false; end
	local isTarget = IsUnit(unit, "target");
	if (IsUnit(unit, "player") and not group.ShowAurasOnPlayerNameplate) then return false; end
	if (group.ShowOnlyOnTarget and not isTarget) then return false; end
	local friendly = UnitIsFriend("player", unit);
	local zoneEnabled = friendly and group.FriendlyUnitsAurasEnabledZoneTypes[instanceType] or not friendly and group.EnemyUnitsAurasEnabledZoneTypes[instanceType];
	local targetOverride = friendly and group.ShowAurasOnAlliedTargetEvenInDisabledAreas or not friendly and group.ShowAurasOnEnemyTargetEvenInDisabledAreas;
	if (not zoneEnabled and not (isTarget and targetOverride)) then return false; end
	if (not UnitIsPlayer(unit) and HasEnabledValue(group.NpcBlacklist)) then
		if (C_Secrets.ShouldUnitIdentityBeSecret(unit)) then return false; end
		local name = UnitName(unit);
		if (issecretvalue(name) or name == nil or group.NpcBlacklist[name]) then return false; end
	end
	return true;
end

local function ApplyContainerStyle(root, state, group)
	local anchor = addonTable.GetNameplateAddonFrame(state.Plate, group);
	root:ClearAllPoints();
	root:SetParent(group.NameplateIsParent and anchor or UIParent);
	root:SetPoint(group.FrameAnchor, anchor, group.FrameAnchorToNameplate, group.IconXOffset, group.IconYOffset);
	local target = IsUnit(state.Unit, "target");
	local targetExists = UnitExists("target");
	root:SetAlpha((target or not targetExists and group.UseTargetAlphaIfNotTargetSelected) and group.IconAlphaTarget or group.IconAlpha);
	root:SetScale(target and group.IconScaleTarget or 1);
	root:SetFrameStrata(target and group.TargetStrata or group.NonTargetStrata);
end

local function Color(value)
	return CreateColor(value[1], value[2], value[3], value[4] or 1);
end

local function BuildTimePresentation(group)
	local formatter = C_StringUtil.CreateNumericRuleFormatter();
	local rounding = Enum.NumericRuleFormatRounding.Up;
	local threshold = group.MinTimeToShowTenthsOfSeconds;
	local rules = {};
	if (threshold > 0) then rules[#rules+1] = {threshold = 0, step = 0.1, rounding = rounding, format = "%.1f"}; end
	if (threshold < 60) then rules[#rules+1] = {threshold = threshold, step = 1, rounding = rounding, format = "%.0f"}; end
	rules[#rules+1] = {threshold = 60, format = "%dm", components = {{div = 60, step = 1, rounding = rounding}}};
	rules[#rules+1] = {threshold = 3600.000001, format = ""};
	formatter:SetBreakpoints(rules);

	local curve = C_CurveUtil.CreateColorCurve();
	local property;
	if (group.TimerTextUseRelativeColor) then
		curve:SetType(Enum.LuaCurveType.Linear);
		curve:AddPoint(0, Color(group.TimerTextColorZeroPercent));
		curve:AddPoint(1, Color(group.TimerTextColorHundredPercent));
		property = Enum.DurationTextBindingProperty.RemainingPercent;
	else
		curve:SetType(Enum.LuaCurveType.Step);
		curve:AddPoint(0, Color(group.TimerTextSoonToExpireColor));
		curve:AddPoint(5, Color(group.TimerTextUnderMinuteColor));
		curve:AddPoint(60, Color(group.TimerTextLongerColor));
		property = Enum.DurationTextBindingProperty.RemainingDuration;
	end
	local binding = C_DurationUtil.CreateDurationTextBinding();
	binding:SetFormatter(formatter);
	binding:SetTextColorCurve(curve, property);
	binding:SetUpdateInterval(0.1);
	binding:SetZeroDurationText("");
	binding:SetExpiredText("");
	return binding;
end

local function GetStyle(group, entry)
	entry = entry or {};
	local style = {
		Width = entry.overrideSize and entry.iconSizeWidth or group.DefaultIconSizeWidth,
		Height = entry.overrideSize and entry.iconSizeHeight or group.DefaultIconSizeHeight,
		BorderType = group.BorderType, BorderSize = group.BorderThickness, BorderPath = group.BorderFilePath,
		Glow = entry.showGlow == addonTable.GLOW_TIME_INFINITE and entry.glowType ~= nil and entry.glowType ~= addonTable.GLOW_TYPE_NONE,
		Blink = entry.animationDisplayMode == addonTable.ICON_ANIMATION_DISPLAY_MODE_ALWAYS,
	};
	if (entry.customBorderType and entry.customBorderType ~= addonTable.BORDER_TYPE_DISABLED) then
		style.BorderType, style.BorderSize, style.BorderPath = entry.customBorderType, entry.customBorderSize, entry.customBorderPath;
		style.BorderColor = entry.customBorderColor;
	end
	local c = style.BorderColor or {};
	style.Signature = table.concat({style.Width, style.Height, style.BorderType, style.BorderSize or 2, style.BorderPath or "", tostring(style.Glow), tostring(style.Blink), c[1] or "", c[2] or "", c[3] or "", c[4] or ""}, ":");
	return style;
end

local function ResolveIDs(entry)
	local ids = {};
	if (entry.checkSpellID ~= nil) then
		for id, enabled in pairs(type(entry.checkSpellID) == "table" and entry.checkSpellID or {}) do
			if (enabled and type(id) == "number" and addonTable.SpellNameByID[id] == entry.spellName) then ids[id] = true; end
		end
	else
		for id in pairs(addonTable.SpellCatalog.ByName[entry.spellName] or {}) do ids[id] = true; end
	end
	return ids;
end

local function BlacklistIDs(names)
	local ids = {};
	for name, enabled in pairs(names) do
		if (enabled) then
			for id in pairs(addonTable.SpellCatalog.ByName[name] or {}) do ids[id] = true; end
		end
	end
	return ids;
end

local function MatchesActor(entry, index, friendly, kind)
	if (not entry.iconGroups[index] or entry.enabledState == DISABLED) then return false; end
	if (friendly and not entry.showOnFriends or not friendly and not entry.showOnEnemies) then return false; end
	if (kind == addonTable.UNIT_TYPE_PLAYER) then return entry.showOnPlayers; end
	if (kind == addonTable.UNIT_TYPE_PET) then return entry.showOnPets; end
	return entry.showOnNpcs;
end

local function SortSpecs(specs, group)
	local mode = group.SortMode;
	table.sort(specs, function(a, b)
		if (mode == addonTable.AURA_SORT_MODE_AURATYPE_EXPIRE and a.Type ~= b.Type) then return a.Type == DEBUFF; end
		if (mode == addonTable.AURA_SORT_MODE_ICONSIZE) then
			local sizeA, sizeB = math.min(a.Style.Width, a.Style.Height), math.min(b.Style.Width, b.Style.Height);
			if (sizeA ~= sizeB) then return sizeA < sizeB; end
		end
		return a.Filter .. a.Style.Signature < b.Filter .. b.Style.Signature;
	end);
end

local function ApplySourceFilter(filter, group)
	if (group.OnlyShowMyAuras and not filter:find("|PLAYER", 1, true)) then
		return filter .. "|PLAYER";
	end
	return filter;
end

-- Groups are compiled solely from public spell metadata and user configuration.
-- The client, not this addon, owns aura identities and aura-to-button assignments.
local function BuildSpecs(index, unit)
	local group = db.IconGroups[index];
	local friendly, kind = UnitIsFriend("player", unit), UnitKind(unit);
	local canAssist = UnitCanAssist("player", unit, true, true);
	local canFilterHelpful = canAssist or UnitIsPlayerControlledOrGroupMember(unit);
	local cacheKey = table.concat({index, kind, tostring(friendly), tostring(canAssist), tostring(canFilterHelpful), instanceType}, ":");
	if (compiledSpecs[cacheKey]) then return compiledSpecs[cacheKey]; end
	local specs, bySignature, explicitIDs = {}, {}, {[BUFF] = {}, [DEBUFF] = {}};
	local hasDispelBlacklist = HasEnabledValue(group.Additions_DispellableSpells_Blacklist);
	local showDispel = group.Additions_DispellableSpells and not friendly and group.Additions_Dispel_InstanceTypes[instanceType] and not hasDispelBlacklist;
	local function Add(filter, auraType, entry, ids, candidate, keySuffix)
		filter = ApplySourceFilter(filter, group);
		local style = GetStyle(group, entry);
		local signature = filter .. ":" .. style.Signature .. ":" .. (keySuffix or "explicit");
		local spec = bySignature[signature];
		if (not spec) then
			spec = {Signature = signature, Filter = filter, Type = auraType, Style = style, Candidate = candidate or {includeSpellIDs = {}}, Group = group, Binding = BuildTimePresentation(group)};
			bySignature[signature] = spec;
			specs[#specs+1] = spec;
		end
		if (ids) then
			for id in pairs(ids) do spec.Candidate.includeSpellIDs[id] = true; explicitIDs[auraType][id] = true; end
		end
	end

	for _, entry in pairs(db.CustomSpells2) do
		if (MatchesActor(entry, index, friendly, kind)) then
			local ids = ResolveIDs(entry);
			if (next(ids)) then
				local mine = entry.enabledState == MINE and "|PLAYER" or "";
				if (entry.auraType == ANY or entry.auraType == DEBUFF) then Add("HARMFUL|INCLUDE_NAME_PLATE_ONLY" .. mine, DEBUFF, entry, ids); end
				if (entry.auraType == ANY or entry.auraType == BUFF) then Add("HELPFUL|INCLUDE_NAME_PLATE_ONLY" .. mine, BUFF, entry, ids); end
			end
		end
	end

	if (group.AlwaysShowMyAuras) then
		local hasBlacklist = HasEnabledValue(group.AlwaysShowMyAurasBlacklist);
		for _, auraType in ipairs({DEBUFF, BUFF}) do
			local excluded = BlacklistIDs(group.AlwaysShowMyAurasBlacklist);
			for id in pairs(explicitIDs[auraType]) do excluded[id] = true; end
			local identityAllowed = auraType == DEBUFF and not canAssist or auraType == BUFF and canFilterHelpful;
			if (not hasBlacklist or identityAllowed and addonTable.SpellCatalog.Ready) then
				local filter = auraType == DEBUFF and "HARMFUL" or "HELPFUL";
				local candidate = {excludeSpellIDs = excluded};
				if (showDispel and auraType == BUFF) then candidate.isStealable = false; end
				Add(filter .. "|PLAYER|INCLUDE_NAME_PLATE_ONLY", auraType, nil, nil, candidate, "mine");
			end
		end
	end

	if (showDispel) then
		local entry = {overrideSize = true, iconSizeWidth = group.DispelIconSizeWidth, iconSizeHeight = group.DispelIconSizeHeight,
			showGlow = addonTable.GLOW_TIME_INFINITE, glowType = group.Additions_DispellableSpells_GlowType};
		Add("HELPFUL|INCLUDE_NAME_PLATE_ONLY", BUFF, entry, nil, {isStealable = true, excludeSpellIDs = explicitIDs[BUFF]}, "dispel");
	end

	SortSpecs(specs, group);
	compiledSpecs[cacheKey] = specs;
	return specs;
end

local anchors = {
	[addonTable.ICON_ALIGN_BOTTOM_LEFT] = {"BOTTOMLEFT", "BOTTOMRIGHT", "BOTTOMLEFT", "TOPLEFT"},
	[addonTable.ICON_ALIGN_TOP_RIGHT] = {"TOPLEFT", "TOPRIGHT", "BOTTOMRIGHT", "TOPRIGHT"},
	[addonTable.ICON_ALIGN_CENTER] = {"LEFT", "RIGHT", "BOTTOM", "TOP"},
};

local function GetLayoutOptions(group)
	local direction = group.IconGrowDirection;
	local vertical = direction == addonTable.ICON_GROW_DIRECTION_UP or direction == addonTable.ICON_GROW_DIRECTION_DOWN;
	return vertical and AnchorUtil.FlowLayoutAxis.Vertical or AnchorUtil.FlowLayoutAxis.Horizontal,
		anchors[group.IconAnchor][direction],
		direction == addonTable.ICON_GROW_DIRECTION_LEFT and AnchorUtil.FlowDirection.Left or AnchorUtil.FlowDirection.Right,
		direction == addonTable.ICON_GROW_DIRECTION_UP and AnchorUtil.FlowDirection.Up or AnchorUtil.FlowDirection.Down;
end

local function ApplyLayout(container, group)
	local axis, point, horizontal, vertical = GetLayoutOptions(group);
	container:SetFlowLayoutAxis(axis);
	container:SetFlowLayoutAnchorPoint(point);
	container:SetFlowLayoutGrowthDirection(horizontal, vertical);
	container:SetFlowLayoutMaximumLineSize(math.huge);
end

local function CreateVisuals(button)
	local v = {};
	v.Texture = button:CreateTexture(nil, "BORDER");
	v.Texture:SetAllPoints(button);
	v.BuffBorder = button:CreateTexture(nil, "OVERLAY"); v.BuffBorder:SetAllPoints(button);
	v.DebuffBorder = button:CreateTexture(nil, "OVERLAY"); v.DebuffBorder:SetAllPoints(button);
	v.Cooldown = CreateFrame("Cooldown", nil, button, "CooldownFrameTemplate");
	v.Cooldown:SetAllPoints(button); v.Cooldown:SetReverse(true); v.Cooldown:SetHideCountdownNumbers(true); v.Cooldown.noCooldownCount = true;
	v.Overlay = CreateFrame("Frame", nil, button);
	v.Overlay:SetAllPoints(button); v.Overlay:SetFrameLevel(v.Cooldown:GetFrameLevel() + 1);
	v.Count = v.Overlay:CreateFontString(nil, "OVERLAY");
	v.Time = v.Overlay:CreateFontString(nil, "OVERLAY");
	v.Time:SetShadowColor(0, 0, 0, 1); v.Time:SetShadowOffset(1, -1);
	v.Glow = v.Overlay:CreateTexture(nil, "OVERLAY");
	v.Glow:SetTexture(addonTable.BORDER_TEXTURES[2]);
	v.Glow:SetPoint("TOPLEFT", button, "TOPLEFT", -3, 3); v.Glow:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", 3, -3);
	v.Glow:SetVertexColor(1, 0.65, 0.1, 1);
	return v;
end

local function CreatePulse(region)
	local animations = region:CreateAnimationGroup();
	animations:SetLooping("BOUNCE");
	local alpha = animations:CreateAnimation("Alpha");
	alpha:SetFromAlpha(1); alpha:SetToAlpha(0.35); alpha:SetDuration(0.5); alpha:SetOrder(1);
	return animations;
end

local function ApplyVisualStyle(button, v, spec)
	local style, group = spec.Style, spec.Group;
	button:SetSize(style.Width, style.Height);
	local size = math.min(style.Width, style.Height);
	v.Time:SetFont(SML:Fetch("font", group.Font), group.TimerTextUseRelativeScale and math.ceil(size / 2 * group.FontScale) or group.TimerTextSize, "OUTLINE");
	v.Time:ClearAllPoints(); v.Time:SetPoint(group.TimerTextAnchor, button, group.TimerTextAnchorIcon, group.TimerTextXOffset, group.TimerTextYOffset);
	v.Count:SetFont(SML:Fetch("font", group.StacksFont), math.ceil(size / 4 * group.StacksFontScale), "OUTLINE");
	v.Count:ClearAllPoints(); v.Count:SetPoint(group.StacksTextAnchor, button, group.StacksTextAnchorIcon, group.StacksTextXOffset, group.StacksTextYOffset);
	local countColor = group.StacksTextColor;
	v.Count:SetTextColor(countColor[1], countColor[2], countColor[3], countColor[4]);
	local x, y = group.IconZoom, group.IconZoom;
	if (group.KeepAspectRatio) then
		local aspect = style.Width / style.Height;
		if (aspect > 1) then y = 0.5 - (0.5 - y) / aspect; elseif (aspect < 1) then x = 0.5 - (0.5 - x) * aspect; end
	end
	v.Texture:SetTexCoord(x, 1-x, y, 1-y);
	for _, border in ipairs({v.BuffBorder, v.DebuffBorder}) do
		border:ClearAllPoints();
		if (style.BorderType == addonTable.BORDER_TYPE_BLIZZARD) then
			-- Preserve the official 25px nameplate icon's overlay proportions.
			local xOffset, yOffset = 6 * style.Width / 25, 5 * style.Height / 25;
			border:SetAtlas(addonTable.BLIZZARD_BORDER_ATLAS, false);
			border:SetPoint("TOPLEFT", button, "TOPLEFT", -xOffset, yOffset);
			border:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", xOffset, -yOffset);
		else
			local texture = style.BorderType == addonTable.BORDER_TYPE_BUILTIN and addonTable.BORDER_TEXTURES[style.BorderSize] or style.BorderPath;
			border:SetTexture(texture);
			border:ResetTexCoord();
			border:SetAllPoints(button);
		end
	end
	v.Cooldown:SetDrawSwipe(group.ShowCooldownAnimation); v.Cooldown:SetDrawEdge(group.ShowCooldownAnimation and group.ShowCooldownSwipeEdge);
end

local function StyleAuraButton(button, v, spec)
	ApplyVisualStyle(button, v, spec);
	local group, style = spec.Group, spec.Style;
	button:SetMouseClickEnabled(false);
	button:SetMouseMotionEnabled(group.ShowAuraTooltip);
	button:SetHideTooltipInCombat(false);
	button:SetTooltipAnchorPoint("ANCHOR_RIGHT", 0, 0);
	button:SetIcon(v.Texture);
	if (group.ShowStacks) then
		button:SetApplicationCount(v.Count, {}); v.Count:Show();
	else
		button:ClearApplicationCount(); v.Count:Hide();
	end
	button:SetDurationCooldown(v.Cooldown);
	if (group.ShowCooldownText) then
		button:SetDurationText(v.Time, {binding = spec.Binding});
		v.Time:Show();
	else
		button:ClearDurationText(); v.Time:Hide();
	end
	button:ClearDispelTypeTextures();
	if (style.BorderType ~= addonTable.BORDER_TYPE_DISABLED) then
		local preserve = Enum.CustomAuraButtonDispelTypeTextureStyle.PreserveAsset;
		local function Options(harmful)
			local options = {style = preserve, showWithoutDispelType = true, showWhenHarmful = harmful, showWhenHelpful = not harmful};
			if (style.BorderColor) then
				local color = Color(style.BorderColor);
				options.customDispelColorMap = {None = color, Magic = color, Curse = color, Disease = color, Poison = color, Enrage = color, Bleed = color};
			elseif (harmful) then
				options.customDispelColorMap = {
					None = Color(group.DebuffBordersOtherColor), Magic = Color(group.DebuffBordersMagicColor),
					Curse = Color(group.DebuffBordersCurseColor), Disease = Color(group.DebuffBordersDiseaseColor),
					Poison = Color(group.DebuffBordersPoisonColor), Enrage = Color(group.DebuffBordersOtherColor), Bleed = Color(group.DebuffBordersOtherColor),
				};
			else
				local color = Color(group.BuffBordersColor);
				options.customDispelColorMap = {None = color, Magic = color, Curse = color, Disease = color, Poison = color, Enrage = color, Bleed = color};
			end
			return options;
		end
		if (group.ShowBuffBorders or style.BorderColor) then button:AddDispelTypeTexture(v.BuffBorder, Options(false)); else v.BuffBorder:Hide(); end
		if (group.ShowDebuffBorders or style.BorderColor) then button:AddDispelTypeTexture(v.DebuffBorder, Options(true)); else v.DebuffBorder:Hide(); end
	else
		v.BuffBorder:Hide(); v.DebuffBorder:Hide();
	end
	button:ClearAuraShownAnimations();
	if (v.GlowAnimation) then v.GlowAnimation:Stop(); end
	if (v.BlinkAnimation) then v.BlinkAnimation:Stop(); end
	v.Glow:SetShown(style.Glow);
	if (style.Glow) then
		v.GlowAnimation = v.GlowAnimation or CreatePulse(v.Glow);
		button:AddAuraShownAnimation(v.GlowAnimation);
	end
	if (style.Blink) then
		v.BlinkAnimation = v.BlinkAnimation or CreatePulse(v.Texture);
		button:AddAuraShownAnimation(v.BlinkAnimation);
	else
		v.Texture:SetAlpha(1);
	end
end

local function CreateState(plate, index)
	local container = CreateFrame("AuraContainer", nil, UIParent, "CustomAuraContainerTemplate");
	container:SetEnabled(false); container:SetUnit(""); container:Hide();
	local state = {Plate = plate, Index = index, Container = container, Slots = {}, Revision = -1};
	return state;
end

ConfigureState = function(state)
	local group = db.IconGroups[state.Index];
	if (not group or not state.Unit) then return; end
	local container = state.Container;
	local specs = BuildSpecs(state.Index, state.Unit);
	local canRestyle = CanRestyleButtons();
	ApplyLayout(container, group);
	for i, spec in ipairs(specs) do
		local key = "g" .. i;
		local slot = state.Slots[i];
		if (not slot) then
			slot = {Key = key, Spec = spec, Buttons = {}};
			state.Slots[i] = slot;
			container:AddAuraGroup(key, spec.Filter, {
				candidateFilters = spec.Candidate, sortMethod = AuraContainerSortMethod.ExpirationOnly,
				initializeFrame = function(button)
					local v = CreateVisuals(button);
					slot.Buttons[button] = v;
					StyleAuraButton(button, v, slot.Spec);
				end,
			});
		else
			slot.Spec = spec;
			slot.NeedsSkin = true;
		end
		container:SetAuraGroupFilterString(key, spec.Filter);
		container:SetAuraGroupCandidateFilters(key, spec.Candidate);
		local sortMethod = group.SortMode == addonTable.AURA_SORT_MODE_NONE and AuraContainerSortMethod.AuraInstanceIDOnly or AuraContainerSortMethod.ExpirationOnly;
		container:SetAuraGroupSortMethod(key, sortMethod, AuraContainerSortDirection.Normal);
		container:SetAuraGroupLayout(key, {elementSpacing = group.IconSpacing, groupSpacing = 0, elementWidth = spec.Style.Width, elementHeight = spec.Style.Height, layoutIndex = i});
		container:SetAuraGroupEnabled(key, true);
		if (canRestyle and slot.NeedsSkin) then
			for button, v in pairs(slot.Buttons) do StyleAuraButton(button, v, spec); end
			slot.NeedsSkin = false;
		end
	end
	for i = #specs + 1, #state.Slots do container:SetAuraGroupEnabled(state.Slots[i].Key, false); end
	state.Revision = configRevision;
end

RefreshState = function(state)
	local group = db.IconGroups[state.Index];
	if (not group or not state.Unit) then
		state.Unit = nil;
		state.Container:SetEnabled(false); state.Container:SetUnit(""); state.Container:Hide();
		HidePreview(state);
		return;
	end
	ApplyContainerStyle(state.Container, state, group);
	if (state.Revision ~= configRevision) then ConfigureState(state); end
	if (CanRestyleButtons()) then
		local reskinned = false;
		for _, slot in ipairs(state.Slots) do
			if (slot.NeedsSkin) then
				for button, v in pairs(slot.Buttons) do StyleAuraButton(button, v, slot.Spec); end
				slot.NeedsSkin = false;
				reskinned = true;
			end
		end
		if (reskinned) then state.Container:UpdateAllAuras(); end
	end
	local show = ShouldShowState(state) and not previewActive;
	state.Container:SetEnabled(show); state.Container:SetShown(show);
	if (previewActive) then RefreshPreview(state, true); end
end

local function RefreshAll()
	if (pendingUpdate) then pendingUpdate:Cancel(); pendingUpdate = nil; end
	if (not initialized) then return; end
	for unit, plate in pairs(visibleByUnit) do
		for index in ipairs(db.IconGroups) do
			local state = states[plate][index];
			if (not state) then state = CreateState(plate, index); states[plate][index] = state; end
			if (state.Unit ~= unit) then
				state.Unit = unit; state.Container:SetUnit(unit); state.Revision = -1;
			end
		end
	end
	for _, plateStates in pairs(states) do
		for _, state in pairs(plateStates) do RefreshState(state); end
	end
end

function addonTable.UpdateAllNameplates()
	if (addonTable.UpdatePreviewStatus) then addonTable.UpdatePreviewStatus(); end
	if (not initialized) then return; end
	compiledSpecs = {};
	configRevision = configRevision + 1;
	if (not pendingUpdate) then pendingUpdate = C_Timer.NewTimer(0, RefreshAll); end
end

function addonTable.RebuildSpellCache()
	if (not db) then return; end
	addonTable.SpellCatalog:Seed();
	addonTable.UpdateAllNameplates();
end

function addonTable.RebuildAuraSortFunctions()
	addonTable.UpdateAllNameplates();
end

function addonTable.OnSpellCatalogUpdated()
	if (addonTable.RecoverUnresolvedSpells) then addonTable.RecoverUnresolvedSpells(); end
	addonTable.UpdateAllNameplates();
end

hooksecurefunc(addonTable, "OnSpellInfoCachesReady", addonTable.OnSpellCatalogUpdated);

local function DetachUnit(unit)
	if (type(unit) ~= "string") then return; end
	local plate = visibleByUnit[unit];
	visibleByUnit[unit] = nil;
	if (not plate) then return; end
	for _, state in pairs(states[plate] or {}) do
		state.Unit = nil;
		state.Container:SetEnabled(false); state.Container:SetUnit(""); state.Container:Hide();
		HidePreview(state);
	end
end

local function AttachUnit(unit)
	if (type(unit) ~= "string") then return; end
	local plate = C_NamePlate.GetNamePlateForUnit(unit);
	if (not plate or plate:IsForbidden()) then return; end
	if (visibleByUnit[unit] and visibleByUnit[unit] ~= plate) then DetachUnit(unit); end
	states[plate] = states[plate] or {};
	local plateStates = states[plate];
	for _, state in pairs(plateStates) do
		if (state.Unit and state.Unit ~= unit) then visibleByUnit[state.Unit] = nil; end
	end
	visibleByUnit[unit] = plate;
	for index in ipairs(db.IconGroups) do
		local state = plateStates[index] or CreateState(plate, index);
		plateStates[index] = state;
		state.Unit = unit;
		state.Container:SetEnabled(false);
		state.Container:SetUnit(unit);
		state.Revision = -1;
		RefreshState(state);
	end
	for index, state in pairs(plateStates) do
		if (not db.IconGroups[index]) then
			state.Unit = nil; state.Container:SetEnabled(false); state.Container:SetUnit(""); state.Container:Hide();
			HidePreview(state);
		end
	end
end

local function SynchronizeNameplates()
	local oldUnits = {};
	for unit in pairs(visibleByUnit) do oldUnits[#oldUnits+1] = unit; end
	for _, unit in ipairs(oldUnits) do DetachUnit(unit); end
	for _, plate in pairs(C_NamePlate.GetNamePlates()) do
		if (not plate:IsForbidden()) then
			local unit = plate.unitToken or plate.UnitFrame and plate.UnitFrame.unit;
			if (type(unit) == "string" and unit ~= "") then AttachUnit(unit); end
		end
	end
end

function addonTable.ImportProfile(profile)
	local prepared, message = addonTable.PrepareProfileImport(profile);
	if (not prepared) then return false, message; end
	local original = addonTable.deepcopy(db);
	local function ReplaceProfile(values)
		for key in pairs(db) do db[key] = nil; end
		for key, value in pairs(values) do db[key] = value; end
	end
	ReplaceProfile(prepared);
	local success, failure = pcall(addonTable.ReloadDB);
	if (not success) then
		ReplaceProfile(original);
		pcall(addonTable.ReloadDB);
		return false, "配置导入失败，已恢复原配置：" .. tostring(failure);
	end
	return true;
end

function addonTable.ReloadDB()
	if (previewActive) then StopPreview("配置已重载；请重新开启预览查看新配置。"); end
	db = aceDB.profile;
	addonTable.db = db;
	addonTable.PrepareForeverProfile();
	addonTable.MigrateDB();
	addonTable.NormalizeForeverProfile();
	addonTable.ImportNewSpells();
	compiledSpecs = {};
	addonTable.SpellCatalog:Start();
	addonTable.RebuildSpellCache();
	addonTable.GuiOnProfileChanged();
	if (initialized) then
		for unit, plate in pairs(visibleByUnit) do
			for index in ipairs(db.IconGroups) do
				if (not states[plate][index]) then
					local state = CreateState(plate, index);
					state.Unit = unit; state.Container:SetUnit(unit); states[plate][index] = state;
				end
			end
		end
		addonTable.UpdateAllNameplates();
	end
end

local function Initialize()
	if (initialized) then return; end
	if (type(_G.NameplateAurasForeverAceDB) ~= "table") then _G.NameplateAurasForeverAceDB = {}; end
	local defaults = {profile = {DBVersion = addonTable.DB_SCHEMA_VERSION, DefaultSpellsLastSetImported = 0, CustomSpells2 = {}, IconGroups = {}}};
	addonTable.AceDBDefaults = addonTable.deepcopy(defaults);
	aceDB = LibStub("AceDB-3.0"):New("NameplateAurasForeverAceDB", defaults);
	aceDB.RegisterCallback(addonName, "OnProfileChanged", addonTable.ReloadDB);
	aceDB.RegisterCallback(addonName, "OnProfileCopied", addonTable.ReloadDB);
	aceDB.RegisterCallback(addonName, "OnProfileReset", addonTable.ReloadDB);
	local config = LibStub("AceConfig-3.0");
	local dialog = LibStub("AceConfigDialog-3.0");
	config:RegisterOptionsTable(addonName, {name = addonTable.DISPLAY_NAME, type = "group", args = {
		open = {type = "execute", name = "打开设置 /naurasf", func = addonTable.ShowGUI},
	}});
	dialog:AddToBlizOptions(addonName, addonTable.DISPLAY_NAME);
	config:RegisterOptionsTable(addonName .. ".profiles", addonTable.GetProfileOptions(aceDB));
	dialog:AddToBlizOptions(addonName .. ".profiles", L["Profiles"], addonTable.DISPLAY_NAME);
	SLASH_NAMEPLATEAURASFOREVER1 = "/naurasf";
	SLASH_NAMEPLATEAURASFOREVER2 = "/nameplateaurasforever";
	SlashCmdList.NAMEPLATEAURASFOREVER = function(message)
		local command = message:match("^%s*(%S+)");
		if (command == "test") then addonTable.SwitchTestMode();
		elseif (command == "ver") then addonTable.Print(version .. " / Interface " .. interfaceVersion .. " / 官方安全光环容器");
		elseif (command == "import-default-spells") then addonTable.ImportNewSpells(true); addonTable.RebuildSpellCache();
		else addonTable.ShowGUI(); end
	end;
	addonTable.ReloadDB();
	initialized = true;
	UpdateInstanceType();
end

-- Synthetic preview owns every frame, duration, count and animation below.
-- Public unit predicates select the presentation, never the real aura contents.
local previewSamples = {
	{ID = 139, Harmful = false, Remaining = 12, Duration = 30, Cycle = 8, WidthScale = 1, HeightScale = 1},
	{ID = 118, Harmful = true, Dispel = "Magic", Remaining = 45, Duration = 60, Cycle = 13, WidthScale = 0.6, HeightScale = 0.8},
	{ID = 122, Harmful = true, Dispel = "Other", Remaining = 4.8, Duration = 120, Cycle = 4, WidthScale = 1, HeightScale = 1},
	{ID = 642, Harmful = false, Remaining = 120, Duration = 120, Cycle = 13, WidthScale = 0.8, HeightScale = 0.6},
};
local previewDispelTypes = {"Magic", "Curse", "Disease", "Poison", "Other"};

local function HidePreviewTooltip(v)
	if (GameTooltip:IsOwned(v.Button)) then GameTooltip:Hide(); end
end

local function ClearPreviewButton(v)
	if (v.Clearing) then return; end
	v.Clearing = true;
	v.Active = false;
	v.Binding:Disable();
	v.Cooldown:Clear();
	if (v.GlowAnimation) then v.GlowAnimation:Stop(); end
	if (v.BlinkAnimation) then v.BlinkAnimation:Stop(); end
	v.Glow:Hide(); v.Glow:SetAlpha(1); v.Texture:SetAlpha(1);
	HidePreviewTooltip(v);
	v.Button:Hide();
	v.Clearing = false;
end

local function ClearPreview(preview)
	preview.Visible, preview.Started = false, nil;
	for _, v in ipairs(preview.Buttons) do ClearPreviewButton(v); end
end

HidePreview = function(state)
	local preview = state.Preview;
	if (not preview) then return; end
	preview.Root:Hide();
	if (preview.Visible) then ClearPreview(preview); end
end

local function CreatePreviewButton(preview)
	local button = CreateFrame("Frame", nil, preview.Root);
	button:Hide(); button:SetMouseClickEnabled(false);
	local v = CreateVisuals(button);
	v.Button, v.Duration, v.Binding = button, C_DurationUtil.CreateDuration(), C_DurationUtil.CreateDurationTextBinding();
	v.Binding:SetFontString(v.Time); v.Binding:SetDuration(v.Duration); v.Binding:Disable();
	button:SetScript("OnEnter", function()
		if (not previewActive or not v.Active or not v.TooltipEnabled or not CanRestyleButtons()) then return; end
		GameTooltip:SetOwner(button, "ANCHOR_RIGHT");
		GameTooltip:SetText("合成预览：" .. v.TooltipName);
		GameTooltip:AddLine(v.Harmful and "减益边框示例：" .. L[v.Dispel] or "增益边框示例", 1, 1, 1, true);
		GameTooltip:AddLine("图标、层数和时间均为合成示例，不代表真实光环匹配。", 0.8, 0.8, 0.8, true);
		GameTooltip:Show();
	end);
	button:SetScript("OnLeave", function() HidePreviewTooltip(v); end);
	button:SetScript("OnHide", function()
		local active = v.Active;
		ClearPreviewButton(v);
		if (active) then preview.Revision = nil; end
	end);
	return v;
end

local function ApplyPreviewAnimations(v, style)
	v.Glow:SetShown(style.Glow);
	if (style.Glow) then
		v.GlowAnimation = v.GlowAnimation or CreatePulse(v.Glow);
		if (not v.GlowAnimation:IsPlaying()) then v.GlowAnimation:Play(); end
	else
		if (v.GlowAnimation) then v.GlowAnimation:Stop(); end
		v.Glow:SetAlpha(1);
	end
	if (style.Blink) then
		v.BlinkAnimation = v.BlinkAnimation or CreatePulse(v.Texture);
		if (not v.BlinkAnimation:IsPlaying()) then v.BlinkAnimation:Play(); end
	else
		if (v.BlinkAnimation) then v.BlinkAnimation:Stop(); end
		v.Texture:SetAlpha(1);
	end
end

local function ApplyPreviewLayout(preview, group)
	for _, spec in ipairs(preview.Groups) do
		if (preview.Category ~= 6) then
			table.sort(spec.Samples, function(a, b)
				if (group.SortMode ~= addonTable.AURA_SORT_MODE_NONE and a.EndTime ~= b.EndTime) then return a.EndTime < b.EndTime; end
				return a.SampleIndex < b.SampleIndex;
			end);
		end
		for i, v in ipairs(spec.Samples) do spec.elements[i] = v.Button; end
	end
	local axis, point, horizontal, vertical = GetLayoutOptions(group);
	preview.Layout:SetLayoutAxis(axis); preview.Layout:SetAnchorPoint(point);
	preview.Layout:SetGrowthDirection(horizontal, vertical); preview.Layout:SetMaximumLineSize(math.huge);
	preview.Layout:Apply(preview.Root, preview.Groups);
end

RefreshPreview = function(state, force)
	if (not previewActive) then HidePreview(state); return; end
	if (not CanRestyleButtons()) then StopPreview(); return; end
	local index, category, entry, spellID = 1;
	if (addonTable.GetPreviewContext) then index, category, entry, spellID = addonTable.GetPreviewContext(); end
	if (state.Index ~= index or not ShouldShowState(state)) then HidePreview(state); return; end
	local group = db.IconGroups[index];
	if (group.NameplateIsParent and not addonTable.GetNameplateAddonFrame(state.Plate, group):IsVisible()) then HidePreview(state); return; end
	if (entry and not MatchesActor(entry, index, UnitIsFriend("player", state.Unit), UnitKind(state.Unit))) then HidePreview(state); return; end
	local dispel = category == 9;
	if (dispel and (not group.Additions_DispellableSpells or UnitIsFriend("player", state.Unit)
		or not group.Additions_Dispel_InstanceTypes[instanceType] or HasEnabledValue(group.Additions_DispellableSpells_Blacklist))) then
		HidePreview(state); return;
	end
	local preview = state.Preview;
	if (not preview) then
		preview = {Root = CreateFrame("Frame", nil, UIParent), Buttons = {}, Groups = {}, Layout = AnchorUtil.CreateFlowLayout()};
		state.Preview = preview;
		preview.Root:Hide();
		preview.Root:SetScript("OnHide", function() if (preview.Visible) then ClearPreview(preview); end end);
	end
	local restyle = force or not preview.Visible or preview.Revision ~= configRevision or preview.ContextRevision ~= previewContextRevision
		or preview.Entry ~= entry or preview.Category ~= category or preview.SpellID ~= spellID;
	local count = category == 6 and 6 or 4;
	if (restyle) then
		ApplyContainerStyle(preview.Root, state, group);
		local styleEntry = entry;
		if (dispel) then
			styleEntry = {overrideSize = true, iconSizeWidth = group.DispelIconSizeWidth, iconSizeHeight = group.DispelIconSizeHeight,
				showGlow = addonTable.GLOW_TIME_INFINITE, glowType = group.Additions_DispellableSpells_GlowType};
		end
		local baseStyle = GetStyle(group, styleEntry);
		if (preview.BindingRevision ~= configRevision) then
			preview.TimeBinding = BuildTimePresentation(group);
			preview.BindingRevision = configRevision;
		end
		local specs, bySignature = {}, {};
		for i = 1, count do
			local v = preview.Buttons[i];
			if (not v) then v = CreatePreviewButton(preview); preview.Buttons[i] = v; end
			local sample = previewSamples[(i-1) % #previewSamples + 1];
			v.Sample, v.SampleIndex = sample, i;
			v.Harmful, v.Dispel = sample.Harmful, sample.Dispel or "Other";
			if (category == 6) then v.Harmful, v.Dispel = i > 1, previewDispelTypes[i-1] or "Other";
			elseif (dispel) then v.Harmful = false;
			elseif (entry and entry.auraType ~= ANY) then v.Harmful = entry.auraType == DEBUFF; end
			local style = baseStyle;
			if (category == 2 and addonTable.PreviewMixedSizes) then
				style = GetStyle(group, {overrideSize = true,
					iconSizeWidth = math.max(1, math.ceil(baseStyle.Width * sample.WidthScale)),
					iconSizeHeight = math.max(1, math.ceil(baseStyle.Height * sample.HeightScale))});
			end
			local filter = v.Harmful and "HARMFUL|INCLUDE_NAME_PLATE_ONLY" or "HELPFUL|INCLUDE_NAME_PLATE_ONLY";
			if (entry and entry.enabledState == MINE) then filter = filter .. "|PLAYER"; end
			filter = ApplySourceFilter(filter, group);
			local signature = category == 6 and "border-colors" or filter .. ":" .. style.Signature;
			local spec = bySignature[signature];
			if (not spec) then
				spec = {Style = style, Group = group, Filter = filter, Type = v.Harmful and DEBUFF or BUFF,
					Samples = {}, elements = {}, elementSpacing = group.IconSpacing, groupSpacing = 0};
				bySignature[signature] = spec; specs[#specs+1] = spec;
			end
			local id = sample.ID;
			if (entry) then id = spellID; end
			ApplyVisualStyle(v.Button, v, spec);
			v.Texture:SetTexture(id and addonTable.SpellTextureByID[id] or 134400);
			v.TooltipName = entry and addonTable.GetSpellDisplayName(entry) or id and addonTable.SpellNameByID[id] or "未解析法术";
			v.TooltipEnabled = group.ShowAuraTooltip;
			v.Button:SetMouseMotionEnabled(v.TooltipEnabled);
			HidePreviewTooltip(v);
			v.BuffBorder:Hide(); v.DebuffBorder:Hide();
			local borderColor = spec.Style.BorderColor or (v.Harmful and group["DebuffBorders" .. v.Dispel .. "Color"] or group.BuffBordersColor);
			local borderEnabled = spec.Style.BorderType ~= addonTable.BORDER_TYPE_DISABLED
				and (spec.Style.BorderColor ~= nil or v.Harmful and group.ShowDebuffBorders or not v.Harmful and group.ShowBuffBorders);
			local border = v.Harmful and v.DebuffBorder or v.BuffBorder;
			border:SetVertexColor(borderColor[1], borderColor[2], borderColor[3], borderColor[4] or 1);
			border:SetShown(borderEnabled);
			v.Count:SetText(i > 1 and i or ""); v.Count:SetShown(group.ShowStacks);
			v.Binding:Assign(preview.TimeBinding);
			v.Binding:SetFontString(v.Time); v.Binding:SetDuration(v.Duration); v.Binding:SetEnabled(group.ShowCooldownText);
			v.Time:SetShown(group.ShowCooldownText);
			ApplyPreviewAnimations(v, spec.Style);
			v.Active = true; v.Button:Show();
			spec.Samples[#spec.Samples+1] = v;
		end
		for i = count + 1, #preview.Buttons do ClearPreviewButton(preview.Buttons[i]); end
		if (category ~= 6) then SortSpecs(specs, group); end
		preview.Groups = specs;
		preview.Revision, preview.ContextRevision = configRevision, previewContextRevision;
		preview.Entry, preview.Category, preview.SpellID = entry, category, spellID;
	end
	local now, relayout = GetTime(), restyle;
	for i = 1, count do
		local v = preview.Buttons[i];
		local sample = v.Sample;
		local started = previewStarted + math.floor((now - previewStarted) / sample.Cycle) * sample.Cycle;
		if (restyle or v.Started ~= started) then
			v.Started, v.EndTime = started, started + sample.Remaining;
			v.Duration:SetTimeFromEnd(v.EndTime, sample.Duration);
			v.Cooldown:SetCooldownFromDurationObject(v.Duration);
			if (group.ShowCooldownText) then v.Binding:UpdateFontString(); end
			relayout = true;
		end
	end
	if (relayout) then ApplyPreviewLayout(preview, group); end
	preview.Started, preview.Visible = previewStarted, true;
	preview.Root:Show();
end

function addonTable.IsPreviewActive()
	return previewActive == true;
end

function addonTable.OnPreviewContextChanged()
	if (addonTable.UpdatePreviewStatus) then addonTable.UpdatePreviewStatus(); end
	if (not previewActive) then return; end
	if (not CanRestyleButtons()) then StopPreview(); return; end
	previewContextRevision = previewContextRevision + 1;
	for _, plateStates in pairs(states) do
		for _, state in pairs(plateStates) do RefreshPreview(state, true); end
	end
end

StopPreview = function(reason)
	if (previewTicker) then previewTicker:Cancel(); previewTicker = nil; end
	previewActive = false;
	if (addonTable.UpdatePreviewStatus) then addonTable.UpdatePreviewStatus(); end
	if (reason) then addonTable.Print(reason); end
	for _, plateStates in pairs(states) do
		for _, state in pairs(plateStates) do HidePreview(state); end
	end
	RefreshAll();
end

function addonTable.SwitchTestMode()
	if (previewActive) then StopPreview(); return; end
	if (not CanRestyleButtons()) then addonTable.Print("战斗或受限光环期间不能开启模拟预览。"); return; end
	previewActive, previewStarted = true, GetTime();
	if (addonTable.UpdatePreviewStatus) then addonTable.UpdatePreviewStatus(); end
	RefreshAll();
	previewTicker = C_Timer.NewTicker(0.5, function()
		if (not CanRestyleButtons()) then StopPreview(); return; end
		if (GetTime() - previewStarted >= 13) then previewStarted = GetTime(); end
		for _, plateStates in pairs(states) do for _, state in pairs(plateStates) do RefreshPreview(state); end end
	end);
	addonTable.Print("模拟预览已开启；显示姓名板后可查看。再次 /naurasf test 关闭，真实光环仍需游戏内验证。");
end

local eventFrame = CreateFrame("Frame");
addonTable.EventFrame = eventFrame;
local handlers = {};
handlers.PLAYER_LOGIN = Initialize;
handlers.PLAYER_ENTERING_WORLD = function()
	Initialize();
	if (previewActive) then StopPreview(); end
	UpdateInstanceType(); SynchronizeNameplates();
end;
handlers.NAME_PLATE_UNIT_ADDED = function(unit)
	if (initialized) then AttachUnit(unit); end
end;
handlers.NAME_PLATE_UNIT_REMOVED = DetachUnit;
handlers.PLAYER_TARGET_CHANGED = RefreshAll;
handlers.ZONE_CHANGED_NEW_AREA = function() UpdateInstanceType(); addonTable.UpdateAllNameplates(); end;
handlers.PLAYER_REGEN_DISABLED = function() if (previewActive) then StopPreview(); end end;
handlers.PLAYER_REGEN_ENABLED = RefreshAll;
handlers.ADDON_RESTRICTION_STATE_CHANGED = function(_, state)
	if (state ~= Enum.AddOnRestrictionState.Inactive and previewActive) then StopPreview(); end
	if (not pendingUpdate) then pendingUpdate = C_Timer.NewTimer(0, RefreshAll); end
end;
handlers.UNIT_FACTION = function(unit)
	if (visibleByUnit[unit] or unit == "player") then addonTable.UpdateAllNameplates(); end
end;
handlers.UNIT_FLAGS = handlers.UNIT_FACTION;
for event in pairs(handlers) do eventFrame:RegisterEvent(event); end
local dispatch = function(_, event, ...)
	local handler = handlers[event];
	if (handler) then handler(...); end
end;
eventFrame:SetScript("OnEvent", dispatch);
if (IsLoggedIn()) then Initialize(); SynchronizeNameplates(); end
