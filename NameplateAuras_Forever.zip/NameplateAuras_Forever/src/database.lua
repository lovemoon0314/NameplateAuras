-- luacheck: no max line length
-- luacheck: globals wipe LibStub

local addonName, addonTable = ...;
local L = LibStub("AceLocale-3.0"):GetLocale(addonName);

-- // consts
local CONST_SPELL_MODE_DISABLED, CONST_SPELL_MODE_ALL, CONST_SPELL_MODE_MYAURAS, AURA_TYPE_BUFF, AURA_TYPE_DEBUFF, AURA_TYPE_ANY, AURA_SORT_MODE_NONE;
local AURA_SORT_MODE_EXPIRETIME, AURA_SORT_MODE_ICONSIZE, AURA_SORT_MODE_AURATYPE_EXPIRE, GLOW_TIME_INFINITE;
do
	CONST_SPELL_MODE_DISABLED, CONST_SPELL_MODE_ALL, CONST_SPELL_MODE_MYAURAS = addonTable.CONST_SPELL_MODE_DISABLED, addonTable.CONST_SPELL_MODE_ALL, addonTable.CONST_SPELL_MODE_MYAURAS;
	AURA_TYPE_BUFF, AURA_TYPE_DEBUFF, AURA_TYPE_ANY = addonTable.AURA_TYPE_BUFF, addonTable.AURA_TYPE_DEBUFF, addonTable.AURA_TYPE_ANY;
	AURA_SORT_MODE_NONE, AURA_SORT_MODE_EXPIRETIME, AURA_SORT_MODE_ICONSIZE, AURA_SORT_MODE_AURATYPE_EXPIRE =
		addonTable.AURA_SORT_MODE_NONE, addonTable.AURA_SORT_MODE_EXPIRETIME, addonTable.AURA_SORT_MODE_ICONSIZE, addonTable.AURA_SORT_MODE_AURATYPE_EXPIRE;
	GLOW_TIME_INFINITE = addonTable.GLOW_TIME_INFINITE; -- // 30 days
end

-- // utilities
local Print, msgWithQuestion, table_count, SpellNameByID, table_insert;
do
	Print, msgWithQuestion, table_count, SpellNameByID, table_insert =
		addonTable.Print, addonTable.msgWithQuestion, addonTable.table_count, addonTable.SpellNameByID, table.insert;
end

local migrations = {
    [0] = function()
        local db = addonTable.db;
        -- delete unused fields
        for _, entry in pairs({ "IconSize", "DebuffBordersColor", "DisplayBorders", "ShowMyAuras", "DefaultSpells", "InterruptsEnableOnlyInPvP" }) do
            if (db[entry] ~= nil) then
                db[entry] = nil;
                Print(string.format(L["Old db record is deleted: %s"], entry));
            end
        end
        if (db.TimerTextSizeMode ~= nil) then
            db.TimerTextUseRelativeScale = (db.TimerTextSizeMode == "relative");
            db.TimerTextSizeMode = nil;
        end
        if (db.SortMode ~= nil and type(db.SortMode) == "string") then
            local replacements = { ["none"] = AURA_SORT_MODE_NONE, ["by-expire-time-asc"] = AURA_SORT_MODE_EXPIRETIME, ["by-expire-time-des"] = 3,
                ["by-icon-size-asc"] = AURA_SORT_MODE_ICONSIZE, ["by-icon-size-des"] = 5, ["by-aura-type-expire-time"] = AURA_SORT_MODE_AURATYPE_EXPIRE };
            db.SortMode = replacements[db.SortMode];
        end
        if (db.TimerStyle ~= nil and type(db.TimerStyle) == "string") then
            local replacements = { [1] = "texture-with-text", [2] = "cooldown-frame-no-text", [3] = "cooldown-frame", [4] = "circular-noomnicc-text" };
            for newValue, oldValue in pairs(replacements) do
                if (db.TimerStyle == oldValue) then
                    db.TimerStyle = newValue;
                    break;
                end
            end
        end
        if (db.DisplayTenthsOfSeconds ~= nil) then
            db.MinTimeToShowTenthsOfSeconds = db.DisplayTenthsOfSeconds and 10 or 0;
            db.DisplayTenthsOfSeconds = nil;
        end
        if (db.DefaultSpellsAreImported ~= nil) then
            db.DefaultSpellsLastSetImported = 1;
            db.DefaultSpellsAreImported = nil;
        end
        for _, spellInfo in pairs(db.CustomSpells2) do
            if (type(spellInfo.checkSpellID) == "number") then
                spellInfo.checkSpellID = { [spellInfo.checkSpellID] = true };
            end
        end
        for _, spellInfo in pairs(db.CustomSpells2) do
            if (spellInfo.checkSpellID ~= nil) then
                local toAdd = { };
                for key in pairs(spellInfo.checkSpellID) do
                    if (type(key) == "string") then
                        spellInfo.checkSpellID[key] = nil;
                        local nmbr = tonumber(key);
                        if (nmbr ~= nil) then
                            table_insert(toAdd, nmbr);
                        end
                    end
                end
                for _, value in pairs(toAdd) do
                    spellInfo.checkSpellID[value] = true;
                end
            end
        end
        for _, spellInfo in pairs(db.CustomSpells2) do
            if (spellInfo.checkSpellID ~= nil) then
                local toAdd = { };
                for key, value in pairs(spellInfo.checkSpellID) do
                    if (type(value) == "number") then
                        table_insert(toAdd, value);
                        spellInfo.checkSpellID[key] = nil;
                    end
                end
                for _, value in pairs(toAdd) do
                    spellInfo.checkSpellID[value] = true;
                end
            end
        end
        for _, spellInfo in pairs(db.CustomSpells2) do
            if (spellInfo.showGlow ~= nil and type(spellInfo.showGlow) == "boolean") then
                spellInfo.showGlow = spellInfo.showGlow and GLOW_TIME_INFINITE or nil;
            end
        end
        for _, spellInfo in pairs(db.CustomSpells2) do
            if (spellInfo.allowMultipleInstances ~= nil and type(spellInfo.allowMultipleInstances) == "boolean" and spellInfo.allowMultipleInstances == false) then
                spellInfo.allowMultipleInstances = nil;
            end
        end
    end,
    [1] = function()
        local db = addonTable.db;
        local tempTable = { };
        for spellID, spellInfo in pairs(db.CustomSpells2) do
            local entry = addonTable.deepcopy(spellInfo);
            if (entry.spellName == nil) then
                entry.spellName = SpellNameByID[spellID];
                entry.unresolvedSpellID = entry.spellName == nil and spellID or nil;
                entry.spellName = entry.spellName or ("Unknown spell #" .. tostring(spellID));
            end
            entry.spellID = nil;
            table.insert(tempTable, entry);
        end
        wipe(db.CustomSpells2);
        for _, spellInfo in pairs(tempTable) do
            table.insert(db.CustomSpells2, spellInfo);
        end
    end,
    [2] = function()
        local db = addonTable.db;
        db.CustomSpells3 = nil;
        for _, spellInfo in pairs(db.CustomSpells2) do
            spellInfo.allowMultipleInstances = nil;
        end
    end,
    [3] = function()
        local db = addonTable.db;
        for _, spellInfo in pairs(db.CustomSpells2) do
            if (db.UseDimGlow) then
                spellInfo.glowType = addonTable.GLOW_TYPE_ACTIONBUTTON_DIM;
            else
                spellInfo.glowType = addonTable.GLOW_TYPE_AUTOUSE;
            end
        end
        db.UseDimGlow = nil;
        db.Additions_DispellableSpells_DimGlow = nil;
    end,
    [4] = function()
        local db = addonTable.db;
        if (not db.InterruptsGlow) then
            db.InterruptsGlowType = addonTable.GLOW_TYPE_NONE;
        else
            db.InterruptsGlowType = addonTable.GLOW_TYPE_ACTIONBUTTON_DIM;
        end
        db.InterruptsGlow = nil;
    end,
    [5] = function()
        local db = addonTable.db;
        db.FrameAnchorToNameplate = db.FrameAnchor;
    end,
    [6] = function()
        local db = addonTable.db;
        local iconAligh = {
            ["TOPLEFT"] = addonTable.ICON_ALIGN_TOP_RIGHT,
            ["LEFT"] = addonTable.ICON_ALIGN_CENTER,
            ["BOTTOMLEFT"] = addonTable.ICON_ALIGN_BOTTOM_LEFT,
        };
        db.IconAnchor = iconAligh[db.IconAnchor];
    end,
    [7] = function()
        local db = addonTable.db;
        if (db.TimerStyle == 2 or db.TimerStyle == 3) then
            local showText = db.TimerStyle == 3;
            db.TimerStyle = 4;
            db.ShowStacks = showText;
            db.ShowCooldownText = showText;
        end
    end,
    [8] = function()
        local db = addonTable.db;
        if (db.TimerStyle ~= nil) then
            db.ShowCooldownAnimation = db.TimerStyle == 4;
            db.TimerStyle = nil;
        end
    end,
    [9] = function()
        local db = addonTable.db;
        if (db.SortMode == 3) then
            db.IconGrowDirection = addonTable.ICON_GROW_DIRECTION_LEFT;
            db.SortMode = addonTable.AURA_SORT_MODE_EXPIRETIME;
        end
        if (db.SortMode == 5) then
            db.IconGrowDirection = addonTable.ICON_GROW_DIRECTION_LEFT;
            db.SortMode = addonTable.AURA_SORT_MODE_ICONSIZE;
        end
    end,
    [10] = function()
        local db = addonTable.db;
        if (db.IgnoreNameplateScale ~= nil) then
            if (not db.IgnoreNameplateScale) then
                db.IconScaleTarget = 1.2;
            end
            db.IgnoreNameplateScale = nil;
        end
        if (db.FullOpacityAlways ~= nil) then
            if (not db.FullOpacityAlways) then
                db.IconAlpha = 0.6;
            end
            db.FullOpacityAlways = nil;
        end
    end,
    [11] = function()
        local db = addonTable.db;
        db.IconScale = nil;
    end,
    [12] = function()
        local db = addonTable.db;
        if (db.TimerTextSoonToExpireColor ~= nil and #db.TimerTextSoonToExpireColor == 3) then
            db.TimerTextSoonToExpireColor[#db.TimerTextSoonToExpireColor+1] = 1;
        end
        if (db.TimerTextUnderMinuteColor ~= nil and #db.TimerTextUnderMinuteColor == 3) then
            db.TimerTextUnderMinuteColor[#db.TimerTextUnderMinuteColor+1] = 1;
        end
        if (db.TimerTextLongerColor ~= nil and #db.TimerTextLongerColor == 3) then
            db.TimerTextLongerColor[#db.TimerTextLongerColor+1] = 1;
        end
    end,
    [13] = function()
        local db = addonTable.db;
        if (db.DefaultIconSize ~= nil) then
            db.DefaultIconSizeWidth = db.DefaultIconSize;
            db.DefaultIconSizeHeight = db.DefaultIconSize;
            db.DefaultIconSize = nil;
        end
        for _, spellInfo in pairs(db.CustomSpells2) do
            if (spellInfo.iconSize ~= nil) then
                spellInfo.iconSizeWidth = spellInfo.iconSize;
                spellInfo.iconSizeHeight = spellInfo.iconSize;
                spellInfo.iconSize = nil;
            end
        end
    end,
    [14] = function()
        local db = addonTable.db;
        if (db.InterruptsIconSize ~= nil) then
            db.InterruptsIconSizeWidth = db.InterruptsIconSize;
            db.InterruptsIconSizeHeight = db.InterruptsIconSize;
            db.InterruptsIconSize = nil;
        end
        if (db.Additions_DispellableSpells_IconSize ~= nil) then
            db.DispelIconSizeWidth = db.Additions_DispellableSpells_IconSize;
            db.DispelIconSizeHeight = db.Additions_DispellableSpells_IconSize;
            db.Additions_DispellableSpells_IconSize = nil;
        end
    end,
    [15] = function()
        local db = addonTable.db;
        for _, spellInfo in pairs(db.CustomSpells2) do
            if (spellInfo.animationType == 3) then -- ICON_ANIMATION_TYPE_SCALE
                spellInfo.animationType = addonTable.ICON_ANIMATION_TYPE_ALPHA;
            end
        end
    end,
    [16] = function()
        local db = addonTable.db;
        if (db.StacksTextColor ~= nil and #db.StacksTextColor == 3) then
            db.StacksTextColor[#db.StacksTextColor+1] = 1;
        end
    end,
    [17] = function()
        local db = addonTable.db;
        local values = { "DebuffBordersMagicColor", "DebuffBordersCurseColor", "DebuffBordersDiseaseColor", "DebuffBordersPoisonColor", "DebuffBordersOtherColor", "BuffBordersColor" };
        for _, value in pairs(values) do
            if (db[value] ~= nil and #db[value] == 3) then
                db[value][4] = 1;
            end
        end
    end,
    [18] = function()
        local db = addonTable.db;
        for _, spellInfo in pairs(db.CustomSpells2) do
            spellInfo.pvpCombat = nil;
        end
    end,
    [19] = function()
        local db = addonTable.db;
        for _, spellInfo in pairs(db.CustomSpells2) do
            spellInfo.customBorderEnabled = nil;
            spellInfo.customBorderType = addonTable.BORDER_TYPE_DISABLED;
        end
    end,
    [20] = function()
        local db = addonTable.db;
        if (db.AlwaysShowMyAurasBlacklist == nil) then
            db.AlwaysShowMyAurasBlacklist = {};
        end
    end,
    [21] = function()
        local db = addonTable.db;
        db.MaxAuras = nil;
    end,
    [22] = function()
        local db = addonTable.db;
        local keys = {
            "ShowAurasOnPlayerNameplate",
            "IconXOffset",
            "IconYOffset",
            "Font",
            "SortMode",
            "FontScale",
            "TimerTextUseRelativeScale",
            "TimerTextSize",
            "TimerTextAnchor",
            "TimerTextAnchorIcon",
            "TimerTextXOffset",
            "TimerTextYOffset",
            "TimerTextSoonToExpireColor",
            "TimerTextUnderMinuteColor",
            "TimerTextLongerColor",
            "StacksFont",
            "StacksFontScale",
            "StacksTextAnchor",
            "StacksTextAnchorIcon",
            "StacksTextXOffset",
            "StacksTextYOffset",
            "StacksTextColor",
            "ShowBuffBorders",
            "BuffBordersColor",
            "ShowDebuffBorders",
            "DebuffBordersMagicColor",
            "DebuffBordersCurseColor",
            "DebuffBordersDiseaseColor",
            "DebuffBordersPoisonColor",
            "DebuffBordersOtherColor",
            "IconSpacing",
            "IconAnchor",
            "AlwaysShowMyAuras",
            "BorderThickness",
            "ShowAboveFriendlyUnits",
            "FrameAnchor",
            "FrameAnchorToNameplate",
            "MinTimeToShowTenthsOfSeconds",
            "InterruptsEnabled",
            "InterruptsIconSizeWidth",
            "InterruptsIconSizeHeight",
            "InterruptsGlowType",
            "InterruptsUseSharedIconTexture",
            "InterruptsShowOnlyOnPlayers",
            "Additions_ExplosiveOrbs",
            "ShowAuraTooltip",
            "Additions_DispellableSpells",
            "Additions_DispellableSpells_Blacklist",
            "DispelIconSizeWidth",
            "DispelIconSizeHeight",
            "Additions_DispellableSpells_GlowType",
            "IconGrowDirection",
            "ShowStacks",
            "ShowCooldownText",
            "ShowCooldownAnimation",
            "IconAlpha",
            "IconAlphaTarget",
            "IconScaleTarget",
            "TargetStrata",
            "NonTargetStrata",
            "BorderType",
            "BorderFilePath",
            "DefaultIconSizeWidth",
            "DefaultIconSizeHeight",
            "IconZoom",
            "CustomSortMethod",
            "Additions_DRPvP",
            "Additions_DRPvE",
            "ShowOnlyOnTarget",
            "UseTargetAlphaIfNotTargetSelected",
            "AffixSpiteful",
            "AffixSpitefulSound",
            "EnabledZoneTypes",
            "MaxAuras",
            "ShowAurasOnTargetEvenInDisabledAreas",
            "AlwaysShowMyAurasBlacklist",
            "NpcBlacklist",
            "TimerTextUseRelativeColor",
            "TimerTextColorZeroPercent",
            "TimerTextColorHundredPercent",
            "KeepAspectRatio",
            "UseDefaultAuraTooltip",
        };
        if (db.IconGroups == nil or db.IconGroups[1] == nil) then
            db.IconGroups[1] = addonTable.GetIconGroupDefaultOptions(L["First Icon Group"]);
        end
        for _, key in pairs(keys) do
            local value = db[key];
            if (value ~= nil) then
                db.IconGroups[1][key] = value;
                db[key] = nil;
            end
        end
    end,
    [23] = function()
        local db = addonTable.db;
        for igIndex, igData in pairs(db.IconGroups) do
            if (igData.IconGroupName == nil or igData.IconGroupName == "") then
                igData.IconGroupName = "[" .. tostring(igIndex) .. "] " .. date("%Y-%m-%d-%H-%M-%S");
            end
        end
    end,
    [24] = function()
        local db = addonTable.db;
        local ref = addonTable.GetIconGroupDefaultOptions();
        local colorKeys = {
            "TimerTextSoonToExpireColor",
            "TimerTextUnderMinuteColor",
            "TimerTextLongerColor",
            "StacksTextColor",
            "BuffBordersColor",
            "DebuffBordersMagicColor",
            "DebuffBordersCurseColor",
            "DebuffBordersDiseaseColor",
            "DebuffBordersPoisonColor",
            "DebuffBordersOtherColor",
            "TimerTextColorZeroPercent",
            "TimerTextColorHundredPercent",
        };
        for _, igData in pairs(db.IconGroups) do
            for _, key in pairs(colorKeys) do
                local entry = igData[key];
                local refEntry = ref[key];
                if (entry ~= nil and refEntry ~= nil) then
                    for refKey, refValue in pairs(refEntry) do
                        if (entry[refKey] == nil) then
                            entry[refKey] = refValue;
                        end
                    end
                end
            end
        end
    end,
    [25] = function()
        local db = addonTable.db;
        local count = 0;
        for _, spellInfo in pairs(db.CustomSpells2) do
            if (spellInfo.overrideSize == nil) then
                local groups = spellInfo.iconGroups;
                if (groups ~= nil) then
                    local firstEnabledGroup = 0;
                    for groupIndex, groupEnabled in pairs(groups) do
                        if (groupEnabled) then
                            firstEnabledGroup = groupIndex;
                            break;
                        end
                    end
                    if (firstEnabledGroup > 0) then
                        local groupInfo = db.IconGroups[firstEnabledGroup];
                        if (groupInfo ~= nil) then
                            if (spellInfo.iconSizeWidth ~= groupInfo.DefaultIconSizeWidth or spellInfo.iconSizeHeight ~= groupInfo.DefaultIconSizeHeight) then
                                spellInfo.overrideSize = true;
                                count = count + 1;
                            end
                        end
                    end
                end
            end
        end
        if (count > 0) then
            addonTable.Print(string.format(L["Total spells with custom size: %d"], count));
        end
    end,
    [26] = function()
        local db = addonTable.db;
        for _, igData in pairs(db.IconGroups) do
            if (igData.ShowCooldownSwipeEdge == nil) then
                igData.ShowCooldownSwipeEdge = true;
            end
        end
    end,
    [27] = function() -- yes, 27 and 28 should be the same
        local db = addonTable.db;
        for _, igData in pairs(db.IconGroups) do
            if (igData.FriendlyUnitsAurasEnabledZoneTypes == nil) then
                igData.FriendlyUnitsAurasEnabledZoneTypes = {
                    [addonTable.INSTANCE_TYPE_NONE] =			true,
                    [addonTable.INSTANCE_TYPE_UNKNOWN] = 		true,
                    [addonTable.INSTANCE_TYPE_PVP] = 			true,
                    [addonTable.INSTANCE_TYPE_PVP_BG_40PPL] = 	true,
                    [addonTable.INSTANCE_TYPE_ARENA] = 			true,
                    [addonTable.INSTANCE_TYPE_PARTY] = 			true,
                    [addonTable.INSTANCE_TYPE_RAID] = 			true,
                    [addonTable.INSTANCE_TYPE_SCENARIO] =		true,
                };
            end
        end
    end,
    [28] = function()
        local db = addonTable.db;
        for _, igData in pairs(db.IconGroups) do
            if (igData.ShowAboveFriendlyUnits ~= nil) then
                local enabled = igData.ShowAboveFriendlyUnits;

                igData.FriendlyUnitsAurasEnabledZoneTypes = {
                    [addonTable.INSTANCE_TYPE_NONE] =			enabled,
                    [addonTable.INSTANCE_TYPE_UNKNOWN] = 		enabled,
                    [addonTable.INSTANCE_TYPE_PVP] = 			enabled,
                    [addonTable.INSTANCE_TYPE_PVP_BG_40PPL] = 	enabled,
                    [addonTable.INSTANCE_TYPE_ARENA] = 			enabled,
                    [addonTable.INSTANCE_TYPE_PARTY] = 			enabled,
                    [addonTable.INSTANCE_TYPE_RAID] = 			enabled,
                    [addonTable.INSTANCE_TYPE_SCENARIO] =		enabled,
                };

                igData.ShowAboveFriendlyUnits = nil;
            end
        end
    end,
    [29] = function()
        local db = addonTable.db;
        for _, igData in pairs(db.IconGroups) do
            if (igData.EnabledZoneTypes ~= nil) then
                igData.EnemyUnitsAurasEnabledZoneTypes = addonTable.deepcopy(igData.EnabledZoneTypes);
                igData.EnabledZoneTypes = nil;
            end
        end
    end,
    [30] = function()
        local db = addonTable.db;
        for _, igData in pairs(db.IconGroups) do
            if (igData.ShowAurasOnTargetEvenInDisabledAreas ~= nil) then
                igData.ShowAurasOnEnemyTargetEvenInDisabledAreas = igData.ShowAurasOnTargetEvenInDisabledAreas
                igData.ShowAurasOnTargetEvenInDisabledAreas = nil;
            end
            igData.ShowAurasOnAlliedTargetEvenInDisabledAreas = false;
        end
    end,
    [31] = function()
        local db = addonTable.db;
        for _, igData in pairs(db.IconGroups) do
            if (igData.AttachToAddonFrame == true) then
                igData.AttachType = addonTable.ATTACH_TYPE_TPTP;
            else
                igData.AttachType = addonTable.ATTACH_TYPE_NAMEPLATE;
            end
            igData.AttachToAddonFrame = nil;
        end
    end,
    [32] = function()
        local db = addonTable.db;
        for _, igData in pairs(db.IconGroups) do
            if (igData.Additions_Dispel_InstanceTypes == nil) then
                igData.Additions_Dispel_InstanceTypes = {
                    [addonTable.INSTANCE_TYPE_NONE] =			true,
                    [addonTable.INSTANCE_TYPE_UNKNOWN] = 		true,
                    [addonTable.INSTANCE_TYPE_PVP] = 			true,
                    [addonTable.INSTANCE_TYPE_PVP_BG_40PPL] = 	true,
                    [addonTable.INSTANCE_TYPE_ARENA] = 			true,
                    [addonTable.INSTANCE_TYPE_PARTY] = 			true,
                    [addonTable.INSTANCE_TYPE_RAID] = 			true,
                    [addonTable.INSTANCE_TYPE_SCENARIO] =		true,
                }
            end
        end
    end,
    [33] = function()
        local db = addonTable.db;
        for _, spellInfo in pairs(db.CustomSpells2) do
            local playerNpcMode = spellInfo.playerNpcMode;
            if (spellInfo.showOnPlayers == nil) then
                spellInfo.showOnPlayers = (playerNpcMode == 1 or playerNpcMode == 2); -- SHOW_ON_PLAYERS_AND_NPC or SHOW_ON_PLAYERS
            end
            if (spellInfo.showOnNpcs == nil) then
                spellInfo.showOnNpcs = (playerNpcMode == 1 or playerNpcMode == 3); -- SHOW_ON_PLAYERS_AND_NPC or SHOW_ON_NPC
            end
            if (spellInfo.showOnPets == nil) then
                spellInfo.showOnPets = (playerNpcMode == 1 or playerNpcMode == 3); -- SHOW_ON_PLAYERS_AND_NPC or SHOW_ON_NPC
            end
            spellInfo.playerNpcMode = nil;
        end
    end,
};

local function FillInMissingEntriesIsSpells()
    local db = addonTable.db;
    local ref = addonTable.GetIconGroupDefaultOptions();
    for index, spellInfo in pairs(db.CustomSpells2) do
        if (spellInfo.spellName == nil) then
            spellInfo.unresolvedSpellID = spellInfo.unresolvedSpellID or index;
            spellInfo.spellName = "Unknown spell #" .. tostring(spellInfo.unresolvedSpellID);
        end
        do
            -- useRelativeGlowTimer may be nil
            -- useRelativeAnimationTimer may be nil
            -- checkSpellID may be nil
            -- showGlow may be nil
            -- spellTooltip may be nil
            -- spellInfo.customBorderPath may be nil
            -- consolidate may be nil
            -- overrideSize may be nil
            if (spellInfo.enabledState == nil) then
                spellInfo.enabledState = CONST_SPELL_MODE_ALL;
            end
            if (spellInfo.showOnFriends == nil) then
                spellInfo.showOnFriends = true;
            end
            if (spellInfo.showOnEnemies == nil) then
                spellInfo.showOnEnemies = true;
            end
            if (spellInfo.showOnPlayers == nil) then
                spellInfo.showOnPlayers = true;
            end
            if (spellInfo.showOnNpcs == nil) then
                spellInfo.showOnNpcs = true;
            end
            if (spellInfo.showOnPets == nil) then
                spellInfo.showOnPets = true;
            end
            if (spellInfo.auraType == nil) then
                spellInfo.auraType = AURA_TYPE_ANY;
            end
            if (spellInfo.glowType == nil) then
                spellInfo.glowType = addonTable.GLOW_TYPE_AUTOUSE;
            end
            if (spellInfo.animationType == nil) then
                spellInfo.animationType = addonTable.ICON_ANIMATION_TYPE_ALPHA;
            end
            if (spellInfo.animationTimer == nil) then
                spellInfo.animationTimer = 10;
            end
            if (spellInfo.animationDisplayMode == nil) then
                spellInfo.animationDisplayMode = addonTable.ICON_ANIMATION_DISPLAY_MODE_NONE;
            end
            if (spellInfo.iconSizeWidth == nil) then
                spellInfo.iconSizeWidth = ref.DefaultIconSizeWidth;
            end
            if (spellInfo.iconSizeHeight == nil) then
                spellInfo.iconSizeHeight = ref.DefaultIconSizeHeight;
            end
            if (spellInfo.customBorderType == nil) then
                spellInfo.customBorderType = addonTable.BORDER_TYPE_DISABLED;
            end
            if (spellInfo.customBorderSize == nil) then
                spellInfo.customBorderSize = ref.BorderThickness;
            end
            if (spellInfo.customBorderColor == nil) then
                spellInfo.customBorderColor = { 1, 0.1, 0.1, 1 };
            end
            if (spellInfo.customBorderPath == nil) then
                spellInfo.customBorderPath = "";
            end

            if (spellInfo.enabledState == "disabled") then
                spellInfo.enabledState = CONST_SPELL_MODE_DISABLED;
            elseif (spellInfo.enabledState == "all") then
                spellInfo.enabledState = CONST_SPELL_MODE_ALL;
            elseif (spellInfo.enabledState == "my") then
                spellInfo.enabledState = CONST_SPELL_MODE_MYAURAS;
            end

            if (spellInfo.auraType == "buff") then
                spellInfo.auraType = AURA_TYPE_BUFF;
            elseif (spellInfo.auraType == "debuff") then
                spellInfo.auraType = AURA_TYPE_DEBUFF;
            elseif (spellInfo.auraType == "buff/debuff") then
                spellInfo.auraType = AURA_TYPE_ANY;
            end

            if (type(spellInfo.iconGroups) ~= "table" or next(spellInfo.iconGroups) == nil) then
                spellInfo.iconGroups = { [1] = true };
            end
        end
    end
end

local function ReplaceLegacyPath(value)
    if (type(value) == "string") then
        value = value:gsub("Interface\\AddOns\\NameplateAuras\\", "Interface\\AddOns\\NameplateAuras_Forever\\");
    end
    return value;
end

local function MergeDefaults(target, defaults)
    for key, value in pairs(defaults) do
        if (type(value) == "table") then
            if (type(target[key]) ~= "table") then target[key] = {}; end
            MergeDefaults(target[key], value);
        elseif (type(target[key]) ~= type(value)) then
            target[key] = value;
        elseif (type(value) == "number" and (target[key] ~= target[key] or target[key] == math.huge or target[key] == -math.huge)) then
            target[key] = value;
        end
    end
end

addonTable.DB_SCHEMA_VERSION = table_count(migrations);

local function Finite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge;
end

local function IsValidGroupBorderType(value)
    return value == addonTable.BORDER_TYPE_BUILTIN or value == addonTable.BORDER_TYPE_CUSTOM
        or value == addonTable.BORDER_TYPE_DISABLED or value == addonTable.BORDER_TYPE_BLIZZARD;
end

local function NormalizeSpellIDs(value)
    if (value == nil) then return nil; end
    if (type(value) == "number" or type(value) == "string") then
        local id = tonumber(value);
        if (Finite(id) and id > 0 and id == math.floor(id)) then return {[id] = true}; end
        return {};
    end
    local ids = {};
    if (type(value) == "table") then
        for key, enabled in pairs(value) do
            local id = type(enabled) == "number" and enabled or tonumber(key);
            if (Finite(id) and id > 0 and id == math.floor(id)) then ids[id] = enabled ~= false; end
        end
    end
    return ids;
end

-- Migration preconditions must not fill the nil sentinels used by old schemas.
function addonTable.PrepareForeverProfile()
    local db = addonTable.db;
    if (not Finite(db.DBVersion) or db.DBVersion < 0) then db.DBVersion = 0; end
    db.DBVersion = math.floor(db.DBVersion);
    if (not Finite(db.DefaultSpellsLastSetImported) or db.DefaultSpellsLastSetImported < 0) then db.DefaultSpellsLastSetImported = 0; end
    db.DefaultSpellsLastSetImported = math.floor(db.DefaultSpellsLastSetImported);
    if (type(db.CustomSpells2) ~= "table") then db.CustomSpells2 = {}; end
    for key, entry in pairs(db.CustomSpells2) do
        if (type(entry) ~= "table") then
            db.CustomSpells2[key] = nil;
        else
            if (entry.spellName ~= nil and type(entry.spellName) ~= "string") then entry.spellNameRaw = entry.spellName; entry.spellName = nil; end
            if (entry.checkSpellID ~= nil and type(entry.checkSpellID) ~= "table") then entry.checkSpellIDRaw = entry.checkSpellID; end
            entry.checkSpellID = NormalizeSpellIDs(entry.checkSpellID);
            if (entry.iconGroups ~= nil and type(entry.iconGroups) ~= "table") then entry.iconGroups = nil; end
        end
    end
    if (type(db.IconGroups) ~= "table") then db.IconGroups = {}; end
    for key, group in pairs(db.IconGroups) do
        if (type(key) ~= "number" or not Finite(key) or key < 1 or key ~= math.floor(key) or type(group) ~= "table") then db.IconGroups[key] = nil; end
    end
end

function addonTable.NormalizeForeverProfile()
    local db = addonTable.db;
    if (type(db.IconGroups[1]) ~= "table") then db.IconGroups[1] = addonTable.GetIconGroupDefaultOptions(); end
    for key, group in pairs(db.IconGroups) do
        if (type(key) ~= "number" or key < 1 or key ~= math.floor(key) or type(group) ~= "table") then
            db.IconGroups[key] = nil;
        else
            local defaults = addonTable.GetIconGroupDefaultOptions();
            MergeDefaults(group, defaults);
            if (not IsValidGroupBorderType(group.BorderType)) then group.BorderType = defaults.BorderType; end
            group.DefaultIconSizeWidth = math.max(1, math.min(addonTable.MAX_AURA_ICON_SIZE, group.DefaultIconSizeWidth));
            group.DefaultIconSizeHeight = math.max(1, math.min(addonTable.MAX_AURA_ICON_SIZE, group.DefaultIconSizeHeight));
            group.BorderThickness = math.max(1, math.min(5, math.floor(group.BorderThickness)));
            group.IconScaleTarget = math.max(0.1, math.min(10, group.IconScaleTarget));
            group.IconZoom = math.max(0, math.min(0.49, group.IconZoom));
            if (group.IconAnchor < 1 or group.IconAnchor > 3 or group.IconAnchor ~= math.floor(group.IconAnchor)) then group.IconAnchor = defaults.IconAnchor; end
            if (group.IconGrowDirection < 1 or group.IconGrowDirection > 4 or group.IconGrowDirection ~= math.floor(group.IconGrowDirection)) then group.IconGrowDirection = defaults.IconGrowDirection; end
            group.FontScale = math.max(0.1, math.min(5, group.FontScale));
            group.StacksFontScale = math.max(0.1, math.min(5, group.StacksFontScale));
            group.TimerTextSize = math.max(1, math.min(100, group.TimerTextSize));
            group.MinTimeToShowTenthsOfSeconds = math.max(0, math.min(60, group.MinTimeToShowTenthsOfSeconds));
            local points = {TOPLEFT = true, TOP = true, TOPRIGHT = true, LEFT = true, CENTER = true, RIGHT = true, BOTTOMLEFT = true, BOTTOM = true, BOTTOMRIGHT = true};
            for _, field in ipairs({"FrameAnchor", "FrameAnchorToNameplate", "TimerTextAnchor", "TimerTextAnchorIcon", "StacksTextAnchor", "StacksTextAnchorIcon"}) do
                if (not points[group[field]]) then group[field] = defaults[field]; end
            end
            local strata = {BACKGROUND = true, LOW = true, MEDIUM = true, HIGH = true, DIALOG = true, FULLSCREEN = true, FULLSCREEN_DIALOG = true, TOOLTIP = true};
            if (not strata[group.TargetStrata]) then group.TargetStrata = defaults.TargetStrata; end
            if (not strata[group.NonTargetStrata]) then group.NonTargetStrata = defaults.NonTargetStrata; end
            if (group.Font == "NAuras_TeenBold") then group.Font = "NAurasForever_TeenBold"; end
            if (group.Font == "NAuras_TexGyreHerosBold") then group.Font = "NAurasForever_TexGyreHerosBold"; end
            if (group.StacksFont == "NAuras_TeenBold") then group.StacksFont = "NAurasForever_TeenBold"; end
            if (group.StacksFont == "NAuras_TexGyreHerosBold") then group.StacksFont = "NAurasForever_TexGyreHerosBold"; end
            group.BorderFilePath = ReplaceLegacyPath(group.BorderFilePath);
        end
    end
    local oldKeys, dense, indexMap = {}, {}, {};
    for key in pairs(db.IconGroups) do oldKeys[#oldKeys+1] = key; end
    table.sort(oldKeys);
    for _, oldKey in ipairs(oldKeys) do
        dense[#dense+1] = db.IconGroups[oldKey];
        indexMap[oldKey] = #dense;
    end
    db.IconGroups = dense;
    for _, entry in pairs(db.CustomSpells2) do
        entry.customBorderPath = ReplaceLegacyPath(entry.customBorderPath);
        local defaults = {iconSizeWidth = 45, iconSizeHeight = 45, customBorderSize = 2, customBorderColor = {1, 0.1, 0.1, 1},
            customBorderType = addonTable.BORDER_TYPE_DISABLED, overrideSize = false, showOnFriends = true, showOnEnemies = true,
            showOnPlayers = true, showOnNpcs = true, showOnPets = true};
        MergeDefaults(entry, defaults);
        entry.iconSizeWidth = math.max(1, math.min(addonTable.MAX_AURA_ICON_SIZE, entry.iconSizeWidth));
        entry.iconSizeHeight = math.max(1, math.min(addonTable.MAX_AURA_ICON_SIZE, entry.iconSizeHeight));
        entry.customBorderSize = math.max(1, math.min(5, math.floor(entry.customBorderSize)));
        if (type(entry.showGlow) == "boolean") then entry.showGlow = entry.showGlow and GLOW_TIME_INFINITE or nil; end
        if (entry.showGlow ~= nil and (not Finite(entry.showGlow) or entry.showGlow < 0)) then entry.showGlowRaw = entry.showGlow; entry.showGlow = nil; end
        if (entry.enabledState ~= CONST_SPELL_MODE_DISABLED and entry.enabledState ~= CONST_SPELL_MODE_ALL and entry.enabledState ~= CONST_SPELL_MODE_MYAURAS) then entry.enabledStateRaw = entry.enabledState; entry.enabledState = CONST_SPELL_MODE_DISABLED; end
        if (entry.auraType ~= AURA_TYPE_BUFF and entry.auraType ~= AURA_TYPE_DEBUFF and entry.auraType ~= AURA_TYPE_ANY) then entry.auraTypeRaw = entry.auraType; entry.auraType = AURA_TYPE_ANY; entry.enabledState = CONST_SPELL_MODE_DISABLED; end
        if (not Finite(entry.animationTimer) or entry.animationTimer < 0) then entry.animationTimer = 10; end
        if (entry.animationDisplayMode ~= 1 and entry.animationDisplayMode ~= 2 and entry.animationDisplayMode ~= 3) then entry.animationDisplayMode = addonTable.ICON_ANIMATION_DISPLAY_MODE_NONE; end
        if (entry.animationType ~= addonTable.ICON_ANIMATION_TYPE_ALPHA) then entry.animationType = addonTable.ICON_ANIMATION_TYPE_ALPHA; entry.animationDisplayMode = addonTable.ICON_ANIMATION_DISPLAY_MODE_NONE; end
        if (not Finite(entry.glowType) or entry.glowType < 1 or entry.glowType > 5 or entry.glowType ~= math.floor(entry.glowType)) then entry.glowType = addonTable.GLOW_TYPE_NONE; end
        if (entry.customBorderType ~= 1 and entry.customBorderType ~= 2 and entry.customBorderType ~= 3) then entry.customBorderType = addonTable.BORDER_TYPE_DISABLED; end
        local membership = {};
        for oldKey, enabled in pairs(entry.iconGroups or {}) do
            if (indexMap[oldKey]) then membership[indexMap[oldKey]] = enabled == true; end
        end
        if (next(membership) == nil) then membership[1] = false; end
        entry.iconGroups = membership;
    end
end

function addonTable.MigrateDB()
    for i = addonTable.db.DBVersion, (table_count(migrations)-1) do
        local migration = migrations[i];
        if (migration ~= nil) then
            migration();
        end
        addonTable.Print(string.format(L["Converted DB up to version %d"], i));
    end
    if (addonTable.db.DBVersion <= table_count(migrations)) then addonTable.db.DBVersion = table_count(migrations); end
    FillInMissingEntriesIsSpells();
    addonTable.RecoverUnresolvedSpells();

    if (#addonTable.db.IconGroups == 0) then
        addonTable.db.IconGroups[1] = addonTable.GetIconGroupDefaultOptions();
    end
end

function addonTable.RecoverUnresolvedSpells()
    for _, entry in pairs(addonTable.db.CustomSpells2) do
        local id = entry.unresolvedSpellID;
        if (Finite(id)) then
            local name = SpellNameByID[id];
            if (name ~= nil) then
                entry.spellName = name;
                entry.unresolvedSpellID = nil;
            end
        end
    end
end

local function ValidateImportShape(value, defaults, version)
    for key, expected in pairs(defaults) do
        local actual = value[key];
        if (actual ~= nil) then
            local legacySort = key == "SortMode" and version < 1 and type(actual) == "string";
            local legacyAnchor = key == "IconAnchor" and version < 7 and type(actual) == "string";
            if (not legacySort and not legacyAnchor) then
                if (type(actual) ~= type(expected)) then return false, "配置字段类型不正确：" .. tostring(key); end
                if (type(expected) == "number" and not Finite(actual)) then return false, "配置字段不是有限数值：" .. tostring(key); end
                if (type(expected) == "table") then
                    local valid, failure = ValidateImportShape(actual, expected, version);
                    if (not valid) then return false, failure; end
                end
            end
        end
    end
    return true;
end

local function ValidateStringMap(values)
    for key, value in pairs(values) do
        if (type(key) ~= "string" or type(value) ~= "boolean") then return false, "黑名单必须使用法术/单位名称与布尔值"; end
    end
    return true;
end

local function ValidateMembership(entry)
    if (entry.iconGroups == nil) then return true; end
    if (type(entry.iconGroups) ~= "table") then return false, "iconGroups 必须是图标组编号表"; end
    for key, value in pairs(entry.iconGroups) do
        if (not Finite(key) or key < 1 or key ~= math.floor(key) or type(value) ~= "boolean") then return false, "图标组成员必须使用整数编号和布尔值"; end
    end
    return true;
end

function addonTable.PrepareProfileImport(profile)
    if (type(profile) ~= "table") then return nil, "导入内容不是配置表"; end
    local version = profile.DBVersion or 0;
    if (not Finite(version) or version < 0 or version > addonTable.DB_SCHEMA_VERSION or version ~= math.floor(version)) then return nil, "配置版本无效或来自更新版本，未改动当前配置"; end
    local defaults = addonTable.GetIconGroupDefaultOptions();
    local valid, failure = ValidateImportShape(profile, defaults, version);
    if (not valid) then return nil, failure; end
    if (profile.BorderType ~= nil and not IsValidGroupBorderType(profile.BorderType)) then return nil, "边框类型不正确：BorderType"; end
    local spellDefaults = {iconSizeWidth = 45, iconSizeHeight = 45, overrideSize = false, customBorderColor = {1, 0.1, 0.1, 1},
        customBorderSize = 2, customBorderType = 3, showOnFriends = true, showOnEnemies = true, showOnPlayers = true, showOnNpcs = true, showOnPets = true,
        animationTimer = 10, animationDisplayMode = 1, animationType = 2, glowType = 3, customBorderPath = "", useRelativeGlowTimer = false, useRelativeAnimationTimer = false};
    if (profile.IconGroups ~= nil and type(profile.IconGroups) ~= "table" or profile.CustomSpells2 ~= nil and type(profile.CustomSpells2) ~= "table") then return nil, "IconGroups 和 CustomSpells2 必须是配置表"; end
    for key, group in pairs(profile.IconGroups or {}) do
        if (not Finite(key) or key < 1 or key ~= math.floor(key) or type(group) ~= "table") then return nil, "图标组编号或内容不正确"; end
        valid, failure = ValidateImportShape(group, defaults, version);
        if (not valid) then return nil, failure; end
        if (group.BorderType ~= nil and not IsValidGroupBorderType(group.BorderType)) then return nil, "边框类型不正确：BorderType"; end
        for _, field in ipairs({"NpcBlacklist", "AlwaysShowMyAurasBlacklist", "Additions_DispellableSpells_Blacklist"}) do
            valid, failure = ValidateStringMap(group[field] or {});
            if (not valid) then return nil, failure; end
        end
    end
    for _, entry in pairs(profile.CustomSpells2 or {}) do
        if (type(entry) ~= "table" or entry.spellName ~= nil and type(entry.spellName) ~= "string") then return nil, "法术规则不是有效配置表"; end
        valid, failure = ValidateImportShape(entry, spellDefaults, version);
        if (not valid) then return nil, failure; end
        valid, failure = ValidateMembership(entry);
        if (not valid) then return nil, failure; end
        if (entry.showGlow ~= nil and not (Finite(entry.showGlow) and entry.showGlow >= 0) and not (version < 1 and type(entry.showGlow) == "boolean")) then return nil, "showGlow 必须是非负时间，旧布尔值仅支持早期配置"; end
        if (entry.enabledState ~= nil) then
            local legacy = {disabled = true, all = true, my = true};
            if (entry.enabledState ~= 1 and entry.enabledState ~= 2 and entry.enabledState ~= 3 and not (type(entry.enabledState) == "string" and legacy[entry.enabledState])) then return nil, "法术启用状态不正确"; end
        end
        if (entry.auraType ~= nil) then
            local legacy = {buff = true, debuff = true, ["buff/debuff"] = true};
            if (entry.auraType ~= 1 and entry.auraType ~= 2 and entry.auraType ~= 3 and not (type(entry.auraType) == "string" and legacy[entry.auraType])) then return nil, "光环类型不正确"; end
        end
        if (entry.animationDisplayMode ~= nil and entry.animationDisplayMode ~= 1 and entry.animationDisplayMode ~= 2 and entry.animationDisplayMode ~= 3) then return nil, "动画显示状态不正确"; end
        if (entry.animationType ~= nil and entry.animationType ~= addonTable.ICON_ANIMATION_TYPE_ALPHA and not (version < 16 and entry.animationType == 3)) then return nil, "动画类型不正确"; end
        if (entry.customBorderType ~= nil and entry.customBorderType ~= 1 and entry.customBorderType ~= 2 and entry.customBorderType ~= 3) then return nil, "边框类型不正确"; end
        if (entry.glowType ~= nil and (entry.glowType < 1 or entry.glowType > 5 or entry.glowType ~= math.floor(entry.glowType))) then return nil, "发光类型不正确"; end
    end
    for _, field in ipairs({"NpcBlacklist", "AlwaysShowMyAurasBlacklist", "Additions_DispellableSpells_Blacklist"}) do
        valid, failure = ValidateStringMap(profile[field] or {});
        if (not valid) then return nil, failure; end
    end
    local candidate = addonTable.deepcopy(profile);
    if (candidate.DBVersion == nil) then candidate.DBVersion = 0; end
    if (not Finite(candidate.DBVersion) or candidate.DBVersion < 0 or candidate.DBVersion > addonTable.DB_SCHEMA_VERSION) then return nil, "配置版本无效或来自更新版本，未改动当前配置"; end
    local original = addonTable.db;
    addonTable.db = candidate;
    local success, migrationFailure = pcall(function()
        addonTable.PrepareForeverProfile();
        addonTable.MigrateDB();
        addonTable.NormalizeForeverProfile();
    end);
    addonTable.db = original;
    if (not success) then return nil, "无法迁移导入配置，当前配置未改动：" .. tostring(migrationFailure); end
    return candidate;
end

function addonTable.PrepareSpellImport(entry)
    if (type(entry) ~= "table" or type(entry.spellName) ~= "string" or entry.spellName == "") then return nil, "导入内容不是有效法术规则"; end
    local candidate, failure = addonTable.PrepareProfileImport({DBVersion = addonTable.DB_SCHEMA_VERSION, DefaultSpellsLastSetImported = #addonTable.DefaultSpells2,
        IconGroups = addonTable.deepcopy(addonTable.db.IconGroups), CustomSpells2 = {entry}});
    if (not candidate) then return nil, failure; end
    return candidate.CustomSpells2[1];
end

function addonTable.ImportNewSpells(force)
    local db = addonTable.db;
    if (force == true) then
        db.DefaultSpellsLastSetImported = 0;
    end
    if (db.DefaultSpellsLastSetImported < #addonTable.DefaultSpells2) then
        local spellNamesAlreadyInUsersDB = { };
        for _, spellInfo in pairs(db.CustomSpells2) do
            if (spellInfo.spellName ~= nil) then
                spellNamesAlreadyInUsersDB[spellInfo.spellName] = true;
            end
        end
        local allNewSpells = { };
        for i = db.DefaultSpellsLastSetImported + 1, #addonTable.DefaultSpells2 do
            local set = addonTable.DefaultSpells2[i];
            for _, spellInfo in pairs(set) do
                if (spellInfo.spellName ~= nil and not spellNamesAlreadyInUsersDB[spellInfo.spellName]) then
                    table.insert(allNewSpells, spellInfo);
                end
            end
        end
        if (db.DefaultSpellsLastSetImported == 0) then
            for _, spellInfo in pairs(allNewSpells) do
                table.insert(db.CustomSpells2, addonTable.deepcopy(spellInfo));
            end
            FillInMissingEntriesIsSpells();
        else
            local allNewSpellsCount = table_count(allNewSpells);
            if (allNewSpellsCount > 0) then
                msgWithQuestion(string.format(L["Import new spells question: %d"], allNewSpellsCount),
                    function()
                        for _, spellInfo in pairs(allNewSpells) do
                            table.insert(db.CustomSpells2, addonTable.deepcopy(spellInfo));
                            Print(string.format(L["Imported '%s'"], spellInfo.spellName));
                        end
                        FillInMissingEntriesIsSpells();
                        Print(L["Imported successfully"]);
                        addonTable.RebuildSpellCache();
                    end,
                    function() end
                );
            end
        end
        db.DefaultSpellsLastSetImported = #addonTable.DefaultSpells2;
    end
end
