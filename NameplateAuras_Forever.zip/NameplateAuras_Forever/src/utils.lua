-- luacheck: no max line length
-- luacheck: globals LibStub WorldFrame format StaticPopup_Show StaticPopupDialogs CreateFrame debugprofilestop UIParent UNKNOWN DEFAULT_CHAT_FRAME
-- luacheck: globals OKAY YES NO ReloadUI wipe C_Spell C_Secrets InCombatLockdown GetLocale NORMAL_FONT_COLOR_CODE FONT_COLOR_CODE_CLOSE

local addonName, addonTable = ...;
local L = LibStub("AceLocale-3.0"):GetLocale(addonName);
local SML = LibStub("LibSharedMedia-3.0");
SML:Register("font", "NAurasForever_TeenBold", 		"Interface\\AddOns\\NameplateAuras_Forever\\media\\teen_bold.ttf", 255);
SML:Register("font", "NAurasForever_TexGyreHerosBold", "Interface\\AddOns\\NameplateAuras_Forever\\media\\texgyreheros-bold-webfont.ttf", 255);
local pairs, select, string_format = pairs, select, format;
local GetSpellTexture, GetSpellInfo = C_Spell.GetSpellTexture, C_Spell.GetSpellInfo;

addonTable.SpellTextureByID = setmetatable({
	[197690] = GetSpellTexture(71),		-- // override for defensive stance
	[179057] = GetSpellTexture(183591),	-- // override for Chaos Nova
}, {
	__index = function(t, key)
		local texture = GetSpellTexture(key);
		rawset(t, key, texture);
		return texture;
	end
});

addonTable.SpellNameByID = setmetatable({}, {
	__index = function(t, key)
		if (key == nil) then
			return nil;
		end

		local spellInfo = GetSpellInfo(key);
		local name = spellInfo ~= nil and spellInfo.name or nil;
		rawset(t, key, name);
		return name;
	end
});

function addonTable.GetSpellDisplayName(entry)
	if (entry.unresolvedSpellID) then
		return string_format(L["Unknown spell #%s"], tostring(entry.unresolvedSpellID));
	end
	return entry.spellName;
end

function addonTable.GetProfileOptions(aceDB)
	local source = LibStub("AceDBOptions-3.0"):GetOptionsTable(aceDB);
	if (GetLocale() ~= "zhCN") then return source; end
	local result, arguments = {}, {};
	for key, value in pairs(source) do result[key] = value; end
	for key, option in pairs(source.args) do
		arguments[key] = {};
		for field, value in pairs(option) do arguments[key][field] = value; end
	end
	result.name, result.desc, result.args = L["Profiles"], L["profiles:manage"], arguments;
	arguments.desc.name = L["profiles:intro"] .. "\n";
	arguments.descreset.name = L["profiles:reset-description"];
	arguments.reset.name, arguments.reset.desc = L["profiles:reset"], L["profiles:reset-tooltip"];
	arguments.current.name = function(info)
		return string_format(L["profiles:current"], NORMAL_FONT_COLOR_CODE .. info.handler:GetCurrentProfile() .. FONT_COLOR_CODE_CLOSE);
	end
	arguments.choosedesc.name = "\n" .. L["profiles:choose-description"];
	arguments.new.name, arguments.new.desc = L["profiles:new"], L["profiles:new-tooltip"];
	arguments.choose.name, arguments.choose.desc = L["profiles:choose"], L["profiles:choose-tooltip"];
	arguments.copydesc.name = "\n" .. L["profiles:copy-description"];
	arguments.copyfrom.name, arguments.copyfrom.desc = L["profiles:copy"], L["profiles:copy-tooltip"];
	arguments.deldesc.name = "\n" .. L["profiles:delete-description"];
	arguments.delete.name, arguments.delete.desc = L["profiles:delete"], L["profiles:delete-tooltip"];
	arguments.delete.confirmText = L["profiles:delete-confirm"];
	return result;
end

function addonTable.Print(...)
	local text = "";
	for i = 1, select("#", ...) do
		text = text..tostring(select(i, ...)).." "
	end
	DEFAULT_CHAT_FRAME:AddMessage(format("NameplateAuras Forever: %s", text), 0, 0.5, 0.5);
end

function addonTable.deepcopy(object)
	local lookup_table = {}
	local function _copy(another_object)
		if type(another_object) ~= "table" then
			return another_object;
		elseif lookup_table[another_object] then
			return lookup_table[another_object];
		end
		local new_table = { };
		lookup_table[another_object] = new_table;
		for index, value in pairs(another_object) do
			new_table[_copy(index)] = _copy(value);
		end
		return setmetatable(new_table, getmetatable(another_object));
	end
	return _copy(object);
end

function addonTable.msg(text)
	if (StaticPopupDialogs["NAURAS_FOREVER_MSG"] == nil) then
		StaticPopupDialogs["NAURAS_FOREVER_MSG"] = {
			text = "NAURAS_FOREVER_MSG",
			button1 = OKAY,
			timeout = 0,
			whileDead = true,
			hideOnEscape = true,
			preferredIndex = 3,
		};
	end
	StaticPopupDialogs["NAURAS_FOREVER_MSG"].text = text;
	StaticPopup_Show("NAURAS_FOREVER_MSG");
end

function addonTable.msgWithQuestion(text, funcOnAccept, funcOnCancel)
	local frameName = "NAURAS_FOREVER_MSG_QUESTION";
	if (StaticPopupDialogs[frameName] == nil) then
		StaticPopupDialogs[frameName] = {
			button1 = YES,
			button2 = NO,
			timeout = 0,
			whileDead = true,
			hideOnEscape = true,
			preferredIndex = 3,
		};
	end
	StaticPopupDialogs[frameName].text = text;
	StaticPopupDialogs[frameName].OnAccept = funcOnAccept;
	StaticPopupDialogs[frameName].OnCancel = funcOnCancel;
	StaticPopup_Show(frameName);
end

function addonTable.PopupReloadUI()
	if (StaticPopupDialogs["NAURAS_FOREVER_MSG_RELOAD"] == nil) then
		StaticPopupDialogs["NAURAS_FOREVER_MSG_RELOAD"] = {
			text = L["Please reload UI to apply changes"],
			button1 = L["Reload UI"],
			OnAccept = function() ReloadUI(); end,
			timeout = 0,
			whileDead = true,
			hideOnEscape = true,
			preferredIndex = 3,
		};
	end
	StaticPopup_Show("NAURAS_FOREVER_MSG_RELOAD");
end

function addonTable.table_contains_value(t, v)
	for _, value in pairs(t) do
		if (value == v) then
			return true;
		end
	end
	return false;
end

function addonTable.table_count(t)
	local count = 0;
	for _ in pairs(t) do
		count = count + 1;
	end
	return count;
end

function addonTable.array_delete_and_shift(array, index)
	local lastKey = index;
	for key in pairs(array) do
		if (type(key) == "number" and key > lastKey) then lastKey = key; end
	end
	for key = index, lastKey do array[key] = array[key+1]; end
end

function addonTable.ColorizeText(text, r, g, b)
	return string_format("|cff%02x%02x%02x%s|r", r*255, g*255, b*255, text);
end

-- Public spell metadata is shared by the options and secure filter compiler.
addonTable.SpellCatalog = { ByName = {}, Ready = false, Progress = 0 };
do
	local catalog = addonTable.SpellCatalog;
	local scanFrame = CreateFrame("Frame");
	local nextID, maximumID = 0, 2000000;
	local lastNotification = 0;
	scanFrame:Hide();

	function catalog:Add(spellID, info)
		info = info or C_Spell.GetSpellInfo(spellID);
		if (info and type(info.name) == "string" and info.name ~= "") then
			local ids = self.ByName[info.name];
			if (not ids) then
				ids = {};
				self.ByName[info.name] = ids;
			end
			ids[spellID] = info.iconID or 134400;
		end
	end

	function catalog:Seed()
		for _, set in ipairs(addonTable.DefaultSpells2 or {}) do
			for spellID in pairs(set) do
				self:Add(spellID);
			end
		end
		for _, entry in pairs(addonTable.db and addonTable.db.CustomSpells2 or {}) do
			if (type(entry.spellName) == "string") then
				local info = C_Spell.GetSpellInfo(entry.spellName);
				if (info) then self:Add(info.spellID, info); end
			end
			for spellID in pairs(type(entry.checkSpellID) == "table" and entry.checkSpellID or {}) do
				if (type(spellID) == "number") then self:Add(spellID); end
			end
		end
	end

	function catalog:Start()
		self:Seed();
		if (self.Ready or self.Running) then return; end
		self.Running = true;
		scanFrame:SetScript("OnUpdate", function()
			if (InCombatLockdown() or C_Secrets.ShouldAurasBeSecret()) then return; end
			local started = debugprofilestop();
			repeat
				nextID = nextID + 1;
				catalog:Add(nextID);
			until nextID >= maximumID or debugprofilestop() - started >= 2;
			catalog.Progress = math.floor(nextID * 100 / maximumID);
			if (catalog.Progress >= lastNotification + 5) then
				lastNotification = catalog.Progress;
				if (addonTable.OnSpellCatalogUpdated) then addonTable.OnSpellCatalogUpdated(); end
			end
			if (nextID >= maximumID) then
				catalog.Ready, catalog.Running = true, false;
				scanFrame:SetScript("OnUpdate", nil);
				scanFrame:Hide();
				if (addonTable.OnSpellInfoCachesReady) then addonTable.OnSpellInfoCachesReady(); end
			end
		end);
		scanFrame:Show();
	end
end
