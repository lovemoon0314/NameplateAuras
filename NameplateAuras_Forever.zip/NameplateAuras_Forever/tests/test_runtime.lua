-- Permanent isolated Lua 5.1 regression suite. No live WoW or private aura engine runs.
-- Pure Blizzard AnchorUtil/FunctionUtil geometry is loaded from the local source unchanged.
-- Usage: lua5.1 tests/test_runtime.lua /absolute/addon/path [test_name|--list]
-- Signature evidence: wow-ui-source 1.60.1.70862, Blizzard_AuraContainer:
-- Blizzard_CustomAuraContainer.lua:72-180,286-328; Blizzard_AuraContainer.lua:28-45;
-- Blizzard_CustomAuraButton.lua:87-97,159-213,243-249,379-400;
-- Blizzard_AuraContainerUtil.lua:311-418; Blizzard_AuraContainerShared.lua:107-149.
-- Duration/formatter calls follow the generated *ObjectAPI/SecondsFormatter docs.
-- We model external access contracts, NOT the private secret engine, assignment,
-- taint propagation, protected execution, or actual aura candidate evaluation.

assert(_VERSION == "Lua 5.1", "This suite requires real Lua 5.1")
local script = debug.getinfo(1, "S").source:sub(2)
local addonPath = arg[1] or script:match("^(.*)/tests/[^/]+$") or ".."
local selected = arg[2]
local tests = {}
local function test(name, fn) tests[#tests + 1] = {name = name, run = fn} end
local function eq(actual, expected, message)
    assert(actual == expected, (message or "values differ") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual))
end
local function truth(value, message) assert(value, message or "expected truthy value") end
local function count(t) local n = 0; for _ in pairs(t) do n = n + 1 end; return n end
local function copy(t)
    if type(t) ~= "table" then return t end
    local result = {}; for k, v in pairs(t) do result[copy(k)] = copy(v) end; return result
end
local function same(a, b)
    if type(a) ~= type(b) then return false end
    if type(a) ~= "table" then return a == b end
    for k, v in pairs(a) do if not same(v, b[k]) then return false end end
    for k in pairs(b) do if a[k] == nil then return false end end
    return true
end
local function raises(fn, pattern)
    local ok, err = pcall(fn)
    assert(not ok, "expected rejection")
    if pattern then truth(tostring(err):find(pattern, 1, true), "unexpected rejection: " .. tostring(err)) end
end
local function args(types, ...)
    local values = {...}
    eq(select("#", ...), #types, "argument count")
    for i, kind in ipairs(types) do
        local v = values[i]
        if kind == "number" then truth(type(v) == "number" and v == v, "expected number at " .. i)
        else eq(type(v), kind, "argument type " .. i) end
    end
end
local points = {TOPLEFT=true, TOP=true, TOPRIGHT=true, LEFT=true, CENTER=true, RIGHT=true, BOTTOMLEFT=true, BOTTOM=true, BOTTOMRIGHT=true}
local strata = {BACKGROUND=true, LOW=true, MEDIUM=true, HIGH=true, DIALOG=true, FULLSCREEN=true, FULLSCREEN_DIALOG=true, TOOLTIP=true}

local function harness(profile, loggedIn, locale)
    locale=locale or "enUS"
    local h = {frames={}, data={}, timers={}, units={}, plates={}, messages={}, calls={}, secret=false, combat=false,
        identitySecret=false, comparisonSecret=false, now=100, cpu=0, cpuStep=1, spellCalls=0, forbiddenReads=0, aceCreates=0, guiChanges=0}
    local env, addon = {}, {}
    h.env, h.addon = env, addon
    local function record(name) h.calls[name] = (h.calls[name] or 0) + 1 end
    local function reject(name) return function() h.forbiddenReads=h.forbiddenReads+1; error("forbidden real aura/identity read: " .. name) end end
    local std = {"assert", "error", "ipairs", "next", "pairs", "pcall", "select", "tonumber", "tostring", "type", "unpack", "setmetatable", "getmetatable", "rawget", "rawset"}
    for _, name in ipairs(std) do env[name] = _G[name] end
    env.math, env.string, env.table = copy(math), copy(string), copy(table)
    env._G, env.format, env.date = env, string.format, function() return "2026-11-08-00-00-00" end
    env.wipe = function(t) args({"table"}, t); for k in pairs(t) do t[k] = nil end; return t end
    env.UNKNOWN, env.OKAY, env.YES, env.NO = "Unknown", "Okay", "Yes", "No"
    env.SlashCmdList, env.StaticPopupDialogs = {}, {}
    env.StaticPopup_Show = function(key) args({"string"}, key); truth(env.StaticPopupDialogs[key]); h.popup=key end
    env.ReloadUI = function() record("ReloadUI") end
    env.DEFAULT_CHAT_FRAME = {AddMessage=function(_, text, r, g, b) args({"string","number","number","number"}, text,r,g,b); h.messages[#h.messages+1]=text end}
    env.GetBuildInfo = function() return "1.60.1", "70862", "", 16001 end
    env.GetLocale = function() return locale end
    env.GetTime = function() return h.now end
    env.debugprofilestop = function() h.cpu=h.cpu+h.cpuStep; return h.cpu end
    env.IsLoggedIn = function() return loggedIn == true end
    env.InCombatLockdown = function() return h.combat end
    env.issecretvalue = function(v) return v == h.secretValue end
    h.secretValue = {}
    env.C_Secrets = {
        ShouldAurasBeSecret=function() return h.secret end,
        CanCompareUnitTokens=function(a,b) args({"string","string"},a,b); return not h.comparisonDenied end,
        ShouldUnitComparisonBeSecret=function(a,b) args({"string","string"},a,b); return h.comparisonSecret end,
        ShouldUnitIdentityBeSecret=function(unit) args({"string"},unit); return h.identitySecret end,
    }
    local function unit(u) args({"string"},u); return h.units[u] or {} end
    env.UnitExists = function(u) return unit(u).exists == true end
    env.UnitIsUnit = function(a,b)
        args({"string","string"},a,b); record("UnitIsUnit")
        if h.comparisonSecret or h.comparisonDenied then error("comparison guard bypassed") end
        if h.secretComparisonResult then return h.secretValue end
        return a == b or (h.units[b] and h.units[b].alias == a) or false
    end
    env.UnitIsFriend = function(a,b) args({"string","string"},a,b); return unit(b).friendly == true end
    env.UnitIsPlayer = function(u) return unit(u).player == true end
    env.UnitIsOtherPlayersPet = function(u) return unit(u).pet == true end
    env.UnitCanAssist = function(a,b,immune,uninteractable)
        args({"string","string","boolean","boolean"},a,b,immune,uninteractable)
        local attrs=unit(b)
        if attrs.canAssist ~= nil then return attrs.canAssist end
        return attrs.friendly == true
    end
    env.UnitIsPlayerControlledOrGroupMember = function(u) return unit(u).controlled == true or u == "player" or u == "pet" end
    env.UnitName = function(u)
        record("UnitName"); if h.identitySecret then error("identity guard bypassed") end
        if h.secretName then return h.secretValue end
        return unit(u).name
    end
    env.UnitGUID, env.UnitAura, env.UnitBuff, env.UnitDebuff = reject("UnitGUID"), reject("UnitAura"), reject("UnitBuff"), reject("UnitDebuff")
    env.CombatLogGetCurrentEventInfo = reject("CombatLogGetCurrentEventInfo")
    env.C_UnitAuras = setmetatable({}, {__index=function(_,k) h.forbiddenReads=h.forbiddenReads+1; error("forbidden C_UnitAuras access: "..k) end})
    env.GetInstanceInfo = function() return "test", h.zone or "none", 0, "", 0, 0, false, h.zoneID or 0 end
    h.spells = {
        [118]={name="Polymorph", spellID=118, iconID=136071},
        [12824]={name="Polymorph", spellID=12824, iconID=136071},
        [122]={name="Frost Nova", spellID=122, iconID=135848},
        [139]={name="Renew", spellID=139, iconID=135953},
        [642]={name="Divine Shield", spellID=642, iconID=135896},
        [9001]={name="Other", spellID=9001, iconID=134400},
    }
    env.C_Spell = {
        GetSpellInfo=function(id)
            truth(type(id)=="number" or type(id)=="string", "spell identifier must be number/string")
            h.spellCalls=h.spellCalls+1
            if type(id)=="number" then return copy(h.spells[id]) end
            for _, info in pairs(h.spells) do if info.name==id then return copy(info) end end
        end,
        GetSpellTexture=function(id) truth(type(id)=="number" or type(id)=="string"); return h.spells[id] and h.spells[id].iconID end,
    }
    env.Enum = {
        LuaCurveType={Step=1, Linear=2}, NumericRuleFormatRounding={Up=1}, SecondsFormatterInterval={Seconds=1,Minutes=2,Hours=3},
        SecondsFormatterAbbreviation={OneLetter=1}, SecondsFormatterRounding={RoundUp=1},
        SecondsFormatterIntervalWhitespace={StripIgnoreLocale=1}, DurationTextBindingProperty={RemainingPercent=1,RemainingDuration=2},
        CustomAuraButtonDispelTypeTextureStyle={PreserveAsset=1}, AddOnRestrictionState={Inactive=0,Active=1},
    }
    env.AuraContainerSortMethod={ExpirationOnly=1,AuraInstanceIDOnly=2}
    env.AuraContainerSortDirection={Normal=1}
    -- Load the actual public layout implementation; do not replace geometry with a mock.
    env.CreateFromMixins=function(...)
        local result={}; for i=1,select("#",...) do for k,v in pairs(select(i,...)) do result[k]=v end end; return result
    end
    env.Mixin=function(target,...) for i=1,select("#",...) do for k,v in pairs(select(i,...)) do target[k]=v end end; return target end
    local shared=addonPath.."/../wow-ui-source/Interface/AddOns/Blizzard_SharedXMLBase/"
    for _,file in ipairs({"Mixin.lua","FunctionUtil.lua","AnchorUtil.lua"}) do
        local chunk=assert(loadfile(shared..file)); setfenv(chunk,env); chunk()
    end
    env.CreateColor = function(r,g,b,a) args({"number","number","number","number"},r,g,b,a); return {kind="Color",r=r,g=g,b=b,a=a} end
    env.C_XMLUtil={GetTemplateInfo=function(name) eq(name,"CustomAuraContainerTemplate"); return {} end}

    local methods, containerMethods, delegateMethods = {}, {}, {}
    local function guard(object, name)
        local d=h.data[object]; truth(d, "unknown script object")
        if d.owner and not h.data[d.owner].initializing and h.secret then
            h.blocked=(h.blocked or 0)+1; error("secret existing button access: " .. name)
        end
        return d
    end
    local function isObject(o, kind)
        local d=h.data[o]; truth(d, "expected script object")
        if kind then eq(d.kind,kind,"object type") end
        return d
    end
    local function descends(o, parent)
        local d=isObject(o)
        while d.parent do if d.parent==parent then return true end; d=isObject(d.parent) end
        return false
    end
    local function inbound(o, parent, kind)
        local d=isObject(o,kind); truth(descends(o,parent),"inbound object must descend from button")
        return d
    end
    local newObject
    newObject = function(kind, parent, owner)
        local object={}
        local d={kind=kind,parent=parent,owner=owner,shown=true,events={},scripts={},calls={},values={},groups={}}
        h.data[object]=d; h.frames[#h.frames+1]=object
        setmetatable(object, {
            __index=function(_, key)
                guard(object,tostring(key))
                local fn=(kind=="AuraContainer" and containerMethods[key]) or (kind=="CustomAuraButton" and delegateMethods[key]) or methods[key]
                if fn then return function(self,...)
                    eq(self,object,"method receiver"); guard(object,key)
                    d.calls[key]=(d.calls[key] or 0)+1; record(key)
                    d.callOrder=d.callOrder or {}; d.callOrder[#d.callOrder+1]=key
                    return fn(self,...)
                end end
                if d.values[key] ~= nil then return d.values[key] end
                -- Missing fields are allowed; missing method calls fail with Lua's nil-call error.
                return nil
            end,
            __newindex=function(_,key,value) guard(object,tostring(key)); d.values[key]=value end,
        })
        return object
    end
    local function valueMethod(target, name, signature, field)
        target[name]=function(self,...)
            args(signature,...); h.data[self][field or name]=copy({...})
        end
    end
    methods.IsForbidden=function(self,...) args({},...); return h.data[self].forbidden==true end
    methods.IsShown=function(self,...) args({},...); return h.data[self].shown end
    local function effectivelyVisible(object)
        local d=h.data[object]; return d.shown and (not d.parent or effectivelyVisible(d.parent))
    end
    local function changeVisibility(object,change)
        local before={}; for _,f in ipairs(h.frames) do before[f]=effectivelyVisible(f) end
        change(h.data[object])
        for _,f in ipairs(h.frames) do
            local visible=effectivelyVisible(f)
            if before[f]~=nil and before[f]~=visible then
                local fn=h.data[f].scripts[visible and "OnShow" or "OnHide"]; if fn then fn(f) end
            end
        end
    end
    methods.IsVisible=function(self,...) args({},...); return effectivelyVisible(self) end
    methods.GetParent=function(self,...) args({},...); return h.data[self].parent end
    methods.GetWidth=function(self,...) args({},...); return h.data[self].width or 0 end
    methods.GetHeight=function(self,...) args({},...); return h.data[self].height or 0 end
    methods.GetSize=function(self,...) args({},...); return self:GetWidth(),self:GetHeight() end
    methods.GetFrameLevel=function(self,...) args({},...); return h.data[self].frameLevel or 2 end
    methods.SetFrameLevel=function(self,v) args({"number"},v); h.data[self].frameLevel=v end
    methods.SetParent=function(self,parent) isObject(parent); changeVisibility(self,function(d) d.parent=parent end) end
    methods.SetSize=function(self,w,ht) args({"number","number"},w,ht); truth(w>=0 and ht>=0); h.data[self].width,h.data[self].height=w,ht end
    methods.ClearAllPoints=function(self,...)
        args({},...); local d=h.data[self]; d.points={}; d.allPoints=nil
    end
    methods.SetPoint=function(self,p,relative,rp,x,y)
        truth(points[p],"invalid anchor point"); if relative~=nil then isObject(relative) end
        if rp~=nil then truth(points[rp],"invalid relative anchor") end
        if x~=nil then args({"number"},x) end; if y~=nil then args({"number"},y) end
        local d=h.data[self]; d.points=d.points or {}; d.points[#d.points+1]={p,relative,rp,x,y}
    end
    methods.SetAllPoints=function(self,relative) isObject(relative); h.data[self].allPoints=relative end
    methods.Show=function(self,...) args({},...); changeVisibility(self,function(d) d.shown=true end) end
    methods.Hide=function(self,...) args({},...); changeVisibility(self,function(d) d.shown=false end) end
    methods.SetShown=function(self,v) args({"boolean"},v); if v then self:Show() else self:Hide() end end
    methods.SetFrameStrata=function(self,v) truth(strata[v],"invalid strata"); h.data[self].strata=v end
    valueMethod(methods,"SetAlpha",{"number"})
    valueMethod(methods,"SetScale",{"number"})
    methods.SetScript=function(self,name,fn) args({"string"},name); truth(fn==nil or type(fn)=="function"); h.data[self].scripts[name]=fn end
    methods.RegisterEvent=function(self,event) args({"string"},event); h.data[self].events[event]=true end
    methods.CreateTexture=function(self,name,layer)
        truth(name==nil or type(name)=="string"); truth(layer=="BORDER" or layer=="OVERLAY","invalid draw layer")
        return newObject("Texture",self,h.data[self].owner)
    end
    methods.CreateFontString=function(self,name,layer)
        truth(name==nil or type(name)=="string"); eq(layer,"OVERLAY"); return newObject("FontString",self,h.data[self].owner)
    end
    methods.SetTexture=function(self,v)
        isObject(self,"Texture"); truth(v==nil or type(v)=="string" or type(v)=="number","texture must be path/ID/nil")
        local d=h.data[self]; d.texture=v; d.atlas=nil; d.useAtlasSize=nil; d.atlasCoords=nil
    end
    -- Strict submitted-call fixture, NOT atlas lookup/rendering or pixel evidence.
    -- The addon contract requires an explicit bool even though the client has a default.
    methods.SetAtlas=function(self,...)
        isObject(self,"Texture"); args({"string","boolean"},...)
        local name,useSize=...
        eq(name,"UI-HUD-CoolDownManager-IconOverlay","unknown atlas fixture")
        local d=h.data[self]; d.atlas=name; d.useAtlasSize=useSize; d.texture=nil
        d.SetTexCoord=nil; d.atlasCoords=true -- Opaque native coordinates: no invented UV/pixels.
    end
    methods.ResetTexCoord=function(self,...)
        isObject(self,"Texture"); args({},...)
        local d=h.data[self]; d.SetTexCoord={0,1,0,1}; d.atlasCoords=nil
    end
    methods.SetFont=function(self,path,size,flags)
        isObject(self,"FontString"); args({"string","number","string"},path,size,flags); truth(path~="" and size>0); h.data[self].font={path,size,flags}; return true
    end
    methods.SetText=function(self,v)
        local kind=isObject(self).kind; truth(kind=="FontString" or kind=="GameTooltip")
        truth(type(v)=="number" or type(v)=="string"); h.data[self].text=v
        if kind=="GameTooltip" then h.data[self].lines={} end
    end
    methods.GetText=function(self,...)
        args({},...); local d=isObject(self,"FontString"); truth(not d.secretText,"private SecretAspect.Text prohibits GetText"); return d.text
    end
    valueMethod(methods,"SetTexCoord",{"number","number","number","number"})
    valueMethod(methods,"SetVertexColor",{"number","number","number","number"})
    valueMethod(methods,"SetTextColor",{"number","number","number","number"})
    valueMethod(methods,"SetShadowColor",{"number","number","number","number"})
    valueMethod(methods,"SetShadowOffset",{"number","number"})
    for _, name in ipairs({"SetReverse","SetHideCountdownNumbers","SetDrawSwipe","SetDrawEdge","SetMouseClickEnabled","SetMouseMotionEnabled","SetHideTooltipInCombat"}) do valueMethod(methods,name,{"boolean"}) end
    valueMethod(methods,"SetTooltipAnchorPoint",{"string","number","number"})
    methods.SetCooldownFromDurationObject=function(self,duration)
        isObject(self,"Cooldown"); eq(duration.kind,"Duration"); h.data[self].duration=duration
    end
    methods.CreateAnimationGroup=function(self,...) args({},...); return newObject("AnimationGroup",self,h.data[self].owner) end
    methods.CreateAnimation=function(self,kind) isObject(self,"AnimationGroup"); eq(kind,"Alpha"); return newObject("Animation",self,h.data[self].owner) end
    valueMethod(methods,"SetLooping",{"string"})
    for _, name in ipairs({"SetFromAlpha","SetToAlpha","SetDuration","SetOrder"}) do valueMethod(methods,name,{"number"}) end
    methods.Stop=function(self,...) args({},...); isObject(self,"AnimationGroup"); h.data[self].playing=false end
    methods.Play=function(self,...) args({},...); isObject(self,"AnimationGroup"); h.data[self].playing=true end
    methods.IsPlaying=function(self,...) args({},...); isObject(self,"AnimationGroup"); return h.data[self].playing==true end
    methods.Clear=function(self,...) args({},...); isObject(self,"Cooldown"); h.data[self].duration=nil end
    methods.SetOwner=function(self,owner,anchor)
        isObject(self,"GameTooltip"); isObject(owner); args({"string"},anchor); h.data[self].tooltipOwner=owner
    end
    methods.IsOwned=function(self,owner) isObject(self,"GameTooltip"); isObject(owner); return h.data[self].tooltipOwner==owner end
    methods.AddLine=function(self,text,r,g,b,wrap)
        isObject(self,"GameTooltip"); args({"string","number","number","number","boolean"},text,r,g,b,wrap)
        local d=h.data[self]; d.lines=d.lines or {}; d.lines[#d.lines+1]=text
    end

    -- Delegates are deliberately NOT exempt from guard(). Only container inbound
    -- methods remain accessible when existing custom buttons are restricted.
    delegateMethods.SetIcon=function(self,o) inbound(o,self,"Texture"); h.data[self].icon=o end
    delegateMethods.SetApplicationCount=function(self,o,options)
        args({"table"},options); inbound(o,self,"FontString").secretText=true; h.data[self].count=o
    end
    delegateMethods.ClearApplicationCount=function(self,...) args({},...); h.data[self].count=nil end
    delegateMethods.SetDurationCooldown=function(self,o) inbound(o,self,"Cooldown"); h.data[self].cooldown=o end
    delegateMethods.SetDurationText=function(self,o,options)
        args({"table"},options); eq(options.binding.kind,"Binding"); inbound(o,self,"FontString").secretText=true; h.data[self].time=o; h.data[self].binding=options.binding
    end
    delegateMethods.ClearDurationText=function(self,...) args({},...); h.data[self].time=nil end
    delegateMethods.ClearDispelTypeTextures=function(self,...) args({},...); h.data[self].dispel={} end
    delegateMethods.AddDispelTypeTexture=function(self,o,options)
        inbound(o,self,"Texture"); args({"table"},options); eq(options.style,env.Enum.CustomAuraButtonDispelTypeTextureStyle.PreserveAsset)
        args({"boolean","boolean","boolean"},options.showWithoutDispelType,options.showWhenHarmful,options.showWhenHelpful)
        for _, c in pairs(options.customDispelColorMap) do eq(c.kind,"Color") end
        local d=h.data[self]; d.dispel[#d.dispel+1]={o,copy(options)}
    end
    delegateMethods.ClearAuraShownAnimations=function(self,...) args({},...); h.data[self].animations={} end
    delegateMethods.AddAuraShownAnimation=function(self,o) inbound(o,self,"AnimationGroup"); local d=h.data[self]; d.animations[#d.animations+1]=o end
    for name, field in pairs({GetIcon="icon",GetApplicationCount="count",GetDurationCooldown="cooldown",GetDurationText="time"}) do
        local captured=field; delegateMethods[name]=function(self,...) args({},...); return h.data[self][captured] end
    end
    delegateMethods.GetDispelTypeTextureCount=function(self,...) args({},...); return #(h.data[self].dispel or {}) end

    local function candidate(v)
        args({"table"},v)
        for name, ids in pairs(v) do
            if name=="includeSpellIDs" or name=="excludeSpellIDs" then
                args({"table"},ids); for id, enabled in pairs(ids) do args({"number","boolean"},id,enabled); truth(id>0 and id==math.floor(id)) end
            elseif name=="isStealable" then args({"boolean"},ids)
            else error("unsupported candidate filter: "..name) end
        end
    end
    local function filter(v)
        args({"string"},v); local first=true
        for token in v:gmatch("[^|]+") do
            if first then truth(token=="HELPFUL" or token=="HARMFUL"); first=false
            else truth(token=="PLAYER" or token=="INCLUDE_NAME_PLATE_ONLY","unexpected aura filter token") end
        end
        truth(not first)
    end
    containerMethods.SetUnit=function(self,u) args({"string"},u); h.data[self].unit=u end
    containerMethods.SetEnabled=function(self,v) args({"boolean"},v); h.data[self].enabled=v end
    containerMethods.UpdateAllAuras=function(self,...) args({},...); h.data[self].rebuilds=(h.data[self].rebuilds or 0)+1 end
    containerMethods.SetFlowLayoutAxis=function(self,v) truth(v==0 or v==1); h.data[self].axis=v end
    containerMethods.SetFlowLayoutAnchorPoint=function(self,v) truth(points[v]); h.data[self].anchor=v end
    containerMethods.SetFlowLayoutGrowthDirection=function(self,x,y) truth(x==-1 or x==1); truth(y==-1 or y==1); h.data[self].growth={x,y} end
    containerMethods.SetFlowLayoutMaximumLineSize=function(self,v) args({"number"},v); truth(v>=0); h.data[self].lineSize=v end
    local function group(self,key) args({"string"},key); local g=h.data[self].groups[key]; truth(g,"missing aura group "..key); return g end
    containerMethods.AddAuraGroup=function(self,key,f,options)
        args({"string","string","table"},key,f,options); truth(key~=""); truth(not h.data[self].groups[key]); filter(f); candidate(options.candidateFilters)
        truth(type(options.initializeFrame)=="function"); truth(options.sortMethod==1 or options.sortMethod==2)
        local g={filter=f,candidate=copy(options.candidateFilters),enabled=true,options=copy(options),buttons={}}
        h.data[self].groups[key]=g
        -- A small fixed batch exercises initializeFrame without inventing private
        -- aura assignments. Callback gets unrestricted access to its new button.
        for _=1,2 do
            local button=newObject("CustomAuraButton",self)
            local d=h.data[button]; d.owner=button; d.initializing=true
            g.buttons[#g.buttons+1]=button
            options.initializeFrame(button)
            d.initializing=false
        end
    end
    containerMethods.SetAuraGroupFilterString=function(self,key,f) filter(f); group(self,key).filter=f end
    containerMethods.SetAuraGroupCandidateFilters=function(self,key,v) candidate(v); group(self,key).candidate=copy(v) end
    containerMethods.SetAuraGroupSortMethod=function(self,key,m,d) truth(m==1 or m==2); eq(d,1); group(self,key).sort={m,d} end
    containerMethods.SetAuraGroupLayout=function(self,key,v)
        args({"table"},v); for k,n in pairs(v) do
            truth(k=="elementSpacing" or k=="groupSpacing" or k=="elementWidth" or k=="elementHeight" or k=="layoutIndex"); args({"number"},n)
            if k=="elementWidth" or k=="elementHeight" then truth(n>=0) end
        end
        group(self,key).layout=copy(v)
    end
    containerMethods.SetAuraGroupEnabled=function(self,key,v) args({"boolean"},v); group(self,key).enabled=v end
    h.newFrame=function(kind) return newObject(kind or "Frame") end
    env.CreateFrame=function(kind,name,parent,template)
        truth(kind=="Frame" or kind=="Cooldown" or kind=="AuraContainer","unexpected frame type")
        truth(name==nil or type(name)=="string"); if parent then isObject(parent) end
        if kind=="AuraContainer" then eq(template,"CustomAuraContainerTemplate")
        elseif kind=="Cooldown" then eq(template,"CooldownFrameTemplate")
        else truth(template==nil,"unexpected frame template") end
        return newObject(kind,parent,parent and h.data[parent].owner)
    end
    env.UIParent, env.WorldFrame = newObject("Frame"), newObject("Frame")
    env.GameTooltip=newObject("GameTooltip",env.UIParent)
    env.GameTooltip:Hide()
    env.C_NamePlate={GetNamePlateForUnit=function(u) args({"string"},u); return h.plates[u] end,
        GetNamePlates=function() local list,seen={},{}; for _,p in pairs(h.plates) do if not seen[p] then list[#list+1]=p; seen[p]=true end end; return list end}

    local function apiObject(kind, signatures)
        local o={kind=kind,config={},calls={}}
        for name, sig in pairs(signatures) do
            local method, types=name,sig
            o[method]=function(self,...)
                eq(self,o); args(types,...); o.calls[method]=(o.calls[method] or 0)+1; o.config[method]=copy({...})
            end
        end
        return o
    end
    local function curve(kind)
        local o=apiObject(kind,{SetType={"number"}}); o.points={}
        o.AddPoint=function(self,x,y) eq(self,o); args({"number"},x); if kind=="ColorCurve" then eq(y.kind,"Color") else args({"number"},y) end; o.points[#o.points+1]={x,y} end
        return o
    end
    env.C_CurveUtil={CreateCurve=function() return curve("Curve") end,CreateColorCurve=function() record("CreateColorCurve"); return curve("ColorCurve") end}
    env.C_StringUtil={CreateNumericRuleFormatter=function() record("CreateNumericRuleFormatter"); return apiObject("Formatter",{SetBreakpoints={"table"}}) end}
    env.C_DurationUtil={
        CreateDuration=function() record("CreateDuration"); return apiObject("Duration",{SetTimeFromEnd={"number","number"}}) end,
        CreateDurationTextBinding=function()
            record("CreateDurationTextBinding")
            local o=apiObject("Binding",{SetFormatter={"table"},SetTextColorCurve={"table","number"},SetUpdateInterval={"number"},SetZeroDurationText={"string"},SetExpiredText={"string"}})
            o.SetFontString=function(self,f) eq(self,o); isObject(f,"FontString"); o.fontString=f end
            o.SetDuration=function(self,d) eq(self,o); eq(d.kind,"Duration"); o.duration=d end
            o.Assign=function(self,b) eq(self,o); eq(b.kind,"Binding"); o.config=copy(b.config) end
            o.SetEnabled=function(self,b) eq(self,o); args({"boolean"},b); o.enabled=b end
            o.Disable=function(self,...) eq(self,o); args({},...); o.enabled=false end
            o.UpdateFontString=function(self,...)
                eq(self,o); args({},...); truth(o.enabled,"disabled preview binding must not update text")
                isObject(o.fontString,"FontString"); truth(o.duration and o.duration.config.SetTimeFromEnd,"duration must be assigned before immediate update")
                o.calls.UpdateFontString=(o.calls.UpdateFontString or 0)+1; record("UpdateFontString")
                -- Capture the submitted native state, not a replacement formatter/curve engine.
                o.updatedEndTime=o.duration.config.SetTimeFromEnd[1]
                o.updatedConfig=copy(o.config)
            end
            return o
        end,
    }
    local function timer(delay,fn,repeating)
        args({"number","function"},delay,fn); truth(delay>=0)
        local t={delay=delay,fn=fn,repeating=repeating,canceled=false,fired=false}
        t.Cancel=function(self,...) eq(self,t); args({},...); t.canceled=true end
        h.timers[#h.timers+1]=t; return t
    end
    env.C_Timer={NewTimer=function(d,f) record("NewTimer"); return timer(d,f,false) end,
        NewTicker=function(d,f) record("NewTicker"); truth(d>0); return timer(d,f,true) end}
    h.pending=function(repeating) local n=0; for _,t in ipairs(h.timers) do if not t.canceled and not t.fired and t.repeating==repeating then n=n+1 end end; return n end
    h.flush=function()
        local snapshot={}; for _,t in ipairs(h.timers) do snapshot[#snapshot+1]=t end
        for _,t in ipairs(snapshot) do if not t.repeating and not t.fired and not t.canceled then t.fired=true; t.fn() end end
        eq(h.pending(false),0,"refresh callback must not schedule another timer")
    end
    h.tick=function() for _,t in ipairs(h.timers) do if t.repeating and not t.canceled then h.now=h.now+t.delay; t.fn() end end end
    local media={fonts={}}
    media.Register=function(self,kind,name,path,mask) eq(self,media); args({"string","string","string","number"},kind,name,path,mask); eq(kind,"font"); media.fonts[name]=path end
    media.Fetch=function(self,kind,name) eq(self,media); eq(kind,"font"); args({"string"},name); return media.fonts[name] or "Fonts\\FRIZQT__.TTF" end
    local libs={
        ["LibSharedMedia-3.0"]=media,
        ["AceLocale-3.0"]={GetLocale=function(_,name) eq(name,"NameplateAuras_Forever"); return setmetatable({}, {__index=function(_,k) return k end}) end},
        ["AceConfig-3.0"]={RegisterOptionsTable=function(_,name,options) args({"string","table"},name,options); record("RegisterOptionsTable") end},
        ["AceConfigDialog-3.0"]={AddToBlizOptions=function(_,name,label,parent)
            args({"string","string"},name,label); truth(parent==nil or type(parent)=="string")
            h.settingsCategories=h.settingsCategories or {}
            if parent then truth(h.settingsCategories[parent], "Settings parent category not found: "..parent) end
            h.settingsCategories[label]=true; record("AddToBlizOptions")
        end},
        ["AceDBOptions-3.0"]={GetOptionsTable=function(_,db) eq(db,h.ace); return {} end},
    }
    libs["AceDB-3.0"]={New=function(_,key,defaults)
        eq(key,"NameplateAurasForeverAceDB"); args({"table"},defaults); h.aceCreates=h.aceCreates+1
        local sv=env[key]; args({"table"},sv); sv.profiles=sv.profiles or {}
        sv.profiles.Default=sv.profiles.Default or profile or copy(defaults.profile)
        local ace={profile=sv.profiles.Default,callbacks={}}
        -- Minimal AceDB contract: missing top-level defaults are available through
        -- __index without overwriting explicit saved false/legacy version values.
        setmetatable(ace.profile,{__index=function(_,k) return copy(defaults.profile[k]) end})
        ace.RegisterCallback=function(owner,event,fn) args({"string","string","function"},owner,event,fn); ace.callbacks[event]=fn end
        h.ace=ace; h.defaults=defaults; return ace
    end}
    env.LibStub=function(name) args({"string"},name); truth(libs[name],"unmocked library: "..name); return libs[name] end
    env.hooksecurefunc=function(target,name,hook)
        args({"table","string","function"},target,name,hook); local original=target[name]; truth(type(original)=="function")
        target[name]=function(...) local result={original(...)}; hook(...); return unpack(result) end
    end
    addon.OnSpellInfoCachesReady=function() record("OnSpellInfoCachesReady") end
    addon.GuiOnProfileChanged=function() h.guiChanges=h.guiChanges+1 end
    addon.ShowGUI=function() record("ShowGUI") end
    -- No fallback to host _G: an unmocked runtime global fails immediately.
    local nullable={NameplateAurasForeverAceDB=true,NameplateAurasAceDB=true}
    setmetatable(env,{__index=function(_,key) if nullable[key] then return nil end; error("unmocked runtime global: "..tostring(key)) end})
    h.load=function(file)
        local chunk=assert(loadfile(addonPath.."/src/"..file)); setfenv(chunk,env); chunk("NameplateAuras_Forever",addon)
    end
    for _,file in ipairs({"consts.lua","utils.lua","spells.lua","database.lua","NameplateAuras.lua"}) do h.load(file) end
    h.event=function(name,...)
        local frame=addon.EventFrame; truth(h.data[frame].events[name],"event not registered: "..name)
        h.data[frame].scripts.OnEvent(frame,name,...)
    end
    h.login=function() h.event("PLAYER_LOGIN"); h.flush() end
    h.attach=function(u,plate,attributes)
        plate=plate or h.newFrame(); h.plates[u]=plate; h.units[u]=attributes or {exists=true,name="NPC"}
        h.data[plate].values.unitToken=u; h.event("NAME_PLATE_UNIT_ADDED",u)
        return plate,addon.Nameplates[plate]
    end
    h.config=function() addon.UpdateAllNameplates(); h.flush() end
    h.scan=function(times)
        for _=1,times do for _,f in ipairs(h.frames) do local d=h.data[f]; if d.scripts.OnUpdate and d.shown then d.scripts.OnUpdate(f,0.016) end end end
    end
    return h
end

local function fresh(profile)
    local h=harness(profile or {DBVersion=34,DefaultSpellsLastSetImported=4,CustomSpells2={},IconGroups={}})
    h.login(); return h
end
local function rule(h,name,overrides)
    local a=h.addon
    local e={spellName=name or "Polymorph",enabledState=a.CONST_SPELL_MODE_ALL,auraType=a.AURA_TYPE_ANY,iconGroups={[1]=true},
        showOnFriends=true,showOnEnemies=true,showOnPlayers=true,showOnPets=true,showOnNpcs=true}
    for k,v in pairs(overrides or {}) do e[k]=v end
    return e
end
local function catalog(h,ready)
    h.addon.SpellCatalog.ByName={Polymorph={[118]=136071,[12824]=136071},["Frost Nova"]={[122]=135848},Renew={[139]=135953},Other={[9001]=134400}}
    h.addon.SpellCatalog.Ready=ready~=false
end
local function configured(overrides,groupOverrides)
    local h=fresh(); catalog(h)
    h.addon.db.CustomSpells2={rule(h,nil,overrides)}
    for k,v in pairs(groupOverrides or {}) do h.addon.db.IconGroups[1][k]=v end
    local p,s=h.attach("nameplate1"); return h,p,s[1]
end
local function active(h,state)
    local result={}; for _,g in pairs(h.data[state.Container].groups) do if g.enabled then result[#result+1]=g end end; return result
end
local function included(h,state)
    local ids={}; for _,g in ipairs(active(h,state)) do for id,on in pairs(g.candidate.includeSpellIDs or {}) do if on then ids[id]=true end end end; return ids
end
local function stopped(h,state)
    eq(h.pending(true),0,"preview ticker survives stop")
    truth(state.Preview); eq(h.data[state.Preview.Root].shown,false)
    for _,v in ipairs(state.Preview.Buttons) do eq(v.Binding.enabled,false,"preview binding survives stop") end
end

-- Harness negative controls ensure failures cannot be hidden by permissive mocks.
test("mock_contract_rejects_bad_signatures_and_unknown_methods",function()
    local h=fresh(); local f=h.newFrame()
    raises(function() f:SetParent("UIParent") end,"expected script object")
    local tex=f:CreateTexture(nil,"OVERLAY"); raises(function() tex:SetTexture({}) end,"texture must")
    local text=f:CreateFontString(nil,"OVERLAY"); raises(function() text:SetFont(123,12,"OUTLINE") end,"argument type")
    raises(function() f:MadeUpMethod() end)
    raises(function() h.env.CreateFrame("Button",nil,nil,"Invented") end,"unexpected frame type")
    raises(function() h.env.C_UnitAuras.GetAuraDataByIndex("nameplate1",1) end,"forbidden C_UnitAuras")
    local binding=h.env.C_DurationUtil.CreateDurationTextBinding()
    raises(function() binding:UpdateFontString() end,"disabled preview binding")
    binding:SetEnabled(true)
    raises(function() binding:UpdateFontString() end,"expected script object")
end)
test("mock_secret_guard_includes_delegates_getters_and_children",function()
    local h,_,s=configured(); local slot=s.Slots[1]; local button,v=next(slot.Buttons)
    truth(button and v); h.secret=true
    raises(function() button:GetIcon() end,"secret existing button access")
    raises(function() button:SetIcon(v.Texture) end,"secret existing button access")
    raises(function() button:GetWidth() end,"secret existing button access")
    raises(function() v.Time:GetText() end,"secret existing button access")
    s.Container:SetUnit("nameplate1"); s.Container:SetEnabled(true)
    h.secret=false; raises(function() v.Time:GetText() end,"SecretAspect.Text")
end)
test("initialize_and_login_are_idempotent",function()
    local h=fresh(); local db=h.addon.db
    for _=1,3 do h.event("PLAYER_LOGIN"); h.event("PLAYER_ENTERING_WORLD") end
    eq(h.aceCreates,1); eq(h.guiChanges,1); eq(h.addon.db,db)
    eq(h.calls.RegisterOptionsTable,2); eq(h.calls.AddToBlizOptions,2); eq(count(h.ace.callbacks),3)
end)
test("already_logged_in_initializes_once",function()
    local h=harness(nil,true); h.event("PLAYER_LOGIN"); h.event("PLAYER_ENTERING_WORLD"); eq(h.aceCreates,1)
end)
test("saved_variables_are_independent_and_defaults_retained",function()
    local h=harness(); local legacy={profiles={Default={marker="legacy",CustomSpells2={}}}}
    local snapshot=copy(legacy); h.env.NameplateAurasAceDB=legacy; h.login()
    truth(h.env.NameplateAurasForeverAceDB~=legacy); truth(same(legacy,snapshot)); truth(h.addon.db~=legacy.profiles.Default)
    for k,v in pairs(h.defaults.profile) do truth(h.addon.AceDBDefaults.profile[k]~=nil,"saved default missing "..k); if type(v)=="table" then truth(h.addon.AceDBDefaults.profile[k]~=v) end end
    truth(h.addon.db.CustomSpells2 and h.addon.db.IconGroups and h.addon.db.DBVersion)
end)
test("detached_nil_nameplate_remove_does_not_throw",function()
    local h=fresh(); h.event("NAME_PLATE_UNIT_REMOVED",nil); h.event("NAME_PLATE_UNIT_REMOVED","nameplate99")
end)
test("added_missing_or_forbidden_plate_does_not_throw",function()
    local h=fresh(); h.event("NAME_PLATE_UNIT_ADDED","nameplate99")
    local p=h.newFrame(); h.data[p].forbidden=true; h.plates.nameplate1=p; h.event("NAME_PLATE_UNIT_ADDED","nameplate1"); eq(h.addon.Nameplates[p],nil)
end)
test("unit_added_removed_reuses_state_without_real_aura_reads",function()
    local h,p,s=configured(); local original=s
    for i=1,4 do
        h.event("NAME_PLATE_UNIT_REMOVED","nameplate1"); eq(s.Unit,nil); eq(h.data[s.Container].unit,""); eq(h.data[s.Container].enabled,false)
        local _,states=h.attach("nameplate1",p); eq(states[1],original); s=states[1]
    end
    eq(h.forbiddenReads,0)
end)
test("late_old_unit_removed_cannot_clear_reused_plate",function()
    local h,p,s=configured(); h.attach("nameplate2",p)
    h.event("NAME_PLATE_UNIT_REMOVED","nameplate1"); eq(s.Unit,"nameplate2"); eq(h.data[s.Container].unit,"nameplate2"); eq(h.data[s.Container].enabled,true)
end)
test("group_add_delete_reorder_reuses_state_without_stale_units",function()
    local h,p,s=configured(); local db=h.addon.db
    db.IconGroups[2]=h.addon.GetIconGroupDefaultOptions("Second"); db.IconGroups[2].DefaultIconSizeWidth=31
    db.CustomSpells2[1].iconGroups[2]=true; h.config()
    local second=h.addon.Nameplates[p][2]; truth(second); eq(second.Unit,"nameplate1")
    db.IconGroups[1],db.IconGroups[2]=db.IconGroups[2],db.IconGroups[1]; h.config()
    eq(h.addon.Nameplates[p][1],s); eq(h.addon.Nameplates[p][2],second)
    eq(active(h,s)[1].layout.elementWidth,31)
    db.IconGroups[2]=nil; h.config()
    eq(h.data[second.Container].enabled,false); eq(h.data[second.Container].shown,false)
    eq(second.Unit,nil,"deleted group retains unit state"); eq(h.data[second.Container].unit,"","deleted container retains real unit")
end)
test("deleted_group_container_clears_unit_token",function()
    local h,p=configured(); local db=h.addon.db
    db.IconGroups[2]=h.addon.GetIconGroupDefaultOptions("Second"); h.config()
    local second=h.addon.Nameplates[p][2]; db.IconGroups[2]=nil; h.config()
    eq(h.data[second.Container].unit,"","deleted container retains real unit")
end)
test("group_readd_reuses_state_and_replaces_current_spec",function()
    local h,p=configured(); local db=h.addon.db
    db.IconGroups[2]=h.addon.GetIconGroupDefaultOptions("Second"); db.CustomSpells2[1].iconGroups[2]=true; h.config()
    local second=h.addon.Nameplates[p][2]; local button=next(second.Slots[1].Buttons)
    db.IconGroups[2]=nil; h.config()
    db.IconGroups[2]=h.addon.GetIconGroupDefaultOptions("Replacement"); db.IconGroups[2].DefaultIconSizeWidth=29
    db.CustomSpells2={rule(h,"Frost Nova",{iconGroups={[2]=true},auraType=2})}; h.config()
    eq(h.addon.Nameplates[p][2],second); eq(second.Unit,"nameplate1")
    eq(h.data[second.Container].unit,"nameplate1"); eq(#active(h,second),1)
    truth(same(included(h,second),{[122]=true}),"stale candidates survived readd")
    eq(h.data[button].width,29,"existing button used stale spec")
    eq(second.Slots[1].Spec.Group.IconGroupName,"Replacement")
end)
test("removed_rule_disables_all_old_aura_groups",function()
    local h,_,s=configured(); truth(#active(h,s)>0); h.addon.db.CustomSpells2={}; h.config(); eq(#active(h,s),0)
end)
test("config_changes_coalesce_at_most_one_timer",function()
    local h,_,s=configured(); local before=h.calls.NewTimer or 0
    for _=1,20 do h.addon.UpdateAllNameplates(); h.addon.RebuildAuraSortFunctions() end
    eq(h.pending(false),1); eq(h.calls.NewTimer-before,1)
    local refreshes=h.data[s.Container].calls.SetEnabled; h.flush(); eq(h.pending(false),0); eq(h.data[s.Container].calls.SetEnabled-refreshes,1)
end)
test("target_filter_and_secret_comparison_fail_closed",function()
    local h,_,s=configured(nil,{ShowOnlyOnTarget=true}); eq(h.data[s.Container].enabled,false)
    h.units.target={exists=true,alias="nameplate1"}; h.event("PLAYER_TARGET_CHANGED"); eq(h.data[s.Container].enabled,true)
    for _,flag in ipairs({"comparisonSecret","comparisonDenied","secretComparisonResult"}) do
        h[flag]=true; h.event("PLAYER_TARGET_CHANGED"); eq(h.data[s.Container].enabled,false,flag); h[flag]=false
    end
end)
test("friendly_enemy_and_zone_predicate_filters",function()
    local h,_,s=configured({showOnFriends=false}); h.units.nameplate1.friendly=true; h.event("UNIT_FACTION","nameplate1"); h.flush(); eq(#active(h,s),0)
    h.units.nameplate1.friendly=false; h.event("UNIT_FLAGS","nameplate1"); h.flush(); eq(#active(h,s),2)
    local g=h.addon.db.IconGroups[1]; g.EnemyUnitsAurasEnabledZoneTypes.party=false; h.zone="party"
    h.event("ZONE_CHANGED_NEW_AREA"); h.flush(); eq(h.data[s.Container].enabled,false)
    g.ShowAurasOnEnemyTargetEvenInDisabledAreas=true; h.units.target={exists=true,alias="nameplate1"}; h.event("PLAYER_TARGET_CHANGED"); eq(h.data[s.Container].enabled,true)
    h.units.nameplate1.friendly=true; g.FriendlyUnitsAurasEnabledZoneTypes.party=false; h.config(); eq(h.data[s.Container].enabled,false)
    g.ShowAurasOnAlliedTargetEvenInDisabledAreas=true; h.config(); eq(h.data[s.Container].enabled,true)
end)
test("actor_player_pet_npc_and_membership_predicates",function()
    local h,_,s=configured({showOnPlayers=false,showOnPets=false,showOnNpcs=false}); eq(#active(h,s),0)
    local e=h.addon.db.CustomSpells2[1]
    for _,kind in ipairs({"player","pet","npc"}) do
        h.units.nameplate1.player=kind=="player"; h.units.nameplate1.pet=kind=="pet"
        local field=kind=="player" and "showOnPlayers" or kind=="pet" and "showOnPets" or "showOnNpcs"
        e[field]=true; h.config(); eq(#active(h,s),2); e[field]=false
    end
    e.showOnNpcs=true; e.iconGroups[1]=false; h.config(); eq(#active(h,s),0)
end)
test("only_mine_rules_use_player_not_pet_candidate",function()
    local h,_,s=configured({enabledState=3}); eq(#active(h,s),2)
    for _,g in ipairs(active(h,s)) do truth(g.filter:find("|PLAYER",1,true)); eq(g.candidate.isFromPlayerOrPlayerPet,nil) end
end)
test("all_rules_do_not_add_player_filter",function()
    local h,_,s=configured(); for _,g in ipairs(active(h,s)) do eq(g.filter:find("|PLAYER",1,true),nil) end
end)
test("all_false_blacklists_do_not_block_mine_or_dispel",function()
    local h,_,s=configured(nil,{AlwaysShowMyAuras=true,AlwaysShowMyAurasBlacklist={Polymorph=false},NpcBlacklist={NPC=false},
        Additions_DispellableSpells=true,Additions_DispellableSpells_Blacklist={Other=false}})
    h.addon.SpellCatalog.Ready=false; h.config(); eq(#active(h,s),5); eq(h.data[s.Container].enabled,true)
end)
test("nonempty_mine_blacklist_has_no_identity_fallback",function()
    local h,_,s=configured(nil,{AlwaysShowMyAuras=true,AlwaysShowMyAurasBlacklist={Polymorph=true}})
    eq(#active(h,s),3,"enemy permits harmful-only mine blacklist")
    for _,g in ipairs(active(h,s)) do if g.candidate.excludeSpellIDs then truth(g.filter:find("HARMFUL",1,true)); truth(g.candidate.excludeSpellIDs[118]); truth(g.candidate.excludeSpellIDs[12824]) end end
    h.units.nameplate1.friendly=true; h.config(); eq(#active(h,s),3)
    for _,g in ipairs(active(h,s)) do if g.candidate.excludeSpellIDs then truth(g.filter:find("HELPFUL",1,true)) end end
    h.addon.SpellCatalog.Ready=false; h.config(); eq(#active(h,s),2,"incomplete catalog must block fallback")
end)
test("nonempty_dispel_blacklist_fails_closed",function()
    local h,_,s=configured(nil,{Additions_DispellableSpells=true,Additions_DispellableSpells_Blacklist={Other=true}})
    eq(#active(h,s),2); for _,g in ipairs(active(h,s)) do eq(g.candidate.isStealable,nil) end
end)
test("npc_blacklist_secret_nil_and_secret_name_fail_closed",function()
    local h,_,s=configured(nil,{NpcBlacklist={Blocked=true}})
    h.identitySecret=true; local before=h.calls.UnitName or 0; h.event("PLAYER_TARGET_CHANGED"); eq(h.data[s.Container].enabled,false); eq(h.calls.UnitName or 0,before)
    h.identitySecret=false; h.units.nameplate1.name=nil; h.event("PLAYER_TARGET_CHANGED"); eq(h.data[s.Container].enabled,false)
    h.units.nameplate1.name="NPC"; h.secretName=true; h.event("PLAYER_TARGET_CHANGED"); eq(h.data[s.Container].enabled,false)
    h.secretName=false; h.units.nameplate1.name="Blocked"; h.event("PLAYER_TARGET_CHANGED"); eq(h.data[s.Container].enabled,false)
end)
test("all_explicit_name_rules_include_ranks_and_dynamic_index_updates",function()
    local h,_,s=configured(); h.addon.db.CustomSpells2[#h.addon.db.CustomSpells2+1]=rule(h,"Frost Nova"); h.config()
    local ids=included(h,s); truth(ids[118] and ids[12824] and ids[122]); eq(ids[9001],nil)
    h.spells[12825]={name="Polymorph",spellID=12825,iconID=136071}; h.addon.SpellCatalog:Add(12825); h.addon.OnSpellInfoCachesReady(); h.flush()
    truth(included(h,s)[12825],"new rank not added to compiled candidates")
end)
test("two_legal_same_name_rank_rules_are_not_deleted",function()
    -- Valid pre-v33 actor configuration must be supplied in a legacy fixture.
    local h=fresh({DBVersion=0,DefaultSpellsLastSetImported=4,CustomSpells2={
        [118]={checkSpellID=118,playerNpcMode=1},[12824]={checkSpellID=12824,playerNpcMode=1}},IconGroups={}})
    catalog(h); eq(count(h.addon.db.CustomSpells2),2); local _,states=h.attach("nameplate1")
    truth(included(h,states[1])[118] and included(h,states[1])[12824])
    h.addon.ReloadDB(); h.flush(); eq(count(h.addon.db.CustomSpells2),2)
end)

for _,version in ipairs({0,22,34,35}) do
    local v=version
    test("migration_"..v.."_preserves_values_and_is_repeatable",function()
        local e={spellName="Polymorph",checkSpellID={["118"]=true,["12824"]=false},showOnFriends=false,showOnEnemies=false,
            showOnPlayers=false,showOnNpcs=false,showOnPets=false,overrideSize=false,iconGroups={[1]=true},enabledState=2,auraType=3,marker={"entry"}}
        local p={DBVersion=v,DefaultSpellsLastSetImported=4,CustomSpells2={e},IconGroups={[1]={IconGroupName="Saved",ShowStacks=false,ShowCooldownText=false,ShowCooldownAnimation=false,marker="group"}},marker={"profile"}}
        if v<23 then p.IconXOffset=17; p.ShowAuraTooltip=false; p.TimerTextSizeMode="absolute" end
        local h=fresh(p); local db=h.addon.db
        eq(db.DBVersion,v==35 and 35 or 34); eq(db.marker[1],"profile"); eq(db.IconGroups[1].marker,"group")
        eq(db.IconGroups[1].ShowStacks,false); eq(db.IconGroups[1].ShowCooldownText,false); eq(db.IconGroups[1].ShowCooldownAnimation,false)
        local out=db.CustomSpells2[1]; eq(out.marker[1],"entry"); eq(out.showOnFriends,false); eq(out.showOnEnemies,false)
        eq(out.showOnPlayers,false); eq(out.showOnNpcs,false); eq(out.showOnPets,false); eq(out.overrideSize,false)
        eq(out.checkSpellID[118],true); eq(out.checkSpellID[12824],false,"disabled rank expanded by migration")
        if v<23 then eq(db.IconGroups[1].IconXOffset,17); eq(db.IconGroups[1].ShowAuraTooltip,false) end
        local snapshot=copy(db); h.addon.ReloadDB(); h.flush(); truth(same(db,snapshot),"repeat reload mutates migrated profile")
    end)
end
test("future_db_does_not_rerun_zero_or_one_migration",function()
    local h=fresh({DBVersion=35,DefaultSpellsLastSetImported=4,IconSize="future-owned",CustomSpells2={[118]={spellName="Polymorph",spellID=118,iconGroups={[1]=true}}},IconGroups={}})
    eq(h.addon.db.DBVersion,35); eq(h.addon.db.IconSize,"future-owned"); truth(h.addon.db.CustomSpells2[118]); eq(h.addon.db.CustomSpells2[118].spellID,118)
end)
test("sparse_groups_and_membership_are_remapped",function()
    local h=fresh({DBVersion=34,DefaultSpellsLastSetImported=4,IconGroups={[1]={IconGroupName="One"},[3]={IconGroupName="Three"}},
        CustomSpells2={{spellName="Polymorph",iconGroups={[1]=false,[3]=true}}}})
    local db=h.addon.db; eq(#db.IconGroups,2); eq(db.IconGroups[2].IconGroupName,"Three"); eq(db.IconGroups[3],nil)
    eq(db.CustomSpells2[1].iconGroups[1],false); eq(db.CustomSpells2[1].iconGroups[2],true); eq(db.CustomSpells2[1].iconGroups[3],nil)
    catalog(h); local _,states=h.attach("nameplate1"); eq(#active(h,states[1]),0); truth(included(h,states[2])[12824])
end)
for _,case in ipairs({{name="number",value=118,ids={[118]=true}}, {name="string",value="12824",ids={[12824]=true}},
    {name="empty_table",value={},ids={}}, {name="all_false",value={[118]=false,[12824]=false},ids={}},
    {name="invalid_string",value="not-a-spell",ids={}}}) do
    local c=case
    test("check_spell_id_"..c.name.."_never_expands",function()
        local h=fresh({DBVersion=34,DefaultSpellsLastSetImported=4,IconGroups={},CustomSpells2={{spellName="Polymorph",checkSpellID=copy(c.value)}}})
        catalog(h); local _,states=h.attach("nameplate1"); local ids=included(h,states[1]); truth(same(ids,c.ids),"explicit ID constraint expanded")
        h.addon.ReloadDB(); h.flush(); truth(same(included(h,states[1]),c.ids),"reload expanded constraint")
    end)
end
test("default_spell_sets_are_deep_copied_across_profiles",function()
    local h=fresh({DBVersion=34,DefaultSpellsLastSetImported=0,CustomSpells2={},IconGroups={}})
    local a=h.addon; truth(#a.db.CustomSpells2>0); local old=a.db; local first=old.CustomSpells2[1]; local name=first.spellName
    first.iconGroups[1]=false; first.customBorderColor[1]=0.321
    h.ace.profile={DBVersion=34,DefaultSpellsLastSetImported=0,CustomSpells2={},IconGroups={}}; a.ReloadDB(); h.flush()
    local found; for _,e in pairs(a.db.CustomSpells2) do if e.spellName==name then found=e end end
    truth(found and found~=first); truth(found.iconGroups~=first.iconGroups); eq(found.iconGroups[1],true); truth(found.customBorderColor~=first.customBorderColor)
    for _,set in ipairs(a.DefaultSpells2) do for _,e in pairs(set) do truth(e~=first and e~=found); if e.spellName==name then truth(e.iconGroups==nil,"defaults mutated by profile") end end end
end)
test("secret_style_refresh_never_touches_existing_buttons",function()
    local h,_,s=configured(); h.secret=true
    local before=h.calls.SetIcon or 0
    h.addon.db.IconGroups[1].DefaultIconSizeWidth=37; h.config(); h.event("PLAYER_TARGET_CHANGED")
    eq(h.calls.SetIcon or 0,before); eq(h.blocked or 0,0)
    for _,slot in ipairs(s.Slots) do truth(slot.NeedsSkin) end
    h.event("ADDON_RESTRICTION_STATE_CHANGED",0,h.env.Enum.AddOnRestrictionState.Active); h.flush()
    eq(h.calls.SetIcon or 0,before); eq(h.blocked or 0,0)
end)
test("new_secret_group_initialization_callback_is_allowed",function()
    local h=fresh(); catalog(h); h.secret=true; h.addon.db.CustomSpells2={rule(h)}
    local _,states=h.attach("nameplate1"); truth(#active(h,states[1])==2); eq(h.blocked or 0,0); truth((h.calls.SetIcon or 0)>0)
end)
test("combat_style_refresh_defers_and_recovers_once",function()
    local h,_,s=configured(); h.combat=true; local before=h.calls.SetIcon
    h.addon.db.IconGroups[1].FontScale=1.5; h.config(); eq(h.calls.SetIcon,before)
    h.combat=false; h.event("PLAYER_REGEN_ENABLED"); eq(h.calls.SetIcon-before,4)
    local after=h.calls.SetIcon; h.event("PLAYER_REGEN_ENABLED"); eq(h.calls.SetIcon,after); eq(h.pending(false),0)
    for _,slot in ipairs(s.Slots) do eq(slot.NeedsSkin,false) end
end)
test("secret_recovery_coalesces_and_skins_only_once",function()
    local h,_,s=configured(); h.secret=true; h.addon.db.IconGroups[1].FontScale=1.5; h.config(); local before=h.calls.SetIcon
    h.secret=false; local timers=h.calls.NewTimer
    for _=1,10 do h.event("ADDON_RESTRICTION_STATE_CHANGED",0,h.env.Enum.AddOnRestrictionState.Inactive) end
    eq(h.pending(false),1); eq(h.calls.NewTimer-timers,1); h.flush(); eq(h.calls.SetIcon-before,4)
    for _,slot in ipairs(s.Slots) do eq(slot.NeedsSkin,false) end
    h.event("PLAYER_REGEN_ENABLED"); eq(h.calls.SetIcon-before,4); eq(h.pending(false),0)
end)
test("preview_start_blocked_in_combat_or_secret",function()
    local h,_,s=configured()
    h.combat=true; h.addon.SwitchTestMode(); eq(h.pending(true),0); eq(s.Preview,nil)
    h.combat=false; h.secret=true; h.addon.SwitchTestMode(); eq(h.pending(true),0); eq(s.Preview,nil)
end)
test("preview_close_cancels_ticker_and_bindings",function()
    local h,_,s=configured(); h.addon.SwitchTestMode(); eq(h.pending(true),1); eq(h.data[s.Container].enabled,false)
    h.tick(); h.addon.SwitchTestMode(); stopped(h,s); eq(h.data[s.Container].enabled,true); eq(h.forbiddenReads,0)
end)
for _,event in ipairs({"PLAYER_ENTERING_WORLD","PLAYER_REGEN_DISABLED"}) do
    local ev=event
    test("preview_auto_stops_on_"..ev:lower(),function()
        local h,_,s=configured(); h.addon.SwitchTestMode(); if ev=="PLAYER_REGEN_DISABLED" then h.combat=true end
        h.event(ev); stopped(h,s)
    end)
end
test("profile_reload_stops_preview",function()
    local h,_,s=configured(); h.addon.SwitchTestMode(); h.ace.profile={DBVersion=34,DefaultSpellsLastSetImported=4,CustomSpells2={},IconGroups={}}
    h.ace.callbacks.OnProfileChanged(); h.flush(); stopped(h,s); eq(h.addon.db,h.ace.profile)
    eq(h.addon.IsPreviewActive(),false)
    truth(h.messages[#h.messages]:find("配置已重载",1,true),"profile reload silently stops preview")
end)
test("preview_secret_transition_stops_without_button_access",function()
    local h,_,s=configured(); h.addon.SwitchTestMode(); h.secret=true; h.tick(); stopped(h,s); eq(h.blocked or 0,0)
end)
test("catalog_scans_only_limited_budget_and_pauses_when_restricted",function()
    local h=fresh(); local before=h.spellCalls; h.cpuStep=1; h.scan(3)
    truth(h.spellCalls-before>0); truth(h.spellCalls-before<=6,"catalog ignored 2ms time budget")
    eq(h.addon.SpellCatalog.Ready,false); eq(h.addon.SpellCatalog.Running,true)
    before=h.spellCalls; h.secret=true; h.scan(2); eq(h.spellCalls,before)
    h.secret=false; h.combat=true; h.scan(2); eq(h.spellCalls,before)
    h.combat=false; h.scan(1); truth(h.spellCalls>before)
end)
test("runtime_events_never_read_unit_aura_guid_or_combat_log",function()
    local h,_,s=configured(); h.event("PLAYER_TARGET_CHANGED"); h.event("UNIT_FLAGS","nameplate1"); h.event("UNIT_FACTION","player")
    h.event("ZONE_CHANGED_NEW_AREA"); h.flush(); h.event("PLAYER_ENTERING_WORLD"); h.event("PLAYER_REGEN_ENABLED")
    truth(s); eq(h.forbiddenReads,0)
end)

test("mine_and_dispel_candidates_are_disjoint_for_stealable_buffs",function()
    local h,_,s=configured(nil,{AlwaysShowMyAuras=true,Additions_DispellableSpells=true})
    local mine,dispel
    for _,g in ipairs(active(h,s)) do
        if g.filter:find("HELPFUL|PLAYER",1,true) and not g.candidate.includeSpellIDs then mine=g end
        if g.candidate.isStealable == true then dispel=g end
    end
    truth(mine and dispel)
    eq(mine.candidate.isStealable,false,"mine fallback duplicates the dispel group")
    eq(dispel.candidate.isStealable,true)
end)
test("blacklist_permission_uses_assist_not_friendliness",function()
    local h,_,s=configured(nil,{AlwaysShowMyAuras=true,AlwaysShowMyAurasBlacklist={Polymorph=true}})
    h.units.nameplate1.friendly=true; h.units.nameplate1.canAssist=false; h.config()
    for _,g in ipairs(active(h,s)) do
        if not g.candidate.includeSpellIDs then truth(g.filter:find("HARMFUL|PLAYER",1,true)) end
    end
    h.units.nameplate1.friendly=false; h.units.nameplate1.canAssist=true; h.config()
    for _,g in ipairs(active(h,s)) do
        if not g.candidate.includeSpellIDs then truth(g.filter:find("HELPFUL|PLAYER",1,true)) end
    end
end)
test("disabled_stacks_clear_the_client_application_binding",function()
    local h,_,s=configured(nil,{ShowStacks=false})
    for _,slot in ipairs(s.Slots) do
        for button,v in pairs(slot.Buttons) do
            eq(h.data[button].count,nil); eq(h.data[v.Count].shown,false)
        end
    end
end)

test("time_and_stacks_render_above_cooldown_without_reparenting",function()
    local h,_,s=configured()
    for _,slot in ipairs(s.Slots) do
        for button,v in pairs(slot.Buttons) do
            eq(h.data[v.Overlay].parent,button)
            eq(h.data[v.Time].parent,v.Overlay); eq(h.data[v.Count].parent,v.Overlay)
            truth(h.data[v.Overlay].frameLevel > v.Cooldown:GetFrameLevel())
        end
    end
end)
test("secret_skin_recovery_requests_client_assignment_rebuild",function()
    local h,_,s=configured(); h.secret=true
    h.addon.db.IconGroups[1].FontScale=1.4; h.config()
    local before=h.data[s.Container].rebuilds or 0
    h.secret=false; h.event("PLAYER_REGEN_ENABLED")
    eq((h.data[s.Container].rebuilds or 0)-before,1)
    h.event("PLAYER_REGEN_ENABLED"); eq((h.data[s.Container].rebuilds or 0)-before,1)
end)

test("client_formatter_preserves_ceil_and_tenths_contract",function()
    local h,_,s=configured()
    local rules=s.Slots[1].Spec.Binding.config.SetFormatter[1].config.SetBreakpoints[1]
    eq(#rules,4)
    eq(rules[1].threshold,0); eq(rules[1].step,0.1); eq(rules[1].rounding,h.env.Enum.NumericRuleFormatRounding.Up); eq(rules[1].format,"%.1f")
    eq(rules[2].threshold,10); eq(rules[2].step,1); eq(rules[2].rounding,h.env.Enum.NumericRuleFormatRounding.Up)
    eq(rules[3].threshold,60); eq(rules[3].format,"%dm"); eq(rules[3].components[1].div,60); eq(rules[3].components[1].rounding,h.env.Enum.NumericRuleFormatRounding.Up)
    truth(rules[4].threshold>3600); eq(rules[4].format,"")
    h.addon.db.IconGroups[1].MinTimeToShowTenthsOfSeconds=0; h.config()
    local without=s.Slots[1].Spec.Binding.config.SetFormatter[1].config.SetBreakpoints[1]
    eq(without[1].threshold,0); eq(without[1].step,1); eq(without[1].format,"%.0f"); eq(#without,3)
end)
test("same_unit_token_reassigned_to_new_plate_detaches_previous",function()
    local h,p,s=configured()
    local old=s.Container
    local new=h.newFrame(); h.attach("nameplate1",new)
    eq(s.Unit,nil); eq(h.data[old].unit,""); eq(h.data[old].enabled,false)
    eq(h.addon.Nameplates[new][1].Unit,"nameplate1"); truth(p~=new)
end)

test("settings_profiles_parent_resolves_registered_display_category",function()
    local h=fresh()
    truth(h.settingsCategories["NameplateAuras Forever"])
    truth(h.settingsCategories.Profiles)
    truth(type(h.env.SlashCmdList.NAMEPLATEAURASFOREVER)=="function")
end)
test("damaged_profile_import_is_rejected_before_mutating_live_db",function()
    local h=fresh(); local original=copy(h.addon.db)
    for _,profile in ipairs({
        {DBVersion=0,TimerTextSoonToExpireColor=false,CustomSpells2={},IconGroups={}},
        {DBVersion=25,CustomSpells2={{spellName="Polymorph",iconGroups={["1"]=true}}},IconGroups={}},
        {DBVersion=35,CustomSpells2={},IconGroups={}}
    }) do
        local ok,message=h.addon.ImportProfile(profile)
        eq(ok,false); truth(type(message)=="string"); truth(same(h.addon.db,original))
    end
end)
test("single_spell_import_validates_shape_and_preserves_live_profile",function()
    local h=fresh(); local original=copy(h.addon.db)
    for _,value in ipairs({42,{spellName="Polymorph",iconGroups=false},{spellName="Polymorph",iconSizeWidth=true}}) do
        local out,message=h.addon.PrepareSpellImport(value)
        eq(out,nil); truth(type(message)=="string"); truth(same(h.addon.db,original))
    end
    local input=rule(h,"Polymorph"); local out=h.addon.PrepareSpellImport(input)
    truth(out and out~=input and out.iconGroups~=input.iconGroups); truth(same(h.addon.db,original))
end)
test("profile_import_rolls_back_when_reload_fails",function()
    local h=fresh(); local original=copy(h.addon.db)
    local real=h.addon.ReloadDB
    h.addon.ReloadDB=function() error("injected reload failure") end
    local ok,message=h.addon.ImportProfile({DBVersion=34,DefaultSpellsLastSetImported=4,CustomSpells2={},IconGroups={{IconGroupName="Imported"}}})
    eq(ok,false); truth(message:find("injected reload failure",1,true)); truth(same(h.addon.db,original))
    h.addon.ReloadDB=real
end)
test("valid_profile_import_keeps_false_and_independent_input",function()
    local h=fresh()
    local input={DBVersion=34,DefaultSpellsLastSetImported=4,CustomSpells2={},IconGroups={{IconGroupName="Imported",ShowStacks=false}}}
    local snapshot=copy(input); truth(h.addon.ImportProfile(input))
    eq(h.addon.db.IconGroups[1].IconGroupName,"Imported"); eq(h.addon.db.IconGroups[1].ShowStacks,false)
    truth(same(input,snapshot)); truth(h.addon.db.IconGroups~=input.IconGroups)
end)
test("legacy_false_glow_does_not_become_permanent_glow",function()
    local h=fresh({DBVersion=0,DefaultSpellsLastSetImported=4,CustomSpells2={[118]={checkSpellID=118,showGlow=false,playerNpcMode=1}},IconGroups={}})
    eq(h.addon.db.CustomSpells2[1].showGlow,nil)
end)
test("unknown_spell_id_recovers_when_public_metadata_arrives",function()
    local h=fresh({DBVersion=0,DefaultSpellsLastSetImported=4,CustomSpells2={[7000]={checkSpellID=7000,playerNpcMode=1}},IconGroups={}})
    local entry=h.addon.db.CustomSpells2[1]; eq(entry.unresolvedSpellID,7000)
    h.spells[7000]={name="Arrived Spell",spellID=7000,iconID=134400}
    h.addon.SpellCatalog:Add(7000); h.addon.OnSpellInfoCachesReady(); h.flush()
    eq(entry.unresolvedSpellID,nil); eq(entry.spellName,"Arrived Spell")
    local _,states=h.attach("nameplate1"); truth(included(h,states[1])[7000])
end)

test("malformed_optional_spell_fields_are_rejected",function()
    local h=fresh(); local original=copy(h.addon.db)
    for key,value in pairs({showGlow=false,enabledState=false,auraType=false,animationTimer=false,animationDisplayMode=9,animationType=42,glowType=10,customBorderType=4}) do
        local entry=rule(h); entry[key]=value
        local result,message=h.addon.PrepareSpellImport(entry)
        eq(result,nil,"accepted malformed "..key); truth(type(message)=="string"); truth(same(h.addon.db,original))
    end
end)
test("legacy_sort_and_anchor_strings_migrate_before_modern_validation",function()
    local h=fresh()
    local input={DBVersion=0,DefaultSpellsLastSetImported=4,SortMode="by-expire-time-asc",IconAnchor="TOPLEFT",CustomSpells2={},IconGroups={}}
    truth(h.addon.ImportProfile(input))
    eq(h.addon.db.IconGroups[1].SortMode,h.addon.AURA_SORT_MODE_EXPIRETIME)
    eq(h.addon.db.IconGroups[1].IconAnchor,h.addon.ICON_ALIGN_TOP_RIGHT)
end)
test("ui_valid_target_scale_eight_survives_import_and_reload",function()
    local h=fresh()
    truth(h.addon.ImportProfile({DBVersion=34,DefaultSpellsLastSetImported=4,CustomSpells2={},IconGroups={{IconScaleTarget=8}}}))
    eq(h.addon.db.IconGroups[1].IconScaleTarget,8)
    h.addon.ReloadDB(); h.flush(); eq(h.addon.db.IconGroups[1].IconScaleTarget,8)
end)

test("stored_invalid_states_fail_closed_and_false_glow_stays_off",function()
    local h=fresh({DBVersion=34,DefaultSpellsLastSetImported=4,CustomSpells2={{spellName="Polymorph",showGlow=false,enabledState=false,iconGroups={[1]=true}}},IconGroups={}})
    local entry=h.addon.db.CustomSpells2[1]
    eq(entry.showGlow,nil); eq(entry.enabledState,h.addon.CONST_SPELL_MODE_DISABLED)
    catalog(h); local _,states=h.attach("nameplate1"); eq(#active(h,states[1]),0)
end)
test("malformed_blacklist_keys_are_rejected_without_commit",function()
    local h=fresh(); local original=copy(h.addon.db)
    local result,message=h.addon.ImportProfile({DBVersion=34,CustomSpells2={},IconGroups={{AlwaysShowMyAurasBlacklist={[42]=true}}}})
    eq(result,false); truth(type(message)=="string"); truth(same(h.addon.db,original))
end)

local function previewContext(h,group,category,entry,id)
    h.addon.GetPreviewContext=function() return group or 1,category,entry,id end
end
local function previewElements(state)
    local result={}; for _,group in ipairs(state.Preview.Groups) do for _,button in ipairs(group.elements) do result[#result+1]=button end end
    return result
end
local function clearedPreview(h,state)
    eq(h.data[state.Preview.Root].shown,false)
    for _,v in ipairs(state.Preview.Buttons) do
        eq(v.Binding.enabled,false); eq(h.data[v.Button].shown,false)
        eq(h.data[v.Cooldown].duration,nil)
        if v.GlowAnimation then eq(h.data[v.GlowAnimation].playing,false) end
        if v.BlinkAnimation then eq(h.data[v.BlinkAnimation].playing,false) end
        eq(h.data[v.Texture].SetAlpha[1],1)
    end
end

test("preview_content_bounds_and_official_twelve_alignment_combinations",function()
    local h,_,s=configured(); local group=h.addon.db.IconGroups[1]
    group.DefaultIconSizeWidth=45; group.DefaultIconSizeHeight=31; group.IconSpacing=1
    h.addon.SwitchTestMode()
    local expected={{"BOTTOMLEFT","BOTTOMRIGHT","BOTTOMLEFT","TOPLEFT"},{"TOPLEFT","TOPRIGHT","BOTTOMRIGHT","TOPRIGHT"},{"LEFT","RIGHT","BOTTOM","TOP"}}
    for align=1,3 do for direction=1,4 do
        group.IconAnchor=align; group.IconGrowDirection=direction; h.config()
        local root=s.Preview.Root; local rd=h.data[root]; local vertical=direction>=3
        eq(rd.width,vertical and 45 or 183); eq(rd.height,vertical and 127 or 31)
        local elements=previewElements(s); eq(#elements,4)
        for i,button in ipairs(elements) do
            local p=h.data[button].points[1]; eq(p[1],expected[align][direction]); eq(p[2],root); eq(p[3],p[1])
            local sign=direction==2 or direction==4; local offset=(i-1)*(vertical and 32 or 46)*(sign and -1 or 1)
            eq(p[4],vertical and 0 or offset); eq(p[5],vertical and offset or 0)
        end
    end end
    eq(h.env.AnchorUtil.FlowDirection.Left,-1); eq(h.env.AnchorUtil.FlowDirection.Up,1)
    eq(h.forbiddenReads,0)
end)
test("preview_bbox_removes_single_icon_center_offset",function()
    local h,_,s=configured(); h.addon.SwitchTestMode(); eq(h.data[s.Preview.Root].width,183); eq(h.data[s.Preview.Root].height,45)
    eq(h.data[s.Preview.Root].points[1][1],"CENTER")
    eq(h.data[s.Preview.Buttons[1].Button].points[1][2],s.Preview.Root)
end)
test("preview_target_alpha_scale_strata_parent_and_attachment_refresh",function()
    local h,p,s=configured(nil,{IconAlpha=.25,IconAlphaTarget=.8,IconScaleTarget=2,TargetStrata="DIALOG",NonTargetStrata="LOW"})
    h.addon.SwitchTestMode(); local root=s.Preview.Root
    eq(h.data[root].SetAlpha[1],.25); eq(h.data[root].SetScale[1],1); eq(h.data[root].strata,"LOW"); eq(h.data[root].parent,h.env.UIParent)
    h.units.target={exists=true,alias="nameplate1"}; h.event("PLAYER_TARGET_CHANGED")
    eq(h.data[root].SetAlpha[1],.8); eq(h.data[root].SetScale[1],2); eq(h.data[root].strata,"DIALOG")
    h.units.target.alias="nameplate99"; h.event("PLAYER_TARGET_CHANGED"); eq(h.data[root].SetAlpha[1],.25); eq(h.data[root].SetScale[1],1)
    h.units.target.exists=false; h.addon.db.IconGroups[1].UseTargetAlphaIfNotTargetSelected=true; h.config(); eq(h.data[root].SetAlpha[1],.8); eq(h.data[root].strata,"LOW")
    local health=h.newFrame(); p.UnitFrame=h.newFrame(); p.UnitFrame.HealthBarsContainer=health
    local group=h.addon.db.IconGroups[1]; group.AttachType=h.addon.ATTACH_TYPE_HEALTHBAR; group.NameplateIsParent=true
    group.FrameAnchor="BOTTOMRIGHT"; group.FrameAnchorToNameplate="TOPLEFT"; group.IconXOffset=17; group.IconYOffset=-23; h.config()
    eq(h.data[root].parent,health); local point=h.data[root].points[1]
    eq(point[1],"BOTTOMRIGHT"); eq(point[2],health); eq(point[3],"TOPLEFT"); eq(point[4],17); eq(point[5],-23)
    group.NameplateIsParent=false; h.config(); eq(h.data[root].parent,h.env.UIParent)
end)
test("preview_border_page_covers_all_colors_and_independent_toggles",function()
    local h,_,s=configured(); local group=h.addon.db.IconGroups[1]
    local keys={"BuffBordersColor","DebuffBordersMagicColor","DebuffBordersCurseColor","DebuffBordersDiseaseColor","DebuffBordersPoisonColor","DebuffBordersOtherColor"}
    for i,key in ipairs(keys) do group[key]={i/7,.25,.75,i/8} end
    previewContext(h,1,6); h.addon.SwitchTestMode(); eq(#previewElements(s),6); eq(#s.Preview.Buttons,6)
    for i,v in ipairs(s.Preview.Buttons) do
        local border=i==1 and v.BuffBorder or v.DebuffBorder; local hidden=i==1 and v.DebuffBorder or v.BuffBorder
        eq(h.data[border].shown,true); eq(h.data[hidden].shown,false)
        for j=1,4 do eq(h.data[border].SetVertexColor[j],group[keys[i]][j]) end
    end
    group.ShowBuffBorders=false; h.config(); eq(h.data[s.Preview.Buttons[1].BuffBorder].shown,false)
    group.ShowDebuffBorders=false; h.config(); for i=2,6 do eq(h.data[s.Preview.Buttons[i].DebuffBorder].shown,false) end
    group.ShowBuffBorders=true; group.ShowDebuffBorders=true; group.BorderType=h.addon.BORDER_TYPE_CUSTOM; group.BorderFilePath="Interface\\custom.tga"; h.config()
    eq(h.data[s.Preview.Buttons[2].DebuffBorder].texture,group.BorderFilePath)
    group.BorderType=h.addon.BORDER_TYPE_DISABLED; h.config(); for _,v in ipairs(s.Preview.Buttons) do eq(h.data[v.BuffBorder].shown,false); eq(h.data[v.DebuffBorder].shown,false) end
    previewContext(h,1,2); h.addon.OnPreviewContextChanged(); eq(#previewElements(s),4)
    for i=5,6 do eq(h.data[s.Preview.Buttons[i].Button].shown,false); eq(s.Preview.Buttons[i].Binding.enabled,false) end
end)
test("preview_selected_rule_style_and_static_metadata_refresh",function()
    local h,_,s=configured(); local entry=h.addon.db.CustomSpells2[1]; local group=h.addon.db.IconGroups[1]
    entry.overrideSize=true; entry.iconSizeWidth=31; entry.iconSizeHeight=59
    entry.customBorderType=h.addon.BORDER_TYPE_CUSTOM; entry.customBorderPath="Interface\\selected.tga"; entry.customBorderColor={.1,.2,.3,.4}
    group.ShowBuffBorders=false; group.ShowDebuffBorders=false
    previewContext(h,1,7,entry,118); h.addon.SwitchTestMode()
    for _,v in ipairs(s.Preview.Buttons) do
        eq(h.data[v.Button].width,31); eq(h.data[v.Button].height,59); eq(h.data[v.Texture].texture,136071)
        local border=v.Harmful and v.DebuffBorder or v.BuffBorder; eq(h.data[border].shown,true); eq(h.data[border].texture,entry.customBorderPath)
        eq(h.data[border].SetVertexColor[4],.4)
    end
    entry.auraType=h.addon.AURA_TYPE_BUFF; h.config(); for _,v in ipairs(s.Preview.Buttons) do eq(v.Harmful,false); eq(h.data[v.DebuffBorder].shown,false) end
    entry.auraType=h.addon.AURA_TYPE_DEBUFF; h.config(); for _,v in ipairs(s.Preview.Buttons) do eq(v.Harmful,true); eq(h.data[v.BuffBorder].shown,false) end
    entry.overrideSize=false; entry.customBorderType=h.addon.BORDER_TYPE_DISABLED; h.config()
    eq(h.data[s.Preview.Buttons[1].Button].width,group.DefaultIconSizeWidth); eq(h.data[s.Preview.Buttons[1].BuffBorder].shown,false); eq(h.data[s.Preview.Buttons[1].DebuffBorder].shown,false)
end)
test("preview_selected_unresolved_spell_uses_question_mark_and_does_not_mutate_db",function()
    local h,_,s=configured(); local entry=h.addon.db.CustomSpells2[1]; entry.spellName="Unresolved"
    previewContext(h,1,7,entry); local snapshot=copy(h.addon.db); h.addon.SwitchTestMode()
    for _,v in ipairs(s.Preview.Buttons) do eq(h.data[v.Texture].texture,134400) end
    for _=1,3 do h.tick(); h.addon.OnPreviewContextChanged() end
    truth(same(h.addon.db,snapshot)); eq(h.forbiddenReads,0)
end)
test("preview_supported_glow_blink_toggle_without_restart_or_leaks",function()
    local h,_,s=configured(); local entry=h.addon.db.CustomSpells2[1]
    previewContext(h,1,7,entry,118); h.addon.SwitchTestMode()
    entry.showGlow=h.addon.GLOW_TIME_INFINITE; entry.glowType=h.addon.GLOW_TYPE_PIXEL; entry.animationDisplayMode=h.addon.ICON_ANIMATION_DISPLAY_MODE_ALWAYS; h.config()
    local glow,blink=s.Preview.Buttons[1].GlowAnimation,s.Preview.Buttons[1].BlinkAnimation
    for _,v in ipairs(s.Preview.Buttons) do eq(h.data[v.Glow].shown,true); eq(h.data[v.GlowAnimation].playing,true); eq(h.data[v.BlinkAnimation].playing,true) end
    local plays=h.calls.Play; h.tick(); eq(h.calls.Play,plays,"ticker restarts animation")
    entry.showGlow=5; entry.animationDisplayMode=h.addon.ICON_ANIMATION_DISPLAY_MODE_THRESHOLD; h.config()
    eq(h.data[glow].playing,false); eq(h.data[blink].playing,false)
    for _,v in ipairs(s.Preview.Buttons) do eq(h.data[v.Glow].shown,false); eq(h.data[v.Texture].SetAlpha[1],1) end
    entry.showGlow=h.addon.GLOW_TIME_INFINITE; entry.animationDisplayMode=h.addon.ICON_ANIMATION_DISPLAY_MODE_ALWAYS; h.config()
    eq(s.Preview.Buttons[1].GlowAnimation,glow); eq(s.Preview.Buttons[1].BlinkAnimation,blink)
    h.addon.SwitchTestMode(); clearedPreview(h,s)
end)
test("preview_public_container_visibility_and_selected_actor_membership_filters",function()
    local h,_,s=configured(); local entry=h.addon.db.CustomSpells2[1]; local group=h.addon.db.IconGroups[1]
    previewContext(h,1,7,entry,118); h.addon.SwitchTestMode(); eq(h.data[s.Preview.Root].shown,true)
    group.ShowOnlyOnTarget=true; h.config(); clearedPreview(h,s)
    h.units.target={exists=true,alias="nameplate1"}; h.event("PLAYER_TARGET_CHANGED"); eq(h.data[s.Preview.Root].shown,true)
    entry.enabledState=h.addon.CONST_SPELL_MODE_DISABLED; h.config(); clearedPreview(h,s)
    entry.enabledState=h.addon.CONST_SPELL_MODE_MYAURAS; h.config(); eq(h.data[s.Preview.Root].shown,true)
    for _,field in ipairs({"showOnEnemies","showOnNpcs"}) do entry[field]=false; h.config(); clearedPreview(h,s); entry[field]=true end
    entry.iconGroups[1]=false; h.config(); clearedPreview(h,s); entry.iconGroups[1]=true
    group.EnemyUnitsAurasEnabledZoneTypes.none=false; h.config(); clearedPreview(h,s)
    group.ShowAurasOnEnemyTargetEvenInDisabledAreas=true; h.config(); eq(h.data[s.Preview.Root].shown,true)
    h.units.nameplate1.friendly=true; group.FriendlyUnitsAurasEnabledZoneTypes.none=false; h.config(); clearedPreview(h,s)
    group.ShowAurasOnAlliedTargetEvenInDisabledAreas=true; entry.showOnFriends=true; h.config(); eq(h.data[s.Preview.Root].shown,true)
    entry.showOnFriends=false; h.config(); clearedPreview(h,s); eq(h.forbiddenReads,0)
end)
test("preview_current_group_switch_hides_old_samples_and_reuses_bounded_pool",function()
    local h,p,s=configured(); local db=h.addon.db
    db.IconGroups[2]=h.addon.GetIconGroupDefaultOptions("Second"); db.IconGroups[2].DefaultIconSizeWidth=27; h.config()
    local second=h.addon.Nameplates[p][2]
    previewContext(h,1,6); h.addon.SwitchTestMode(); eq(#s.Preview.Buttons,6); eq(second.Preview,nil)
    local one=s.Preview; previewContext(h,2,2); local before=h.calls.SetIcon; h.addon.OnPreviewContextChanged()
    clearedPreview(h,s); eq(h.data[second.Preview.Root].shown,true); eq(h.data[second.Preview.Buttons[1].Button].width,27)
    eq(h.calls.SetIcon,before,"context-only change restyles real buttons")
    for _=1,8 do previewContext(h,1,6); h.addon.OnPreviewContextChanged(); previewContext(h,2,2); h.addon.OnPreviewContextChanged() end
    eq(s.Preview,one); eq(#s.Preview.Buttons,6); eq(#second.Preview.Buttons,4)
    db.IconGroups[2]=nil; h.config(); clearedPreview(h,second)
    previewContext(h,1,2); h.addon.OnPreviewContextChanged(); eq(h.data[s.Preview.Root].shown,true); eq(#previewElements(s),4)
end)
test("preview_dispel_page_applies_enabled_size_glow_zone_and_blacklist",function()
    local h,_,s=configured(nil,{Additions_DispellableSpells=true,DispelIconSizeWidth=28,DispelIconSizeHeight=61})
    local group=h.addon.db.IconGroups[1]; previewContext(h,1,9); h.addon.SwitchTestMode()
    for _,v in ipairs(s.Preview.Buttons) do eq(h.data[v.Button].width,28); eq(h.data[v.Button].height,61); eq(v.Harmful,false); eq(h.data[v.GlowAnimation].playing,true) end
    group.Additions_DispellableSpells=false; h.config(); clearedPreview(h,s)
    group.Additions_DispellableSpells=true; group.Additions_Dispel_InstanceTypes.none=false; h.config(); clearedPreview(h,s)
    group.Additions_Dispel_InstanceTypes.none=true; group.Additions_DispellableSpells_Blacklist.Other=true; h.config(); clearedPreview(h,s)
    group.Additions_DispellableSpells_Blacklist.Other=false; h.config(); eq(h.data[s.Preview.Root].shown,true)
    group.Additions_DispellableSpells_GlowType=h.addon.GLOW_TYPE_NONE; h.config(); eq(h.data[s.Preview.Buttons[1].Glow].shown,false)
end)
test("preview_clock_reuses_formatter_binding_and_does_not_reset_on_style_change",function()
    local h,_,s=configured(); h.addon.SwitchTestMode(); local first=s.Preview.Buttons[1]; local duration=first.Duration; local binding=first.Binding
    local initial=duration.config.SetTimeFromEnd[1]; local formats=h.calls.CreateNumericRuleFormatter; local allocations=h.calls.CreateDurationTextBinding
    for _=1,27 do h.tick() end
    eq(first.Binding,binding); eq(first.Duration,duration); eq(h.calls.CreateNumericRuleFormatter,formats); eq(h.calls.CreateDurationTextBinding,allocations)
    truth(duration.config.SetTimeFromEnd[1]>initial); local endTime=duration.config.SetTimeFromEnd[1]
    h.addon.db.IconGroups[1].FontScale=1.7; h.config(); eq(duration.config.SetTimeFromEnd[1],endTime,"style edit resets synthetic clock")
    h.addon.db.IconGroups[1].TimerTextUseRelativeColor=true; h.config()
    eq(first.Binding.config.SetTextColorCurve[2],h.env.Enum.DurationTextBindingProperty.RemainingPercent)
    eq(first.Binding, binding); eq(first.Duration,duration)
end)
test("preview_time_stacks_zoom_and_cooldown_settings_refresh_independently",function()
    local h,_,s=configured(); h.addon.SwitchTestMode(); local group=h.addon.db.IconGroups[1]; local first=s.Preview.Buttons[1]
    group.TimerTextUseRelativeScale=false; group.TimerTextSize=37; group.TimerTextAnchor="TOPLEFT"; group.TimerTextAnchorIcon="BOTTOMRIGHT"; group.TimerTextXOffset=8; group.TimerTextYOffset=-7
    group.StacksFontScale=2; group.StacksTextColor={.2,.3,.4,.5}; group.StacksTextXOffset=11; group.IconZoom=.2; group.KeepAspectRatio=false; h.config()
    eq(h.data[first.Time].font[2],37); local point=h.data[first.Time].points[1]
    eq(point[1],"TOPLEFT"); eq(point[3],"BOTTOMRIGHT"); eq(point[4],8); eq(point[5],-7)
    eq(h.data[first.Count].font[2],23); eq(h.data[first.Count].SetTextColor[4],.5); eq(h.data[first.Texture].SetTexCoord[1],.2)
    group.ShowCooldownText=false; h.config(); eq(first.Binding.enabled,false); eq(h.data[first.Time].shown,false); eq(h.data[first.Cooldown].SetDrawSwipe[1],true)
    group.ShowCooldownAnimation=false; group.ShowCooldownText=true; group.ShowStacks=false; h.config()
    eq(first.Binding.enabled,true); eq(h.data[first.Cooldown].SetDrawSwipe[1],false); eq(h.data[first.Cooldown].SetDrawEdge[1],false); eq(h.data[first.Count].shown,false)
    group.ShowCooldownAnimation=true; group.ShowCooldownSwipeEdge=false; h.config(); eq(h.data[first.Cooldown].SetDrawSwipe[1],true); eq(h.data[first.Cooldown].SetDrawEdge[1],false)
end)
test("preview_static_tooltip_tracks_option_and_is_cleaned_on_detach",function()
    local h,_,s=configured(nil,{ShowAuraTooltip=true}); h.addon.SwitchTestMode(); local v=s.Preview.Buttons[1]; local tooltip=h.env.GameTooltip
    eq(h.data[v.Button].SetMouseMotionEnabled[1],true)
    h.data[v.Button].scripts.OnEnter(v.Button); eq(h.data[tooltip].shown,true); eq(h.data[tooltip].tooltipOwner,v.Button)
    truth(h.data[tooltip].text:find("合成",1,true)); eq(h.forbiddenReads,0)
    h.addon.db.IconGroups[1].ShowAuraTooltip=false; h.config(); eq(h.data[tooltip].shown,false); eq(h.data[v.Button].SetMouseMotionEnabled[1],false)
    h.addon.db.IconGroups[1].ShowAuraTooltip=true; h.config(); h.data[v.Button].scripts.OnEnter(v.Button)
    h.event("NAME_PLATE_UNIT_REMOVED","nameplate1"); eq(h.data[tooltip].shown,false); clearedPreview(h,s)
end)
test("preview_restriction_event_cleans_animations_cooldowns_and_bindings",function()
    local h,_,s=configured(); local entry=h.addon.db.CustomSpells2[1]
    entry.showGlow=h.addon.GLOW_TIME_INFINITE; entry.glowType=h.addon.GLOW_TYPE_PIXEL; entry.animationDisplayMode=h.addon.ICON_ANIMATION_DISPLAY_MODE_ALWAYS
    previewContext(h,1,7,entry,118); h.addon.SwitchTestMode(); h.secret=true
    h.event("ADDON_RESTRICTION_STATE_CHANGED",0,h.env.Enum.AddOnRestrictionState.Active); h.flush(); stopped(h,s); clearedPreview(h,s); eq(h.blocked or 0,0)
end)
test("preview_recycled_plate_restarts_clean_binding_and_keeps_frame_identity",function()
    local h,p,s=configured(); h.addon.SwitchTestMode(); local root=s.Preview.Root; local button=s.Preview.Buttons[1].Button
    h.event("NAME_PLATE_UNIT_REMOVED","nameplate1"); clearedPreview(h,s)
    h.attach("nameplate2",p); eq(s.Preview.Root,root); eq(s.Preview.Buttons[1].Button,button)
    eq(h.data[root].shown,true); eq(s.Preview.Buttons[1].Binding.enabled,true); eq(h.data[s.Preview.Buttons[1].Cooldown].duration,s.Preview.Buttons[1].Duration)
end)

test("preview_queued_config_refresh_stops_before_restriction_event_or_ticker",function()
    for _,restricted in ipairs({"secret","combat"}) do
        local h,_,s=configured(); h.addon.SwitchTestMode()
        local changes=h.calls.SetFont; local before=h.calls.CreateNumericRuleFormatter
        h[restricted]=true; h.addon.db.IconGroups[1].FontScale=2; h.config()
        stopped(h,s); clearedPreview(h,s); eq(h.calls.SetFont,changes); eq(h.calls.CreateNumericRuleFormatter,before+2)
        eq(h.blocked or 0,0); eq(h.forbiddenReads,0)
    end
end)
test("preview_child_hidden_stops_resources_and_next_tick_restores_without_allocation",function()
    local h,_,s=configured(); local entry=h.addon.db.CustomSpells2[1]
    entry.showGlow=h.addon.GLOW_TIME_INFINITE; entry.glowType=h.addon.GLOW_TYPE_PIXEL; entry.animationDisplayMode=h.addon.ICON_ANIMATION_DISPLAY_MODE_ALWAYS
    previewContext(h,1,7,entry,118); h.addon.SwitchTestMode(); local v=s.Preview.Buttons[1]
    local allocations=h.calls.CreateDuration; local binding=v.Binding; local glow=v.GlowAnimation
    v.Button:Hide(); eq(v.Binding.enabled,false); eq(h.data[v.Cooldown].duration,nil); eq(h.data[glow].playing,false); eq(v.Active,false)
    h.tick(); eq(h.data[v.Button].shown,true); eq(binding.enabled,true); eq(h.data[glow].playing,true); eq(v.Active,true)
    eq(h.calls.CreateDuration,allocations); eq(v.Binding,binding); eq(v.GlowAnimation,glow)
end)
test("preview_hidden_parent_stops_and_recovers_same_pool",function()
    local h,p,s=configured(nil,{NameplateIsParent=true}); h.addon.SwitchTestMode(); local preview=s.Preview
    local allocations=h.calls.CreateDuration
    p:Hide(); eq(preview.Visible,false); eq(preview.Buttons[1].Binding.enabled,false); eq(h.data[preview.Buttons[1].Cooldown].duration,nil)
    h.tick(); eq(preview.Buttons[1].Binding.enabled,false); eq(h.data[preview.Root].shown,false)
    p:Show(); h.tick(); eq(h.data[preview.Root].shown,true); eq(preview.Visible,true); eq(preview.Buttons[1].Binding.enabled,true)
    eq(h.calls.CreateDuration,allocations); eq(s.Preview,preview)
end)

local function previewOrder(_,state)
    local result={}; local byButton={}
    for i,v in ipairs(state.Preview.Buttons) do byButton[v.Button]=i end
    for _,button in ipairs(previewElements(state)) do result[#result+1]=byButton[button] end
    return result
end
local function near(actual,expected)
    truth(math.abs(actual-expected)<0.000001,"numeric values differ: "..tostring(actual).." ~= "..tostring(expected))
end

test("preview_group_local_sorting_matches_live_comparator_without_global_time_sort",function()
    local h,_,s=configured(); local group=h.addon.db.IconGroups[1]
    h.addon.SwitchTestMode(); eq(h.addon.IsPreviewActive(),true)
    truth(same(previewOrder(h,s),{3,2,1,4}),"expiration must be sorted within harmful/helpful groups")
    eq(#s.Preview.Groups,2)
    group.SortMode=h.addon.AURA_SORT_MODE_NONE; h.config()
    truth(same(previewOrder(h,s),{2,3,1,4}),"NONE must retain synthetic instance order inside each group")
    group.SortMode=h.addon.AURA_SORT_MODE_AURATYPE_EXPIRE; h.config()
    truth(same(previewOrder(h,s),{3,2,1,4}))
    group.SortMode=h.addon.AURA_SORT_MODE_ICONSIZE; h.config()
    truth(same(previewOrder(h,s),{3,2,1,4}),"equal-size groups must not invent size differences")
    local specs={}; for _,slot in ipairs(s.Slots) do specs[#specs+1]=slot.Spec end
    eq(#specs,#s.Preview.Groups)
    for i,spec in ipairs(specs) do
        eq(s.Preview.Groups[i].Filter,spec.Filter); eq(s.Preview.Groups[i].Style.Signature,spec.Style.Signature)
    end
    h.addon.SwitchTestMode(); eq(h.addon.IsPreviewActive(),false); clearedPreview(h,s); eq(h.forbiddenReads,0)
end)

test("preview_mixed_size_opt_in_covers_twelve_alignments_and_uniform_group_spacing",function()
    local h,_,s=configured(); local group=h.addon.db.IconGroups[1]
    group.IconSpacing=10; previewContext(h,1,2); h.addon.SwitchTestMode()
    local snapshot=copy(h.addon.db); local liveSkins=h.calls.SetIcon
    h.addon.PreviewMixedSizes=true; h.addon.OnPreviewContextChanged()
    eq(h.calls.SetIcon,liveSkins); truth(same(h.addon.db,snapshot))
    local dimensions={{45,45},{27,36},{45,45},{36,27}}
    for i,v in ipairs(s.Preview.Buttons) do
        eq(h.data[v.Button].width,dimensions[i][1]); eq(h.data[v.Button].height,dimensions[i][2])
    end
    eq(#s.Preview.Groups,4)
    for _,g in ipairs(s.Preview.Groups) do eq(g.elementSpacing,10); eq(g.groupSpacing,0) end
    local expected={{"BOTTOMLEFT","BOTTOMRIGHT","BOTTOMLEFT","TOPLEFT"},{"TOPLEFT","TOPRIGHT","BOTTOMRIGHT","TOPRIGHT"},{"LEFT","RIGHT","BOTTOM","TOP"}}
    for align=1,3 do for direction=1,4 do
        group.IconAnchor=align; group.IconGrowDirection=direction; h.config()
        local vertical=direction>=3; local sign=(direction==2 or direction==4) and -1 or 1
        local cursor,maxCross=0,0
        for _,button in ipairs(previewElements(s)) do
            local data=h.data[button]; local p=data.points[1]
            eq(p[1],expected[align][direction]); eq(p[2],s.Preview.Root); eq(p[3],p[1])
            eq(p[4],vertical and 0 or cursor*sign); eq(p[5],vertical and cursor*sign or 0)
            cursor=cursor+(vertical and data.height or data.width)+10
            maxCross=math.max(maxCross,vertical and data.width or data.height)
        end
        local root=h.data[s.Preview.Root]
        eq(root.width,vertical and maxCross or cursor-10); eq(root.height,vertical and cursor-10 or maxCross)
        eq(vertical and root.height or root.width,183,"inter-group spacing counted twice")
    end end
    group.SortMode=h.addon.AURA_SORT_MODE_ICONSIZE; h.config()
    truth(same(previewOrder(h,s),{2,4,3,1}),"size group ordering must match the live comparator")
    h.addon.PreviewMixedSizes=false; h.addon.OnPreviewContextChanged()
    for _,v in ipairs(s.Preview.Buttons) do eq(h.data[v.Button].width,45); eq(h.data[v.Button].height,45) end
    previewContext(h,1,6); h.addon.PreviewMixedSizes=true; h.addon.OnPreviewContextChanged()
    eq(#s.Preview.Groups,1); truth(same(previewOrder(h,s),{1,2,3,4,5,6}),"border color examples must stay in labeled order")
    for _,v in ipairs(s.Preview.Buttons) do eq(h.data[v.Button].width,45); eq(h.data[v.Button].height,45) end
    previewContext(h,1,7,h.addon.db.CustomSpells2[1],118); h.addon.OnPreviewContextChanged()
    for _,v in ipairs(s.Preview.Buttons) do eq(h.data[v.Button].width,45); eq(h.data[v.Button].height,45) end
    eq(h.forbiddenReads,0)
end)

test("preview_zoom_and_aspect_ratio_refresh_on_non_square_mixed_samples",function()
    local h,_,s=configured(); local group=h.addon.db.IconGroups[1]
    group.IconZoom=.1; previewContext(h,1,2); h.addon.PreviewMixedSizes=true; h.addon.SwitchTestMode()
    local second,fourth=s.Preview.Buttons[2],s.Preview.Buttons[4]
    near(h.data[second.Texture].SetTexCoord[1],.2); near(h.data[second.Texture].SetTexCoord[3],.1)
    near(h.data[fourth.Texture].SetTexCoord[1],.1); near(h.data[fourth.Texture].SetTexCoord[3],.2)
    local clock=second.EndTime
    group.KeepAspectRatio=false; h.config()
    for _,v in ipairs(s.Preview.Buttons) do
        truth(same(h.data[v.Texture].SetTexCoord,{.1,.9,.1,.9})); eq(h.data[v.Button].width>0,true)
    end
    eq(second.EndTime,clock)
    group.IconZoom=.2; group.KeepAspectRatio=true; h.config()
    near(h.data[second.Texture].SetTexCoord[1],.275); near(h.data[second.Texture].SetTexCoord[3],.2)
    near(h.data[fourth.Texture].SetTexCoord[1],.2); near(h.data[fourth.Texture].SetTexCoord[3],.275)
    group.DefaultIconSizeWidth=1; group.DefaultIconSizeHeight=1; h.config()
    for _,v in ipairs(s.Preview.Buttons) do eq(h.data[v.Button].width,1); eq(h.data[v.Button].height,1) end
    eq(h.forbiddenReads,0)
end)

test("live_and_preview_inter_group_spacing_is_applied_exactly_once",function()
    local h,_,s=configured(nil,{IconSpacing=10}); local group=h.addon.db.IconGroups[1]
    h.addon.db.CustomSpells2[2]=rule(h,"Frost Nova",{overrideSize=true,iconSizeWidth=27,iconSizeHeight=39,auraType=h.addon.AURA_TYPE_DEBUFF})
    h.config(); local nativeGroups={}
    for _,slot in ipairs(s.Slots) do
        local actual=h.data[s.Container].groups[slot.Key]
        if actual.enabled then
            eq(actual.layout.elementSpacing,10); eq(actual.layout.groupSpacing,0)
            local button=h.newFrame(); button:SetSize(actual.layout.elementWidth,actual.layout.elementHeight)
            nativeGroups[#nativeGroups+1]={elements={button},elementSpacing=actual.layout.elementSpacing,groupSpacing=actual.layout.groupSpacing}
        end
    end
    truth(#nativeGroups>=3)
    -- Run unchanged public geometry on the recorded live inputs; no aura assignment is invented.
    local layout=h.env.AnchorUtil.CreateFlowLayout(); local root=h.newFrame(); layout:Apply(root,nativeGroups)
    local cursor=0
    for _,g in ipairs(nativeGroups) do
        local data=h.data[g.elements[1]]; eq(data.points[1][4],cursor); cursor=cursor+data.width+10
    end
    eq(h.data[root].width,cursor-10)
    h.addon.SwitchTestMode()
    for _,g in ipairs(s.Preview.Groups) do eq(g.elementSpacing,group.IconSpacing); eq(g.groupSpacing,0) end
end)

test("preview_short_timers_cycle_before_expiration_and_reuse_native_resources",function()
    local h,_,s=configured(); h.addon.SwitchTestMode()
    local native={}; local allocations=h.calls.CreateDuration; local bindings=h.calls.CreateDurationTextBinding; local formats=h.calls.CreateNumericRuleFormatter
    for i,v in ipairs(s.Preview.Buttons) do native[i]={v.Duration,v.Binding}; eq(v.Binding.updatedEndTime,v.EndTime) end
    for n=1,160 do
        h.tick(); local phase=s.Preview.Started
        for i,v in ipairs(s.Preview.Buttons) do
            local expectedStart=phase+math.floor((h.now-phase)/v.Sample.Cycle)*v.Sample.Cycle
            eq(v.Started,expectedStart); near(v.EndTime,expectedStart+v.Sample.Remaining)
            truth(v.EndTime-h.now>.7,"synthetic timer is expired or blank")
            eq(v.Binding.updatedEndTime,v.EndTime); eq(v.Duration,native[i][1]); eq(v.Binding,native[i][2])
        end
        if n%5==0 then
            local ends={}; for i,v in ipairs(s.Preview.Buttons) do ends[i]=v.EndTime end
            h.addon.OnPreviewContextChanged()
            for i,v in ipairs(s.Preview.Buttons) do eq(v.EndTime,ends[i],"context refresh restarts clock") end
        end
    end
    eq(h.calls.CreateDuration,allocations); eq(h.calls.CreateDurationTextBinding,bindings); eq(h.calls.CreateNumericRuleFormatter,formats)
    eq(h.pending(true),1); eq(#s.Preview.Buttons,4); eq(h.forbiddenReads,0)
end)

test("preview_time_changes_immediately_submit_native_formatter_and_color_config",function()
    local h,_,s=configured(); h.addon.SwitchTestMode(); local group=h.addon.db.IconGroups[1]
    local first=s.Preview.Buttons[1]; local clock=first.EndTime; local before=h.calls.UpdateFontString
    group.TimerTextSoonToExpireColor={.1,.2,.3,.4}; group.TimerTextUnderMinuteColor={.2,.3,.4,.5}; group.TimerTextLongerColor={.3,.4,.5,.6}
    group.MinTimeToShowTenthsOfSeconds=3.5; h.config()
    eq(h.calls.UpdateFontString,before+4); eq(first.EndTime,clock)
    local config=first.Binding.updatedConfig; local colorPoints=config.SetTextColorCurve[1].points
    eq(config.SetTextColorCurve[2],h.env.Enum.DurationTextBindingProperty.RemainingDuration)
    eq(colorPoints[1][1],0); eq(colorPoints[1][2].a,.4); eq(colorPoints[2][1],5); eq(colorPoints[2][2].a,.5); eq(colorPoints[3][1],60); eq(colorPoints[3][2].a,.6)
    eq(config.SetFormatter[1].config.SetBreakpoints[1][2].threshold,3.5)
    group.TimerTextUseRelativeColor=true; group.TimerTextColorZeroPercent={.1,.4,.7,.2}; group.TimerTextColorHundredPercent={.7,.4,.1,.8}; h.config()
    config=first.Binding.updatedConfig; colorPoints=config.SetTextColorCurve[1].points
    eq(config.SetTextColorCurve[2],h.env.Enum.DurationTextBindingProperty.RemainingPercent); eq(colorPoints[1][2].a,.2); eq(colorPoints[2][2].a,.8)
    truth(s.Preview.Buttons[3].Sample.Remaining/s.Preview.Buttons[3].Sample.Duration<.05)
    eq(s.Preview.Buttons[4].Sample.Remaining/s.Preview.Buttons[4].Sample.Duration,1)
    group.ShowCooldownText=false; before=h.calls.UpdateFontString; h.config(); eq(h.calls.UpdateFontString,before)
    group.ShowCooldownText=true; h.config(); eq(h.calls.UpdateFontString,before+4)
    eq(first.Binding.updatedEndTime,first.EndTime); eq(first.Binding.enabled,true)
end)

test("preview_config_matrix_matches_live_fonts_anchors_colors_and_dimensions",function()
    local h,_,s=configured(); local group=h.addon.db.IconGroups[1]; h.addon.SwitchTestMode()
    group.Font="NAurasForever_Skada"; group.StacksFont="NAurasForever_TexGyreHeros"; group.FontScale=1.5; group.StacksFontScale=1.8
    group.DefaultIconSizeWidth=50; group.DefaultIconSizeHeight=38; group.TimerTextUseRelativeScale=true
    group.TimerTextAnchor="TOPRIGHT"; group.TimerTextAnchorIcon="BOTTOMLEFT"; group.TimerTextXOffset=-12; group.TimerTextYOffset=14
    group.StacksTextAnchor="TOPLEFT"; group.StacksTextAnchorIcon="BOTTOMRIGHT"; group.StacksTextXOffset=13; group.StacksTextYOffset=-17
    group.StacksTextColor={.25,.5,.75,.4}; h.config()
    local _,live=next(s.Slots[1].Buttons)
    for _,v in ipairs(s.Preview.Buttons) do
        truth(same(h.data[v.Time].font,h.data[live.Time].font)); truth(same(h.data[v.Count].font,h.data[live.Count].font))
        eq(h.data[v.Time].font[2],29); eq(h.data[v.Count].font[2],18)
        truth(same(h.data[v.Count].SetTextColor,h.data[live.Count].SetTextColor))
        for _,name in ipairs({"Time","Count"}) do
            local pp,lp=h.data[v[name]].points[1],h.data[live[name]].points[1]
            for _,j in ipairs({1,3,4,5}) do eq(pp[j],lp[j]) end
        end
        eq(h.data[v.Button].width,50); eq(h.data[v.Button].height,38)
        eq(v.Binding.updatedEndTime,v.EndTime)
    end
    group.TimerTextUseRelativeScale=false; group.TimerTextSize=41; h.config()
    for _,v in ipairs(s.Preview.Buttons) do eq(h.data[v.Time].font[2],41) end
    eq(h.forbiddenReads,0)
end)

-- own_aura_contract regressions are independent of the original 93 cases.
-- PLAYER is a native filter (including owned pets/vehicles), not a Lua caster test.
local function playerComponents(filter)
    local n=0
    for token in filter:gmatch("[^|]+") do if token=="PLAYER" then n=n+1 end end
    return n
end
local function assertOwnSpecs(h,state,expectedCount)
    local groups=active(h,state)
    eq(#groups,expectedCount,"unexpected active spec count")
    for _,slot in ipairs(state.Slots) do
        local native=h.data[state.Container].groups[slot.Key]
        if native.enabled then
            eq(playerComponents(native.filter),1,"native filter must contain exactly one PLAYER")
            eq(native.filter,slot.Spec.Filter,"native filter differs from current slot")
            truth(same(native.candidate,slot.Spec.Candidate),"native candidates differ from current slot")
            eq(native.candidate.isFromPlayerOrPlayerPet,nil)
        end
    end
    eq(h.forbiddenReads,0)
end
local function sourceSnapshot(h,state)
    local out={}
    for _,slot in ipairs(state.Slots) do
        if h.data[state.Container].groups[slot.Key].enabled then
            local spec=slot.Spec
            out[#out+1]={filter=spec.Filter,candidate=copy(spec.Candidate),style=spec.Style.Signature,
                suffix=spec.Signature:match("([^:]+)$"),layout=copy(h.data[state.Container].groups[slot.Key].layout)}
        end
    end
    return out
end
local function withoutPlayer(snapshot)
    local result=copy(snapshot)
    for _,spec in ipairs(result) do spec.filter=spec.filter:gsub("|PLAYER","") end
    return result
end

test("own_default_off_keeps_all_and_single_mine_without_enabling_supplement",function()
    local h,_,s=configured(); local a=h.addon; local group=a.db.IconGroups[1]
    eq(group.OnlyShowMyAuras,false); eq(a.GetIconGroupDefaultOptions().OnlyShowMyAuras,false)
    eq(a.DB_SCHEMA_VERSION,34); eq(a.db.DBVersion,34)
    local original=copy(a.db.CustomSpells2[1])
    for _,flag in ipairs({false,true,false}) do
        group.OnlyShowMyAuras=flag; h.config(); eq(#active(h,s),2)
        eq(group.AlwaysShowMyAuras,false,"exclusive switch must not enable supplement")
        for _,native in ipairs(active(h,s)) do eq(playerComponents(native.filter),flag and 1 or 0) end
        truth(same(a.db.CustomSpells2[1],original),"source switch mutated the rule")
    end
    a.db.CustomSpells2[1].enabledState=a.CONST_SPELL_MODE_MYAURAS; h.config()
    local old=sourceSnapshot(h,s)
    for _,flag in ipairs({true,false}) do
        group.OnlyShowMyAuras=flag; h.config(); assertOwnSpecs(h,s,2)
        truth(same(sourceSnapshot(h,s),old),"single MINE behavior changed")
    end
    group.AlwaysShowMyAuras=true; h.config(); eq(group.OnlyShowMyAuras,false)
end)

for _,auraType in ipairs({1,2,3}) do for _,mode in ipairs({2,3}) do
    local kind,source=auraType,mode
    test("own_explicit_type_"..kind.."_mode_"..source.."_native_exactly_one_player",function()
        local h,_,s=configured({auraType=kind,enabledState=source},{OnlyShowMyAuras=true})
        assertOwnSpecs(h,s,kind==3 and 2 or 1)
        truth(same(included(h,s),{[118]=true,[12824]=true}))
        for _,native in ipairs(active(h,s)) do
            local base=native.filter:match("^[^|]+")
            truth(kind==3 or base==(kind==1 and "HELPFUL" or "HARMFUL"))
        end
    end)
end end

for _,differentStyle in ipairs({false,true}) do
    local separate=differentStyle
    test("own_same_name_same_id_all_mine_"..(separate and "different_style" or "same_style"),function()
        -- Same-name/same-ID public fixtures prove legal filter construction only.
        -- Real two-priest same-spell instance exclusion MUST be checked in-game.
        local h,_,s=configured({checkSpellID={[118]=true}})
        local a=h.addon; local all=a.db.CustomSpells2[1]
        local mine=rule(h,"Polymorph",{enabledState=a.CONST_SPELL_MODE_MYAURAS,checkSpellID={[118]=true}})
        if separate then mine.overrideSize=true; mine.iconSizeWidth=29; mine.iconSizeHeight=37 end
        local disabled=rule(h,"Other",{enabledState=a.CONST_SPELL_MODE_DISABLED})
        a.db.CustomSpells2={all,mine,disabled}; h.config()
        local old=sourceSnapshot(h,s); local entries=copy(a.db.CustomSpells2)
        eq(#active(h,s),4); local slots=copy(s.Slots); local buttons={}
        for i,slot in ipairs(s.Slots) do buttons[i]=next(slot.Buttons) end
        a.db.IconGroups[1].OnlyShowMyAuras=true; h.config()
        assertOwnSpecs(h,s,separate and 4 or 2)
        truth(same(included(h,s),{[118]=true}),"ID constraints changed or disabled rule activated")
        for i=#active(h,s)+1,#s.Slots do eq(h.data[s.Container].groups[s.Slots[i].Key].enabled,false,"stale slot remains enabled") end
        a.db.IconGroups[1].OnlyShowMyAuras=false; h.config()
        truth(same(sourceSnapshot(h,s),old),"OFF failed to restore legacy ALL/MINE filters")
        truth(same(a.db.CustomSpells2,entries),"enabledState or original rule changed")
        for i,button in ipairs(buttons) do truth(s.Slots[i].Buttons[button]); eq(s.Slots[i].Key,slots[i].Key) end
        a.db.CustomSpells2={all}; h.config(); eq(#active(h,s),2)
        for i=3,#s.Slots do eq(h.data[s.Container].groups[s.Slots[i].Key].enabled,false) end
    end)
end

test("own_disabled_rules_and_unlisted_mine_fallback_remain_disjoint",function()
    local h,_,s=configured({enabledState=1},{OnlyShowMyAuras=true,AlwaysShowMyAuras=true,Additions_DispellableSpells=true})
    assertOwnSpecs(h,s,3); eq(count(included(h,s)),0)
    local mine,dispel
    for _,native in ipairs(active(h,s)) do
        if native.candidate.isStealable==false then mine=native end
        if native.candidate.isStealable==true then dispel=native end
    end
    truth(mine and dispel); eq(playerComponents(mine.filter),1)
    eq(playerComponents(dispel.filter),1); eq(h.addon.db.CustomSpells2[1].enabledState,1)
end)

for _,always in ipairs({false,true}) do for _,dispel in ipairs({false,true}) do
    local mineEnabled,dispelEnabled=always,dispel
    test("own_fallback_matrix_mine_"..tostring(always).."_dispel_"..tostring(dispel),function()
        local h,_,s=configured(nil,{AlwaysShowMyAuras=mineEnabled,Additions_DispellableSpells=dispelEnabled})
        local a=h.addon; local group=a.db.IconGroups[1]
        -- Enumerate blacklist eligibility, catalog readiness, assist/controlled policy,
        -- zone and target predicates. No candidate is evaluated against real auras.
        for _,blocked in ipairs({false,true}) do for _,dispelBlocked in ipairs({false,true}) do
        for _,ready in ipairs({false,true}) do
        for _,policy in ipairs({{false,false,false},{true,false,false},{false,true,false},{false,false,true}}) do
        for _,zoneAllowed in ipairs({false,true}) do
            local friendly,assist,controlled=unpack(policy)
            h.units.nameplate1.friendly=friendly; h.units.nameplate1.canAssist=assist; h.units.nameplate1.controlled=controlled
            h.zone="party"; h.event("ZONE_CHANGED_NEW_AREA"); h.flush(); a.SpellCatalog.Ready=ready
            group.AlwaysShowMyAurasBlacklist={Other=blocked}
            group.Additions_DispellableSpells_Blacklist={Other=dispelBlocked}
            group.Additions_Dispel_InstanceTypes.party=zoneAllowed
            group.EnemyUnitsAurasEnabledZoneTypes.party=zoneAllowed
            group.FriendlyUnitsAurasEnabledZoneTypes.party=zoneAllowed
            group.OnlyShowMyAuras=false; h.config()
            local old=sourceSnapshot(h,s)
            local showDispel=dispelEnabled and not friendly and zoneAllowed and not dispelBlocked
            local mineCount=not blocked and 2 or ready and ((not assist and 1 or 0)+((assist or controlled) and 1 or 0)) or 0
            local expected=2+(mineEnabled and mineCount or 0)+(showDispel and 1 or 0)
            eq(#old,expected,"fallback predicate regression")
            local rules=copy(a.db.CustomSpells2)
            group.OnlyShowMyAuras=true; h.config(); assertOwnSpecs(h,s,expected)
            truth(same(withoutPlayer(sourceSnapshot(h,s)),withoutPlayer(old)),"source switch altered candidates/style/layout")
            for _,native in ipairs(active(h,s)) do
                if native.candidate.excludeSpellIDs and not native.candidate.includeSpellIDs then
                    if native.filter:find("HELPFUL",1,true) then
                        truth(native.candidate.excludeSpellIDs[118] and native.candidate.excludeSpellIDs[12824])
                    end
                    if native.candidate.isStealable~=true and showDispel and native.filter:find("HELPFUL",1,true) then
                        eq(native.candidate.isStealable,false,"mine/dispel candidates must remain disjoint")
                    end
                end
            end
            group.ShowOnlyOnTarget=true; h.units.target={exists=false}; h.config(); eq(h.data[s.Container].enabled,false)
            h.units.target={exists=true,alias="nameplate1"}; h.event("PLAYER_TARGET_CHANGED")
            eq(h.data[s.Container].enabled,zoneAllowed)
            local override=friendly and "ShowAurasOnAlliedTargetEvenInDisabledAreas" or "ShowAurasOnEnemyTargetEvenInDisabledAreas"
            group[override]=true; h.config(); eq(h.data[s.Container].enabled,true); assertOwnSpecs(h,s,expected)
            group[override]=false; group.ShowOnlyOnTarget=false
            group.OnlyShowMyAuras=false; h.config(); truth(same(sourceSnapshot(h,s),old))
            truth(same(a.db.CustomSpells2,rules))
        end end end end end
    end)
end end

test("own_native_filter_callback_current_spec_and_pool_reuse",function()
    local h,p,s=configured(); local a=h.addon; local slot=s.Slots[1]
    local callback=h.data[s.Container].groups[slot.Key].options.initializeFrame
    local pooled=next(slot.Buttons); local revision=s.Revision
    a.db.IconGroups[1].OnlyShowMyAuras=true
    a.db.CustomSpells2={rule(h,"Frost Nova",{auraType=a.AURA_TYPE_DEBUFF,checkSpellID={[122]=true},overrideSize=true,iconSizeWidth=33,iconSizeHeight=41})}
    h.config(); truth(s.Revision>revision); assertOwnSpecs(h,s,1)
    eq(h.data[pooled].width,33); eq(h.data[pooled].height,41)
    eq(h.data[s.Container].groups[slot.Key].options.initializeFrame,callback)
    -- Explicit native initialize callback on an unrestricted new pooled button,
    -- not a mock of aura matching, source ownership or assignment success.
    local button=h.newFrame("CustomAuraButton"); h.data[button].owner=button; h.data[button].initializing=true
    callback(button); h.data[button].initializing=false
    truth(slot.Buttons[button]); eq(h.data[button].width,33); eq(h.data[button].height,41)
    truth(same(slot.Spec.Candidate.includeSpellIDs,{[122]=true}))
    local allocations=#h.frames
    for _,flag in ipairs({false,true,false}) do
        a.db.IconGroups[1].OnlyShowMyAuras=flag; h.config()
        eq(playerComponents(h.data[s.Container].groups[slot.Key].filter),flag and 1 or 0)
        h.event("NAME_PLATE_UNIT_REMOVED","nameplate1"); h.attach("nameplate2",p)
        eq(a.Nameplates[p][1],s); truth(slot.Buttons[pooled] and slot.Buttons[button]); eq(#h.frames,allocations)
        eq(slot.Spec.Group.OnlyShowMyAuras,flag)
    end
    eq(h.forbiddenReads,0)
end)

test("own_on_off_coalesced_timer_uses_last_configuration",function()
    local h,_,s=configured(); local a=h.addon; local group=a.db.IconGroups[1]
    local timers=h.calls.NewTimer or 0; local revision=s.Revision; local filters=h.calls.SetAuraGroupFilterString
    local pool=#h.frames
    for i=1,20 do group.OnlyShowMyAuras=i%2==1; a.UpdateAllNameplates() end
    eq(h.pending(false),1); eq(h.calls.NewTimer-timers,1)
    eq(h.calls.SetAuraGroupFilterString,filters,"native filters changed before queued callback")
    h.flush(); truth(s.Revision>revision); eq(h.calls.SetAuraGroupFilterString-filters,2)
    for _,native in ipairs(active(h,s)) do eq(playerComponents(native.filter),0) end
    timers=h.calls.NewTimer
    for _=1,20 do group.OnlyShowMyAuras=true; a.UpdateAllNameplates() end
    eq(h.pending(false),1); eq(h.calls.NewTimer-timers,1); h.flush(); assertOwnSpecs(h,s,2)
    eq(#h.frames,pool); eq(h.pending(false),0)
end)

test("own_new_states_and_recreated_groups_are_independent",function()
    local h,p,s=configured(nil,{OnlyShowMyAuras=true}); local a=h.addon
    a.db.IconGroups[2]=a.GetIconGroupDefaultOptions("Off"); a.db.CustomSpells2[1].iconGroups[2]=true; h.config()
    local second=a.Nameplates[p][2]; assertOwnSpecs(h,s,2)
    for _,native in ipairs(active(h,second)) do eq(playerComponents(native.filter),0) end
    local _,states=h.attach("nameplate2"); assertOwnSpecs(h,states[1],2)
    for _,native in ipairs(active(h,states[2])) do eq(playerComponents(native.filter),0) end
    a.db.IconGroups[1].OnlyShowMyAuras=false; a.db.IconGroups[2].OnlyShowMyAuras=true; h.config()
    for _,list in ipairs({a.Nameplates[p],states}) do
        for _,native in ipairs(active(h,list[1])) do eq(playerComponents(native.filter),0) end
        assertOwnSpecs(h,list[2],2)
    end
    a.db.IconGroups[2]=nil; h.config(); eq(h.data[second.Container].enabled,false); eq(second.Unit,nil)
    a.db.IconGroups[2]=a.GetIconGroupDefaultOptions("Recreated"); h.config()
    eq(a.Nameplates[p][2],second); eq(a.db.IconGroups[2].OnlyShowMyAuras,false)
    for _,native in ipairs(active(h,second)) do eq(playerComponents(native.filter),0) end
end)

test("own_actor_predicates_and_metadata_ranges_do_not_change",function()
    local h,_,s=configured({checkSpellID={[118]=true,[12824]=false}},{OnlyShowMyAuras=true})
    local a=h.addon; local entry=a.db.CustomSpells2[1]; local original=copy(entry)
    for _,kind in ipairs({"player","pet","npc"}) do
        h.units.nameplate1.player=kind=="player"; h.units.nameplate1.pet=kind=="pet"
        local field=kind=="player" and "showOnPlayers" or kind=="pet" and "showOnPets" or "showOnNpcs"
        for _,flag in ipairs({false,true}) do
            a.db.IconGroups[1].OnlyShowMyAuras=flag; entry[field]=false; h.config(); eq(#active(h,s),0)
            entry[field]=true; h.config(); eq(#active(h,s),2); truth(same(included(h,s),{[118]=true}))
        end
    end
    entry.iconGroups[1]=false; h.config(); eq(#active(h,s),0); entry.iconGroups[1]=true
    entry.showOnFriends=false; h.units.nameplate1.friendly=true; h.config(); eq(#active(h,s),0)
    entry.showOnFriends=true; h.config(); assertOwnSpecs(h,s,2)
    truth(same(entry,original)); eq(h.forbiddenReads,0)
end)

for _,restriction in ipairs({"secret","combat","both"}) do
    local restricted=restriction
    test("own_restricted_"..restricted.."_native_updates_without_existing_button_access",function()
        local h,_,s=configured(); local a=h.addon; local group=a.db.IconGroups[1]
        local button=next(s.Slots[1].Buttons); local skin=h.calls.SetIcon; local frames=#h.frames
        h.secret=restricted~="combat"; h.combat=restricted~="secret"
        local filters=h.calls.SetAuraGroupFilterString
        for _,flag in ipairs({true,false,true}) do
            group.OnlyShowMyAuras=flag; group.DefaultIconSizeWidth=37; h.config()
            for _,native in ipairs(active(h,s)) do eq(playerComponents(native.filter),flag and 1 or 0) end
            eq(h.calls.SetIcon,skin); eq(h.blocked or 0,0); eq(#h.frames,frames)
            for _,slot in ipairs(s.Slots) do eq(slot.NeedsSkin,true) end
        end
        eq(h.calls.SetAuraGroupFilterString-filters,6); assertOwnSpecs(h,s,2)
        h.secret=false; h.combat=false; h.event("PLAYER_REGEN_ENABLED")
        eq(h.data[button].width,37); eq(h.calls.SetIcon-skin,4)
        for _,slot in ipairs(s.Slots) do eq(slot.NeedsSkin,false) end
        h.event("PLAYER_REGEN_ENABLED"); eq(h.calls.SetIcon-skin,4); eq(h.forbiddenReads,0)
    end)
end

for _,version in ipairs({0,22,34,35}) do for _,value in ipairs({"missing",false,true}) do
    local schema,flag=version,value
    test("own_persistence_schema_"..schema.."_"..tostring(flag).."_reload",function()
        local group={IconGroupName="Saved identity",AlwaysShowMyAuras=false}
        if flag~="missing" then group.OnlyShowMyAuras=flag end
        local h=fresh({DBVersion=schema,DefaultSpellsLastSetImported=4,CustomSpells2={},IconGroups={group}})
        local a=h.addon; local expected=flag==true
        eq(a.db.DBVersion,schema==35 and 35 or 34); eq(a.db.IconGroups[1].OnlyShowMyAuras,expected)
        eq(a.db.IconGroups[1].IconGroupName,"Saved identity"); eq(a.db.IconGroups[1].AlwaysShowMyAuras,false)
        local saved=copy(a.db)
        for _=1,3 do a.ReloadDB(); h.flush(); truth(same(a.db,saved)) end
        local restarted=fresh(copy(saved))
        eq(restarted.addon.db.IconGroups[1].OnlyShowMyAuras,expected)
        truth(same(restarted.addon.db,saved),"saved profile restart changed values")
    end)
end end

local function presentationConfig(binding)
    local config=binding.config
    return {breakpoints=copy(config.SetFormatter[1].config.SetBreakpoints),
        colors=copy(config.SetTextColorCurve[1].points),property=config.SetTextColorCurve[2],
        interval=copy(config.SetUpdateInterval),zero=copy(config.SetZeroDurationText),expired=copy(config.SetExpiredText)}
end

local function exportRoundTrip(profile)
    -- Execute the actual embedded codecs, rather than substituting a table copy
    -- for profile serialization. No files or global library registrations occur.
    local env=setmetatable({LibStub=false,arg=false},{__index=_G})
    local serializeChunk=assert(loadfile(addonPath.."/libs/LibSerialize/LibSerialize.lua"))
    local deflateChunk=assert(loadfile(addonPath.."/libs/LibDeflate/LibDeflate.lua"))
    setfenv(serializeChunk,env); setfenv(deflateChunk,env)
    local serialize,deflate=serializeChunk(),deflateChunk()
    local encoded=deflate:EncodeForPrint(deflate:CompressDeflate(serialize:Serialize(profile)))
    local ok,decoded=serialize:Deserialize(deflate:DecompressDeflate(deflate:DecodeForPrint(encoded)))
    eq(ok,true); truth(type(encoded)=="string" and #encoded>0); return decoded
end

for _,value in ipairs({false,true}) do
    local flag=value
    test("own_import_export_copy_new_reset_"..tostring(flag),function()
        local h,_,s=configured(nil,{OnlyShowMyAuras=flag}); local a=h.addon
        local saved=copy(a.db); local exported=exportRoundTrip(a.db)
        truth(same(exported,saved),"serialized profile changed boolean or identity")
        local input=copy(exported); truth(a.ImportProfile(input)); h.flush()
        truth(same(input,exported),"import mutated decoded input")
        eq(a.db.IconGroups[1].OnlyShowMyAuras,flag); eq(a.db.DBVersion,34)
        a.db.IconGroups[2]=a.deepcopy(a.db.IconGroups[1]); a.db.IconGroups[2].IconGroupName="Copy"
        a.db.CustomSpells2[1].iconGroups[2]=true; h.config()
        truth(a.db.IconGroups[1]~=a.db.IconGroups[2]); eq(a.db.IconGroups[2].OnlyShowMyAuras,flag)
        a.db.IconGroups[2].OnlyShowMyAuras=not flag; eq(a.db.IconGroups[1].OnlyShowMyAuras,flag)
        -- AceDB supplies the copied/reset profile; exercise the real registered callbacks.
        h.ace.profile=copy(exported); h.ace.callbacks.OnProfileCopied(); h.flush()
        eq(a.db.IconGroups[1].OnlyShowMyAuras,flag); eq(a.db.DBVersion,34)
        eq(s.Unit,"nameplate1")
        h.ace.profile=copy(h.defaults.profile); h.ace.callbacks.OnProfileReset(); h.flush()
        eq(a.db.IconGroups[1].OnlyShowMyAuras,false); eq(a.db.DBVersion,34)
        local new=a.GetIconGroupDefaultOptions("Fresh group")
        eq(new.OnlyShowMyAuras,false); eq(new.AlwaysShowMyAuras,false)
        a.db.IconGroups[2]=new; a.NormalizeForeverProfile(); h.config()
        eq(a.db.IconGroups[2].OnlyShowMyAuras,false); eq(h.forbiddenReads,0)
    end)
end

test("own_import_missing_defaults_false_without_mutating_input",function()
    local h,_,s=configured(nil,{OnlyShowMyAuras=true})
    local input={DBVersion=34,DefaultSpellsLastSetImported=4,CustomSpells2={rule(h)},IconGroups={{IconGroupName="Missing"}}}
    local saved=copy(input); truth(h.addon.ImportProfile(input)); h.flush()
    eq(h.addon.db.IconGroups[1].OnlyShowMyAuras,false); truth(same(input,saved))
    for _,native in ipairs(active(h,s)) do eq(playerComponents(native.filter),0) end
end)

for _,invalid in ipairs({{name="string",value="true"},{name="number",value=1},{name="table",value={true}}}) do
    local case=invalid
    test("own_malformed_import_"..case.name.."_rejected_without_mutation",function()
        local h,_,s=configured(nil,{OnlyShowMyAuras=true}); local a=h.addon
        local db=a.db; local group=db.IconGroups[1]; local original=copy(db)
        local specs=sourceSnapshot(h,s); local revision=s.Revision; local gui=h.guiChanges
        for _,version in ipairs({0,22,34}) do
            local input={DBVersion=version,DefaultSpellsLastSetImported=4,CustomSpells2={},
                IconGroups={{IconGroupName="Invalid",OnlyShowMyAuras=copy(case.value)}}}
            local snapshot=copy(input)
            local prepared,failure=a.PrepareProfileImport(input)
            eq(prepared,nil); truth(failure:find("OnlyShowMyAuras",1,true))
            local ok,message=a.ImportProfile(input)
            eq(ok,false); truth(message:find("OnlyShowMyAuras",1,true)); eq(a.db,db); eq(a.db.IconGroups[1],group)
            truth(same(db,original)); truth(same(input,snapshot)); truth(same(sourceSnapshot(h,s),specs))
            eq(h.guiChanges,gui); eq(s.Revision,revision); eq(h.pending(false),0)
        end
    end)
    test("own_stored_invalid_"..case.name.."_defaults_false",function()
        local h=fresh({DBVersion=34,DefaultSpellsLastSetImported=4,CustomSpells2={},
            IconGroups={{OnlyShowMyAuras=copy(case.value),AlwaysShowMyAuras=true},{OnlyShowMyAuras=true}}})
        eq(h.addon.db.IconGroups[1].OnlyShowMyAuras,false); eq(h.addon.db.IconGroups[1].AlwaysShowMyAuras,true)
        eq(h.addon.db.IconGroups[2].OnlyShowMyAuras,true); eq(h.addon.db.DBVersion,34)
        local snapshot=copy(h.addon.db); h.addon.ReloadDB(); h.flush(); truth(same(h.addon.db,snapshot))
    end)
end

test("own_sparse_group_remap_preserves_independent_flags_and_membership",function()
    local h=fresh({DBVersion=34,DefaultSpellsLastSetImported=4,
        IconGroups={[1]={IconGroupName="One",OnlyShowMyAuras=true},[3]={IconGroupName="Three",OnlyShowMyAuras=false},[7]={IconGroupName="Seven"}},
        CustomSpells2={{spellName="Polymorph",enabledState=2,auraType=3,iconGroups={[1]=true,[3]=true,[7]=true}}}})
    catalog(h); local a=h.addon; local _,states=h.attach("nameplate1")
    eq(#a.db.IconGroups,3); eq(a.db.IconGroups[2].IconGroupName,"Three"); eq(a.db.IconGroups[3].IconGroupName,"Seven")
    eq(a.db.IconGroups[1].OnlyShowMyAuras,true); eq(a.db.IconGroups[2].OnlyShowMyAuras,false); eq(a.db.IconGroups[3].OnlyShowMyAuras,false)
    truth(same(a.db.CustomSpells2[1].iconGroups,{true,true,true})); assertOwnSpecs(h,states[1],2)
    a.db.IconGroups[2].OnlyShowMyAuras=true; h.config(); assertOwnSpecs(h,states[2],2)
    for _,native in ipairs(active(h,states[3])) do eq(playerComponents(native.filter),0) end
    local saved=exportRoundTrip(a.db); truth(a.ImportProfile(saved)); h.flush()
    eq(a.db.DBVersion,34); assertOwnSpecs(h,states[1],2); assertOwnSpecs(h,states[2],2)
    eq(a.db.IconGroups[3].OnlyShowMyAuras,false)
end)

for _,category in ipairs({1,2,6,7,9}) do
    local page=category
    test("own_preview_page_"..page.."_source_tag_and_resources_unchanged",function()
        local h,_,s=configured(nil,{Additions_DispellableSpells=true,ShowAuraTooltip=true})
        local a=h.addon; local group=a.db.IconGroups[1]; local entry=a.db.CustomSpells2[1]
        entry.overrideSize=true; entry.iconSizeWidth=31; entry.iconSizeHeight=59
        previewContext(h,1,page,page==7 and entry or nil,page==7 and 118 or nil)
        if page==2 then a.PreviewMixedSizes=true end
        h.config(); a.SwitchTestMode()
        local sampleCount=page==6 and 6 or 4; eq(#previewElements(s),sampleCount)
        local saved={}; local frames=#h.frames; local durations=h.calls.CreateDuration
        for i,v in ipairs(s.Preview.Buttons) do
            saved[i]={button=v.Button,duration=v.Duration,binding=v.Binding,clock=v.EndTime,sample=copy(v.Sample),
                count=h.data[v.Count].text,width=h.data[v.Button].width,height=h.data[v.Button].height,config=presentationConfig(v.Binding)}
        end
        local native=sourceSnapshot(h,s); local entries=copy(a.db.CustomSpells2)
        for _,flag in ipairs({true,false,true}) do
            local bindingAllocations=h.calls.CreateDurationTextBinding
            group.OnlyShowMyAuras=flag; h.config(); eq(#previewElements(s),sampleCount)
            for _,spec in ipairs(s.Preview.Groups) do
                eq(playerComponents(spec.Filter),flag and 1 or 0); eq(spec.Style.Width>0,true)
            end
            for i,v in ipairs(s.Preview.Buttons) do
                local old=saved[i]; eq(v.Button,old.button); eq(v.Duration,old.duration); eq(v.Binding,old.binding)
                eq(v.EndTime,old.clock); truth(same(v.Sample,old.sample)); eq(h.data[v.Count].text,old.count)
                eq(h.data[v.Button].width,old.width); eq(h.data[v.Button].height,old.height)
                truth(same(presentationConfig(v.Binding),old.config),"source flag changed duration formatting")
            end
            eq(#h.frames,frames); eq(h.calls.CreateDuration,durations)
            -- Existing config refresh rebuilds one presentation per live spec and
            -- one preview template; the per-sample binding pool above must be reused.
            eq(h.calls.CreateDurationTextBinding-bindingAllocations,#active(h,s)+1)
            eq(h.pending(true),1); truth(same(a.db.CustomSpells2,entries))
        end
        group.OnlyShowMyAuras=false; h.config(); truth(same(sourceSnapshot(h,s),native))
        a.SwitchTestMode(); clearedPreview(h,s); eq(h.forbiddenReads,0)
    end)
end

test("own_preview_selected_mine_flag_has_exactly_one_player",function()
    local h,_,s=configured({enabledState=3}); local a=h.addon; local entry=a.db.CustomSpells2[1]
    previewContext(h,1,7,entry,118); a.SwitchTestMode(); local allocations=#h.frames
    for _,flag in ipairs({false,true,false,true}) do
        a.db.IconGroups[1].OnlyShowMyAuras=flag; h.config()
        for _,spec in ipairs(s.Preview.Groups) do eq(playerComponents(spec.Filter),1) end
        eq(#previewElements(s),4); eq(#h.frames,allocations); assertOwnSpecs(h,s,2)
    end
end)

test("own_preview_groups_off_on_are_isolated",function()
    local h,p,s=configured(nil,{OnlyShowMyAuras=true}); local a=h.addon
    a.db.IconGroups[2]=a.GetIconGroupDefaultOptions("Off"); a.db.CustomSpells2[1].iconGroups[2]=true; h.config()
    local second=a.Nameplates[p][2]; previewContext(h,1,1); a.SwitchTestMode()
    for _,spec in ipairs(s.Preview.Groups) do eq(playerComponents(spec.Filter),1) end
    previewContext(h,2,1); a.OnPreviewContextChanged(); clearedPreview(h,s)
    for _,spec in ipairs(second.Preview.Groups) do eq(playerComponents(spec.Filter),0) end
    local frames=#h.frames
    for _=1,4 do
        previewContext(h,1,1); a.OnPreviewContextChanged()
        for _,spec in ipairs(s.Preview.Groups) do eq(playerComponents(spec.Filter),1) end
        previewContext(h,2,1); a.OnPreviewContextChanged()
        for _,spec in ipairs(second.Preview.Groups) do eq(playerComponents(spec.Filter),0) end
    end
    eq(#h.frames,frames); eq(h.pending(true),1); eq(h.forbiddenReads,0)
end)

for _,restriction in ipairs({"secret","combat"}) do
    local restricted=restriction
    test("own_preview_queued_"..restricted.."_toggle_retains_resource_guards",function()
        local h,_,s=configured(); local a=h.addon; a.SwitchTestMode()
        local skins=h.calls.SetIcon; local frames=#h.frames; h[restricted]=true
        for _,flag in ipairs({true,false,true}) do
            a.db.IconGroups[1].OnlyShowMyAuras=flag; h.config()
            stopped(h,s); clearedPreview(h,s); eq(h.calls.SetIcon,skins); eq(#h.frames,frames)
            eq(h.blocked or 0,0); eq(#active(h,s),2)
            for _,slot in ipairs(s.Slots) do
                local native=h.data[s.Container].groups[slot.Key]
                if native.enabled then
                    eq(playerComponents(native.filter),flag and 1 or 0)
                    eq(native.filter,slot.Spec.Filter); eq(slot.NeedsSkin,true)
                end
            end
        end
        eq(h.forbiddenReads,0)
    end)
end

test("own_npc_blacklist_public_identity_gate_unchanged_on_off",function()
    local h,_,s=configured(nil,{NpcBlacklist={Blocked=true},AlwaysShowMyAuras=true,Additions_DispellableSpells=true})
    local a=h.addon; local group=a.db.IconGroups[1]
    for _,flag in ipairs({false,true,false}) do
        group.OnlyShowMyAuras=flag; h.config()
        local before=h.calls.UnitName or 0
        h.identitySecret=true; h.event("PLAYER_TARGET_CHANGED")
        eq(h.data[s.Container].enabled,false); eq(h.calls.UnitName or 0,before)
        h.identitySecret=false; h.units.nameplate1.name="Blocked"; h.event("PLAYER_TARGET_CHANGED")
        eq(h.data[s.Container].enabled,false)
        h.units.nameplate1.name=nil; h.event("PLAYER_TARGET_CHANGED"); eq(h.data[s.Container].enabled,false)
        h.units.nameplate1.name="NPC"; h.event("PLAYER_TARGET_CHANGED"); eq(h.data[s.Container].enabled,true)
        eq(#active(h,s),5)
        if flag then assertOwnSpecs(h,s,5) end
    end
    eq(h.forbiddenReads,0); eq(h.blocked or 0,0)
end)

test("own_new_secret_states_receive_native_policy_during_allowed_initialization",function()
    local h=fresh(); catalog(h); local a=h.addon
    a.db.IconGroups[1].OnlyShowMyAuras=true
    a.db.IconGroups[2]=a.GetIconGroupDefaultOptions("Off")
    a.db.CustomSpells2={rule(h,nil,{iconGroups={[1]=true,[2]=true}})}
    h.secret=true; local _,states=h.attach("nameplate1")
    -- New-button initializeFrame is the existing client-authorized window. It
    -- proves only initialization inputs, never successful private aura filtering.
    assertOwnSpecs(h,states[1],2)
    for _,native in ipairs(active(h,states[2])) do eq(playerComponents(native.filter),0) end
    local skin=h.calls.SetIcon; a.db.IconGroups[2].OnlyShowMyAuras=true; h.config()
    assertOwnSpecs(h,states[2],2); eq(h.calls.SetIcon,skin); eq(h.blocked or 0,0)
    for _,state in ipairs(states) do for _,slot in ipairs(state.Slots) do eq(slot.NeedsSkin,true) end end
    eq(h.forbiddenReads,0)
end)

local function readSource(relative)
    local file=assert(io.open(addonPath.."/"..relative,"rb")); local text=file:read("*all"); file:close(); return text
end

test("own_general_checkbox_static_wiring_and_localized_policy_not_identity",function()
    -- Static UI wiring is deliberately separate from runtime filter evidence.
    -- This does not replace real embedded-GUI clicks or in-game presentation.
    local source=readSource("src/options-dialog.lua")
    local general=assert(source:match("local function GUICategory_1%(index%)(.-)local function GUICategory_Fonts"))
    truth(source:find('local ownOnly = group and group.OnlyShowMyAuras or entry and entry.enabledState == CONST_SPELL_MODE_MYAURAS;',1,true))
    truth(source:find('ownOnly and L["options:preview:source-own"] or L["options:preview:source-rules"]',1,true),"GUI preview tooltip lacks effective source policy")
    truth(general:find('checkBoxOnlyShowMyAuras = VGUI.CreateCheckBox();',1,true))
    truth(general:find('checkBoxOnlyShowMyAuras:SetText(L["options:general:only-show-my-auras"]);',1,true))
    truth(general:find('addonTable.db.IconGroups[CurrentIconGroup].OnlyShowMyAuras = self:GetChecked();',1,true))
    truth(general:find('checkBoxOnlyShowMyAuras:SetChecked(addonTable.db.IconGroups[CurrentIconGroup].OnlyShowMyAuras);',1,true))
    truth(general:find('table_insert(GUIFrame.Categories[index], checkBoxOnlyShowMyAuras);',1,true))
    truth(general:find('VGUI.SetTooltip(checkBoxOnlyShowMyAuras, L["options:general:only-show-my-auras:tooltip"]);',1,true))
    for _,locale in ipairs({"enUS","zhCN"}) do
        local text=readSource("locales/"..locale..".lua")
        truth(text:find('L["options:general:only-show-my-auras"]',1,true))
        truth(text:find('L["options:general:only-show-my-auras:tooltip"]',1,true))
        truth(text:find('L["options:preview:source-own"]',1,true))
    end
    local h,_,s=configured(); local entry=h.addon.db.CustomSpells2[1]; local saved=copy(entry)
    h.addon.db.IconGroups[1].OnlyShowMyAuras=true; h.config(); assertOwnSpecs(h,s,2)
    truth(same(entry,saved)); eq(entry.spellName,"Polymorph"); truth(same(entry.checkSpellID,saved.checkSpellID))
end)

-- blizzard_border_contract: submitted atlas/geometry and native registrations only.
-- These tests never query atlas pixels or emulate private aura/dispel evaluation.
local function borderState(h,button,v,mode,w,ht,path,thickness)
    for _,border in ipairs({v.BuffBorder,v.DebuffBorder}) do
        local d=h.data[border]
        eq(d.parent,button,"registered border reparented")
        if mode==4 then
            eq(d.atlas,"UI-HUD-CoolDownManager-IconOverlay"); eq(d.useAtlasSize,false)
            eq(d.texture,nil); eq(d.SetTexCoord,nil,"old manual crop survived atlas")
            eq(d.atlasCoords,true); eq(d.allPoints,nil,"old allPoints survived clear")
            eq(#d.points,2,"atlas anchors accumulated")
            local tl,br=d.points[1],d.points[2]
            eq(tl[1],"TOPLEFT"); eq(tl[2],button); eq(tl[3],"TOPLEFT")
            eq(br[1],"BOTTOMRIGHT"); eq(br[2],button); eq(br[3],"BOTTOMRIGHT")
            near(tl[4],-6*w/25); near(tl[5],5*ht/25)
            near(br[4],6*w/25); near(br[5],-5*ht/25)
            if w==25 and ht==25 then
                eq(tl[4],-6); eq(tl[5],5); eq(br[4],6); eq(br[5],-5)
            end
        else
            eq(d.atlas,nil); eq(d.useAtlasSize,nil); eq(d.atlasCoords,nil)
            eq(d.texture,mode==1 and h.addon.BORDER_TEXTURES[thickness or 2] or path)
            truth(same(d.SetTexCoord,{0,1,0,1}),"switch-back crop not reset")
            eq(d.allPoints,button); eq(#d.points,0,"old explicit atlas points survived")
        end
    end
end
local function borderOrder(h,border,start,mode)
    local expected=mode==4 and {"ClearAllPoints","SetAtlas","SetPoint","SetPoint"}
        or {"ClearAllPoints","SetTexture","ResetTexCoord","SetAllPoints"}
    local order=h.data[border].callOrder
    for i,name in ipairs(expected) do eq(order[start+i],name,"border submission order") end
end
local function borderSources(h,state)
    local out=sourceSnapshot(h,state)
    for _,spec in ipairs(out) do spec.style=nil end
    return out
end
local function colorEquals(actual,expected)
    eq(actual.kind,"Color")
    for i,key in ipairs({"r","g","b","a"}) do eq(actual[key],expected[i]) end
end

test("blizzard_mock_exact_signatures_and_state_negative_controls",function()
    local h=fresh(); local f=h.newFrame(); local t=f:CreateTexture(nil,"OVERLAY")
    local atlas="UI-HUD-CoolDownManager-IconOverlay"
    for _,bad in ipairs({function() t:SetAtlas(nil,false) end,function() t:SetAtlas(atlas) end,
        function() t:SetAtlas(atlas,nil) end,function() t:SetAtlas(atlas,0) end,
        function() t:SetAtlas(atlas,false,true) end,function() t:SetAtlas("Invented-Atlas",false) end,
        function() t:ResetTexCoord(false) end,function() f:SetAtlas(atlas,false) end,
        function() f:ResetTexCoord() end,function() t:UnknownAtlasMethod() end}) do raises(bad) end
    eq(h.data[t].atlas,nil,"rejected call mutated mock state")
    t:SetAllPoints(f); t:SetTexCoord(.2,.8,.3,.7); t:ClearAllPoints()
    eq(h.data[t].allPoints,nil); eq(#h.data[t].points,0)
    t:SetAtlas(atlas,false); eq(h.data[t].atlas,atlas); eq(h.data[t].useAtlasSize,false)
    eq(h.data[t].SetTexCoord,nil); eq(h.data[t].atlasCoords,true)
    t:SetTexture("Interface\\fixture.tga"); eq(h.data[t].atlas,nil); eq(h.data[t].atlasCoords,nil)
    t:SetTexCoord(.2,.8,.3,.7); t:ResetTexCoord(); truth(same(h.data[t].SetTexCoord,{0,1,0,1}))
    t:SetAtlas(atlas,true); eq(h.data[t].useAtlasSize,true)
    t:SetTexture(nil); eq(h.data[t].atlas,nil); eq(h.data[t].texture,nil)
end)

for _,dimensions in ipairs({{25,25},{45,45},{31,59}}) do
    local w,ht=dimensions[1],dimensions[2]
    test("blizzard_shared_live_preview_geometry_"..w.."x"..ht,function()
        local h,_,s=configured(nil,{BorderType=4,DefaultIconSizeWidth=w,DefaultIconSizeHeight=ht})
        eq(h.addon.BORDER_TYPE_BLIZZARD,4); eq(h.addon.BLIZZARD_BORDER_ATLAS,"UI-HUD-CoolDownManager-IconOverlay")
        for _,slot in ipairs(s.Slots) do for button,v in pairs(slot.Buttons) do
            borderState(h,button,v,4,w,ht)
            for _,b in ipairs({v.BuffBorder,v.DebuffBorder}) do
                -- CreateVisuals initially submits SetAllPoints, then shared styling replaces it.
                eq(h.data[b].callOrder[1],"SetAllPoints"); borderOrder(h,b,1,4)
                eq(h.data[b].calls.ClearAllPoints,1); eq(h.data[b].calls.SetAtlas,1)
            end
        end end
        previewContext(h,1,2); h.addon.SwitchTestMode()
        local _,live=next(s.Slots[1].Buttons)
        for _,v in ipairs(s.Preview.Buttons) do
            borderState(h,v.Button,v,4,w,ht)
            truth(same(h.data[v.Texture].SetTexCoord,h.data[live.Texture].SetTexCoord))
        end
        eq(h.data[s.Preview.Root].width,4*w+3); eq(h.data[s.Preview.Root].height,ht)
        for _,native in ipairs(active(h,s)) do
            eq(native.layout.elementWidth,w); eq(native.layout.elementHeight,ht)
            eq(native.layout.elementSpacing,1); eq(native.layout.groupSpacing,0)
        end
        eq(h.forbiddenReads,0)
    end)
end

test("blizzard_six_colors_alpha_preserveasset_and_independent_toggles",function()
    local h,_,s=configured(nil,{BorderType=4}); local group=h.addon.db.IconGroups[1]
    local fields={"BuffBordersColor","DebuffBordersMagicColor","DebuffBordersCurseColor","DebuffBordersDiseaseColor","DebuffBordersPoisonColor","DebuffBordersOtherColor"}
    local names={"Magic","Curse","Disease","Poison"}
    for i,key in ipairs(fields) do group[key]={i/7,.25,.75,i/8} end
    previewContext(h,1,6); h.config(); h.addon.SwitchTestMode()
    for _,toggles in ipairs({{true,true},{false,true},{true,false},{false,false},{true,true}}) do
        group.ShowBuffBorders,group.ShowDebuffBorders=unpack(toggles); h.config()
        for _,slot in ipairs(s.Slots) do for button,v in pairs(slot.Buttons) do
            borderState(h,button,v,4,45,45)
            local registrations=h.data[button].dispel
            eq(#registrations,(toggles[1] and 1 or 0)+(toggles[2] and 1 or 0))
            for _,registration in ipairs(registrations) do
                local texture,options=registration[1],registration[2]
                eq(options.style,h.env.Enum.CustomAuraButtonDispelTypeTextureStyle.PreserveAsset)
                eq(options.showWithoutDispelType,true); eq(count(options.customDispelColorMap),7)
                local harmful=texture==v.DebuffBorder
                eq(texture,harmful and v.DebuffBorder or v.BuffBorder)
                eq(options.showWhenHarmful,harmful); eq(options.showWhenHelpful,not harmful)
                colorEquals(options.customDispelColorMap.None,group[fields[harmful and 6 or 1]])
                for i,name in ipairs(names) do colorEquals(options.customDispelColorMap[name],group[fields[harmful and i+1 or 1]]) end
                for _,name in ipairs({"Enrage","Bleed"}) do colorEquals(options.customDispelColorMap[name],group[fields[harmful and 6 or 1]]) end
            end
        end end
        eq(#s.Preview.Buttons,6); eq(#previewElements(s),6)
        for i,v in ipairs(s.Preview.Buttons) do
            borderState(h,v.Button,v,4,45,45)
            local border=i==1 and v.BuffBorder or v.DebuffBorder
            eq(h.data[border].shown,toggles[i==1 and 1 or 2])
            truth(same(h.data[border].SetVertexColor,group[fields[i]]))
            eq(h.data[i==1 and v.DebuffBorder or v.BuffBorder].shown,false)
        end
    end
    eq(h.forbiddenReads,0)
end)

test("blizzard_cycle_1_2_4_3_twice_preserves_pool_source_layout_clock_bindings",function()
    local h,_,s=configured(nil,{OnlyShowMyAuras=true,IconSpacing=10,DefaultIconSizeWidth=31,DefaultIconSizeHeight=59})
    local a=h.addon; local group=a.db.IconGroups[1]
    previewContext(h,1,2); a.SwitchTestMode()
    local frames=#h.frames; local durations=h.calls.CreateDuration; local sources=borderSources(h,s)
    local saved,live={},{}
    for i,v in ipairs(s.Preview.Buttons) do
        saved[i]={button=v.Button,buff=v.BuffBorder,debuff=v.DebuffBorder,binding=v.Binding,duration=v.Duration,
            clock=v.EndTime,config=presentationConfig(v.Binding),coords=copy(h.data[v.Texture].SetTexCoord)}
    end
    for _,slot in ipairs(s.Slots) do for button,v in pairs(slot.Buttons) do
        live[button]={v=v,buff=v.BuffBorder,debuff=v.DebuffBorder,icon=h.data[button].icon,
            cooldown=h.data[button].cooldown,count=h.data[button].count,time=h.data[button].time,
            config=presentationConfig(h.data[button].binding),coords=copy(h.data[v.Texture].SetTexCoord)}
    end end
    for pass=1,2 do for _,mode in ipairs({1,2,4,3}) do
        local order={}
        for _,old in pairs(live) do for _,b in ipairs({old.buff,old.debuff}) do order[b]=#h.data[b].callOrder end end
        for _,old in ipairs(saved) do for _,b in ipairs({old.buff,old.debuff}) do order[b]=#h.data[b].callOrder end end
        -- Seed a stale manual crop to ensure SetAtlas/ResetTexCoord actually replace it.
        for b in pairs(order) do b:SetTexCoord(.17,.83,.23,.77); order[b]=#h.data[b].callOrder end
        group.BorderType=mode; group.BorderThickness=pass==1 and 2 or 5
        group.BorderFilePath=pass==1 and "Interface\\first.tga" or "Interface\\second.tga"
        local allocations=h.calls.CreateDurationTextBinding; h.config()
        for button,old in pairs(live) do
            local v=old.v; eq(v.BuffBorder,old.buff); eq(v.DebuffBorder,old.debuff)
            borderState(h,button,v,mode,31,59,group.BorderFilePath,group.BorderThickness)
            for _,b in ipairs({old.buff,old.debuff}) do borderOrder(h,b,order[b],mode) end
            local d=h.data[button]
            eq(d.icon,old.icon); eq(d.cooldown,old.cooldown); eq(d.count,old.count); eq(d.time,old.time)
            truth(same(presentationConfig(d.binding),old.config)); truth(same(h.data[v.Texture].SetTexCoord,old.coords))
            eq(#d.dispel,mode==3 and 0 or 2)
        end
        for i,v in ipairs(s.Preview.Buttons) do
            local old=saved[i]; eq(v.Button,old.button); eq(v.BuffBorder,old.buff); eq(v.DebuffBorder,old.debuff)
            borderState(h,v.Button,v,mode,31,59,group.BorderFilePath,group.BorderThickness)
            for _,b in ipairs({old.buff,old.debuff}) do borderOrder(h,b,order[b],mode) end
            eq(v.Binding,old.binding); eq(v.Duration,old.duration); eq(v.EndTime,old.clock)
            eq(v.Binding.updatedEndTime,old.clock); truth(same(presentationConfig(v.Binding),old.config))
            truth(same(h.data[v.Texture].SetTexCoord,old.coords))
            eq(h.data[v.Cooldown].duration,old.duration)
            eq(h.data[v.BuffBorder].shown,mode~=3 and not v.Harmful)
            eq(h.data[v.DebuffBorder].shown,mode~=3 and v.Harmful)
        end
        truth(same(borderSources(h,s),sources)); assertOwnSpecs(h,s,2)
        for _,spec in ipairs(s.Preview.Groups) do eq(playerComponents(spec.Filter),1); eq(spec.elementSpacing,10); eq(spec.groupSpacing,0) end
        eq(h.data[s.Preview.Root].width,154); eq(h.data[s.Preview.Root].height,59)
        eq(#h.frames,frames); eq(h.calls.CreateDuration,durations); eq(h.pending(true),1)
        -- Config revisions rebuild native presentation templates, not pooled sample bindings.
        eq(h.calls.CreateDurationTextBinding-allocations,#active(h,s)+1)
    end end
    eq(h.forbiddenReads,0); eq(h.blocked or 0,0)
end)

for _,mode in ipairs({1,2,3}) do
    local old=mode
    test("blizzard_old_group_"..old.."_default_schema_reload_unchanged",function()
        local input={DBVersion=22,DefaultSpellsLastSetImported=4,CustomSpells2={},IconGroups={{BorderType=old,BorderThickness=5,BorderFilePath="Interface\\saved.tga"}}}
        local h=fresh(input); local a=h.addon
        eq(a.GetIconGroupDefaultOptions().BorderType,1); eq(a.db.IconGroups[1].BorderType,old)
        eq(a.db.IconGroups[1].BorderThickness,5); eq(a.db.IconGroups[1].BorderFilePath,"Interface\\saved.tga")
        eq(a.db.DBVersion,34); eq(a.DB_SCHEMA_VERSION,34)
        local saved=copy(a.db); a.ReloadDB(); h.flush(); truth(same(a.db,saved))
        catalog(h); a.db.CustomSpells2={rule(h)}; local _,states=h.attach("nameplate1")
        for _,slot in ipairs(states[1].Slots) do for button,v in pairs(slot.Buttons) do
            borderState(h,button,v,old,45,45,"Interface\\saved.tga",5)
            eq(#h.data[button].dispel,old==3 and 0 or 2)
        end end
        eq(h.calls.SetAtlas,nil)
    end)
end

test("blizzard_group4_real_codec_sparse_import_reload_copy_persistence",function()
    local h,_,s=configured(); local a=h.addon
    local input={DBVersion=34,DefaultSpellsLastSetImported=4,
        IconGroups={[1]={IconGroupName="Atlas",BorderType=4,BorderThickness=5,BorderFilePath="Interface\\keep.tga"},
            [3]={IconGroupName="Custom",BorderType=2},[7]={IconGroupName="Atlas seven",BorderType=4}},
        CustomSpells2={rule(h,nil,{customBorderType=3,iconGroups={[1]=true,[3]=true,[7]=true}})}}
    local original=copy(input); local decoded=exportRoundTrip(input); truth(same(decoded,original))
    truth(a.ImportProfile(decoded)); h.flush(); truth(same(decoded,original))
    eq(#a.db.IconGroups,3); truth(same(a.db.CustomSpells2[1].iconGroups,{true,true,true}))
    eq(a.db.IconGroups[1].BorderType,4); eq(a.db.IconGroups[2].BorderType,2); eq(a.db.IconGroups[3].BorderType,4)
    eq(a.db.IconGroups[1].BorderThickness,5); eq(a.db.IconGroups[1].BorderFilePath,"Interface\\keep.tga")
    a.db.IconGroups[4]=a.deepcopy(a.db.IconGroups[1]); a.db.CustomSpells2[1].iconGroups[4]=true
    truth(a.db.IconGroups[4]~=a.db.IconGroups[1]); a.db.IconGroups[4].IconGroupName="Copy"
    a.db.IconGroups[4].BorderThickness=3; eq(a.db.IconGroups[1].BorderThickness,5)
    local saved=exportRoundTrip(a.db)
    a.ReloadDB(); h.flush(); truth(same(a.db,saved))
    h.ace.profile=copy(saved); h.ace.callbacks.OnProfileCopied(); h.flush(); truth(same(a.db,saved))
    local restart=fresh(exportRoundTrip(a.db)); truth(same(restart.addon.db,saved)); eq(restart.addon.db.DBVersion,34)
    eq(s.Unit,"nameplate1"); eq(h.env.NameplateAurasForeverAceDB.profiles.Default~=nil,true)
    h.ace.profile=copy(h.defaults.profile); h.ace.callbacks.OnProfileReset(); h.flush()
    eq(a.db.IconGroups[1].BorderType,1); eq(a.db.DBVersion,34)
end)

for _,invalid in ipairs({{name="five",value=5},{name="zero",value=0},{name="float",value=2.5},
    {name="string",value="4"},{name="table",value={}},{name="nan",value=0/0}}) do
    local case=invalid
    test("blizzard_invalid_group_"..case.name.."_import_rejected_no_live_mutation",function()
        local h,_,s=configured(nil,{BorderType=4}); local a=h.addon; local db=a.db; local group=db.IconGroups[1]
        local saved=copy(db); local sources=sourceSnapshot(h,s); local calls=copy(h.calls); local revision=s.Revision
        for _,topLevel in ipairs({false,true}) do
            local input={DBVersion=34,DefaultSpellsLastSetImported=4,CustomSpells2={},IconGroups={{BorderType=4}}}
            if topLevel then input.BorderType=case.value else input.IconGroups[1].BorderType=case.value end
            local prepared,failure=a.PrepareProfileImport(input); eq(prepared,nil); truth(failure:find("BorderType",1,true))
            local ok,message=a.ImportProfile(input); eq(ok,false); truth(message:find("BorderType",1,true))
            eq(a.db,db); eq(db.IconGroups[1],group); truth(same(db,saved)); truth(same(sourceSnapshot(h,s),sources))
            eq(s.Revision,revision); truth(same(h.calls,calls)); eq(h.pending(false),0)
            local value=topLevel and input.BorderType or input.IconGroups[1].BorderType
            if case.name=="nan" then truth(value~=value) else eq(value,case.value) end
        end
    end)
    test("blizzard_invalid_stored_group_"..case.name.."_normalizes_builtin",function()
        local h=fresh({DBVersion=34,DefaultSpellsLastSetImported=4,CustomSpells2={},
            IconGroups={{BorderType=case.value},{BorderType=4}}})
        eq(h.addon.db.IconGroups[1].BorderType,1); eq(h.addon.db.IconGroups[2].BorderType,4)
        eq(h.addon.db.DBVersion,34); local saved=copy(h.addon.db)
        h.addon.ReloadDB(); h.flush(); truth(same(h.addon.db,saved))
    end)
end

test("blizzard_rule4_rejected_and_1_2_override_3_inherits_group4",function()
    local h,_,s=configured(nil,{BorderType=4}); local a=h.addon; local group=a.db.IconGroups[1]
    group.ShowBuffBorders=false; group.ShowDebuffBorders=false
    local saved=copy(a.db); local e=rule(h,nil,{customBorderType=4})
    eq(a.PrepareSpellImport(e),nil)
    local input=copy(saved); input.CustomSpells2={e}; eq(a.ImportProfile(input),false)
    truth(same(a.db,saved)); eq(e.customBorderType,4)
    for _,mode in ipairs({1,2,3}) do
        local entry=a.db.CustomSpells2[1]; entry.customBorderType=mode; entry.customBorderSize=5
        entry.customBorderPath="Interface\\rule.tga"; entry.customBorderColor={.11,.22,.33,.44}
        local prepared=a.PrepareSpellImport(entry); truth(prepared); eq(prepared.customBorderType,mode)
        previewContext(h,1,7,entry,118); h.config()
        if not a.IsPreviewActive() then a.SwitchTestMode() end
        local effective=mode==3 and 4 or mode
        for _,slot in ipairs(s.Slots) do for button,v in pairs(slot.Buttons) do
            borderState(h,button,v,effective,45,45,entry.customBorderPath,5)
            eq(#h.data[button].dispel,mode==3 and 0 or 2)
            for _,r in ipairs(h.data[button].dispel) do
                for _,color in pairs(r[2].customDispelColorMap) do colorEquals(color,entry.customBorderColor) end
            end
        end end
        for _,v in ipairs(s.Preview.Buttons) do
            borderState(h,v.Button,v,effective,45,45,entry.customBorderPath,5)
            local b=v.Harmful and v.DebuffBorder or v.BuffBorder
            eq(h.data[b].shown,mode~=3)
            if mode~=3 then truth(same(h.data[b].SetVertexColor,entry.customBorderColor)) end
        end
        eq(group.BorderType,4)
    end
    a.db.CustomSpells2[1].customBorderType=4; a.NormalizeForeverProfile()
    eq(a.db.CustomSpells2[1].customBorderType,3); eq(group.BorderType,4)
end)

for _,restriction in ipairs({"combat","secret","both"}) do
    local restricted=restriction
    test("blizzard_deferred_"..restricted.."_existing_borders_exactly_once",function()
        local h,_,s=configured(); local a=h.addon; local group=a.db.IconGroups[1]
        local saved={}; local frames=#h.frames
        for _,slot in ipairs(s.Slots) do for _,v in pairs(slot.Buttons) do
            for _,b in ipairs({v.BuffBorder,v.DebuffBorder}) do saved[b]=copy(h.data[b].calls) end
        end end
        h.combat=restricted~="secret"; h.secret=restricted~="combat"
        for _,mode in ipairs({4,2,4}) do
            group.BorderType=mode; h.config()
            for b,calls in pairs(saved) do truth(same(h.data[b].calls,calls),"restricted border accessed") end
            for _,slot in ipairs(s.Slots) do eq(slot.NeedsSkin,true) end
            eq(h.blocked or 0,0); eq(#h.frames,frames)
        end
        h.combat=false; h.secret=false
        if restricted=="secret" then
            h.event("ADDON_RESTRICTION_STATE_CHANGED",0,h.env.Enum.AddOnRestrictionState.Inactive); h.flush()
        else h.event("PLAYER_REGEN_ENABLED") end
        for _,slot in ipairs(s.Slots) do for button,v in pairs(slot.Buttons) do
            eq(slot.NeedsSkin,false); borderState(h,button,v,4,45,45)
        end end
        for b,calls in pairs(saved) do
            local now=h.data[b].calls
            eq((now.SetAtlas or 0)-(calls.SetAtlas or 0),1)
            eq(now.SetPoint or 0,(calls.SetPoint or 0)+2)
            eq(now.ClearAllPoints,calls.ClearAllPoints+1)
            eq(now.ResetTexCoord,calls.ResetTexCoord,"atlas restyle unexpectedly resets crop")
        end
        local after={}; for b in pairs(saved) do after[b]=copy(h.data[b].calls) end
        h.event("PLAYER_REGEN_ENABLED")
        h.event("ADDON_RESTRICTION_STATE_CHANGED",0,h.env.Enum.AddOnRestrictionState.Inactive); h.flush()
        for b,calls in pairs(after) do truth(same(h.data[b].calls,calls),"deferred style applied twice") end
        -- Also defer atlas -> builtin: ResetTexCoord must be submitted exactly once.
        h.combat=true; h.secret=true; group.BorderType=1; h.config()
        for b,calls in pairs(after) do truth(same(h.data[b].calls,calls)) end
        h.combat=false; h.secret=false; h.event("PLAYER_REGEN_ENABLED")
        for b,calls in pairs(after) do
            local d=h.data[b]; eq(d.calls.ResetTexCoord,calls.ResetTexCoord+1)
            eq(d.calls.SetAtlas,calls.SetAtlas); eq(d.atlas,nil); eq(d.allPoints,d.parent)
        end
        eq(#h.frames,frames); eq(h.blocked or 0,0); eq(h.forbiddenReads,0)
    end)
end

test("blizzard_restricted_new_initialization_uses_existing_callback_window",function()
    local h=fresh(); catalog(h); local a=h.addon
    a.db.IconGroups[1].BorderType=4; a.db.CustomSpells2={rule(h)}
    h.secret=true; h.combat=true; local _,states=h.attach("nameplate1"); local s=states[1]
    for _,slot in ipairs(s.Slots) do for button,v in pairs(slot.Buttons) do
        borderState(h,button,v,4,45,45)
    end end
    local atlas=h.calls.SetAtlas; h.config(); eq(h.calls.SetAtlas,atlas)
    for _,slot in ipairs(s.Slots) do eq(slot.NeedsSkin,true) end
    eq(h.blocked or 0,0); eq(h.forbiddenReads,0)
end)

test("blizzard_decorative_geometry_does_not_expand_public_live_layout_bbox",function()
    local h,_,s=configured(nil,{BorderType=4,DefaultIconSizeWidth=31,DefaultIconSizeHeight=59,IconSpacing=10})
    local root=h.newFrame(); local layout=h.env.AnchorUtil.CreateFlowLayout(); local groups={}
    -- Feed the recorded native dimensions to unchanged public AnchorUtil using
    -- the fixed initialization batch, not a claim about real aura assignment.
    for _,slot in ipairs(s.Slots) do
        local native=h.data[s.Container].groups[slot.Key]
        groups[#groups+1]={elements=native.buttons,elementSpacing=native.layout.elementSpacing,groupSpacing=native.layout.groupSpacing}
    end
    local frames=#h.frames
    for _,mode in ipairs({1,4,2,4,3}) do
        h.addon.db.IconGroups[1].BorderType=mode; h.config(); layout:Apply(root,groups)
        eq(h.data[root].width,154); eq(h.data[root].height,59)
        local cursor=0
        for _,g in ipairs(groups) do for _,button in ipairs(g.elements) do
            eq(h.data[button].points[1][4],cursor); cursor=cursor+41
        end end
        eq(#h.frames,frames)
    end
    eq(h.forbiddenReads,0)
end)

for _,restriction in ipairs({"combat","secret"}) do
    local restricted=restriction
    test("blizzard_preview_queued_"..restricted.."_stops_without_border_submission",function()
        local h,_,s=configured(nil,{BorderType=4}); local a=h.addon
        previewContext(h,1,6); a.SwitchTestMode()
        local saved={}; local frames=#h.frames
        for _,v in ipairs(s.Preview.Buttons) do
            for _,b in ipairs({v.BuffBorder,v.DebuffBorder}) do saved[b]=copy(h.data[b].calls) end
        end
        local atlas=h.calls.SetAtlas; local reset=h.calls.ResetTexCoord
        h[restricted]=true; a.db.IconGroups[1].BorderType=2; h.config()
        stopped(h,s); clearedPreview(h,s)
        eq(h.calls.SetAtlas,atlas); eq(h.calls.ResetTexCoord,reset)
        for b,calls in pairs(saved) do
            local now=h.data[b].calls
            for _,method in ipairs({"SetAtlas","ResetTexCoord","SetPoint","ClearAllPoints","SetAllPoints","SetTexture"}) do
                eq(now[method],calls[method],"restricted preview border submission: "..method)
            end
        end
        h[restricted]=false; h.event("PLAYER_REGEN_ENABLED")
        eq(a.IsPreviewActive(),false,"restriction must not auto-restart preview")
        eq(#h.frames,frames); eq(h.blocked or 0,0); eq(h.forbiddenReads,0)
    end)
end

if selected=="--list" then
    for _,entry in ipairs(tests) do print(entry.name) end
else
    local passed,failed,ran=0,0,0
    print("Runtime: ".._VERSION.."; mocked GetBuildInfo Interface=16001; addon="..addonPath)
    for _,entry in ipairs(tests) do
        if not selected or selected==entry.name then
            ran=ran+1
            local ok,err=xpcall(entry.run,debug.traceback)
            if ok then passed=passed+1; print("PASS "..entry.name)
            else failed=failed+1; print("FAIL "..entry.name.."\n"..err) end
        end
    end
    assert(ran>0,"unknown test: "..tostring(selected))
    print(string.format("RESULT: %d passed, %d failed, %d total",passed,failed,ran))
    print("GAME_TEST_REQUIRED: private secret/taint engine, actual aura matching and assignment, event payloads/order, protected execution and visual rendering.")
    if failed>0 then os.exit(1) end
end
