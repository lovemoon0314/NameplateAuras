"""Independent standard unittest runner for the isolated Lua 5.1 runtime suite.

Run: python3 -B tests/test_runtime.py -v
Or: python3 -B -m unittest discover -s tests -p test_runtime.py -v
LUA51 can select a specific real Lua 5.1 interpreter. No shell or game runs.
"""

import os
from pathlib import Path
import shutil
import subprocess
import unittest


PACKAGE = Path(__file__).resolve().parents[1]
SUITE = Path(__file__).with_suffix(".lua")


def lua51():
    """Reject newer Lua and LuaJIT rather than silently weakening the contract."""
    candidates = [
        os.environ.get("LUA51"),
        shutil.which("lua5.1"),
        str(Path.home() / ".local/bin/lua5.1"),
        shutil.which("lua"),
    ]
    for candidate in dict.fromkeys(c for c in candidates if c):
        try:
            version = subprocess.run(
                [candidate, "-e", "io.write(_VERSION)"],
                capture_output=True, text=True, timeout=5, check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        if version.returncode == 0 and version.stdout == "Lua 5.1":
            return candidate
    raise RuntimeError("INCONCLUSIVE: real Lua 5.1 interpreter unavailable; set LUA51")


class RuntimeTests(unittest.TestCase):
    """Every Lua case gets its own interpreter and isolated mock environment."""


# --list only enumerates cases; it does not load or execute addon modules.
# Discovery errors are errors, never skip/success when Lua 5.1 is unavailable.
INTERPRETER = lua51()
_listing = subprocess.run(
    [INTERPRETER, str(SUITE), str(PACKAGE), "--list"],
    capture_output=True, text=True, timeout=10, check=False,
)
if _listing.returncode:
    raise RuntimeError(_listing.stdout + _listing.stderr)
_names = _listing.stdout.splitlines()
if not _names or len(_names) != len(set(_names)):
    raise RuntimeError("Invalid or empty Lua runtime test inventory")


def runtime_case(name):
    def run(self):
        result = subprocess.run(
            [INTERPRETER, str(SUITE), str(PACKAGE), name],
            capture_output=True, text=True, timeout=30, check=False,
        )
        output = result.stdout + result.stderr
        self.assertEqual(result.returncode, 0, output)
        self.assertIn("RESULT: 1 passed, 0 failed, 1 total", output)
    run.__name__ = "test_" + name
    run.__doc__ = name
    return run


for _name in _names:
    if not _name or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789_" for c in _name):
        raise RuntimeError("Invalid Lua test name: " + repr(_name))
    setattr(RuntimeTests, "test_" + _name, runtime_case(_name))


if __name__ == "__main__":
    print("Runtime interpreter: " + INTERPRETER, flush=True)
    unittest.main()
