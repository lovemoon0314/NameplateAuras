"""Real embedded GUI Lua regression; isolated mocks, not a WoW/game test.

Run: python3 -B tests/test_ui.py -v
No runtime harness is imported or copied; no game or addon installation runs.
"""

import json
import os
from pathlib import Path
import shutil
import subprocess
import unittest


def lua51():
    """Fail closed if an actual Lua 5.1 interpreter cannot be located."""
    candidates = [os.environ.get("LUA51"), shutil.which("lua5.1"),
                  str(Path.home() / ".local/bin/lua5.1"), shutil.which("lua")]
    for candidate in dict.fromkeys(c for c in candidates if c):
        try:
            result = subprocess.run(
                [candidate, "-e", "io.write(_VERSION)"],
                capture_output=True, text=True, timeout=5, check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        if result.returncode == 0 and result.stdout == "Lua 5.1":
            return candidate
    raise RuntimeError("INCONCLUSIVE: real Lua 5.1 unavailable; set LUA51")


PACKAGE = Path(__file__).resolve().parents[1]
SUITE = Path(__file__).with_suffix(".lua")
INTERPRETER = lua51()
CONTRACT = json.loads((PACKAGE / "tests/runtime_contract.json").read_text(encoding="utf-8"))
if CONTRACT["localization_contract"]["vocabulary"] != {
    "nameplate": "姓名板", "buff": "增益", "debuff": "减益",
    "stack_text": "层数文字", "timer_text": "倒计时文字", "profile": "配置方案",
    "aura_rule": "光环规则", "crop": "材质裁切", "frame_strata": "框架层级",
}:
    raise RuntimeError("Localization vocabulary contract changed; review GUI expectations")


class UITests(unittest.TestCase):
    """Each case loads real libraries in a fresh Lua 5.1 process."""


def ui_case(name, locale):
    def run(self):
        result = subprocess.run(
            [INTERPRETER, str(SUITE), str(PACKAGE), name, locale],
            capture_output=True, text=True, timeout=30, check=False,
        )
        output = result.stdout + result.stderr
        self.assertEqual(result.returncode, 0, output)
        self.assertIn("RESULT: 1 passed, 0 failed, 1 total", output)
        self.assertNotIn("Translation missing", output)
        self.assertNotIn("AceLocale-3.0:", output)
    run.__name__ = "test_" + name + "_" + locale
    run.__doc__ = name + " (real AceLocale " + locale + ")"
    return run


listing = subprocess.run(
    [INTERPRETER, str(SUITE), str(PACKAGE), "--list"],
    capture_output=True, text=True, timeout=10, check=False,
)
if listing.returncode:
    raise RuntimeError(listing.stdout + listing.stderr)
names = listing.stdout.splitlines()
if not names or len(names) != len(set(names)):
    raise RuntimeError("Invalid GUI test inventory")
for name in names:
    if not name or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789_" for c in name):
        raise RuntimeError("Invalid GUI test name: " + repr(name))
    for locale in ("enUS", "zhCN"):
        setattr(UITests, "test_" + name + "_" + locale, ui_case(name, locale))


if __name__ == "__main__":
    print("GUI interpreter: " + INTERPRETER, flush=True)
    unittest.main()
