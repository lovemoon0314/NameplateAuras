-- Real embedded GUI regression, Lua 5.1 only; no live WoW, secret simulation,
-- universal missing-method stubs, source extraction, or runtime harness copy.
-- Mock contract evidence: wow-ui-source 1.60.1.70862:
-- Blizzard_APIDocumentationGenerated/SimpleTextureBaseAPIDocumentation.lua:403-414,604-619;
-- SimpleCheckboxAPIDocumentation.lua:49-67; Blizzard_SharedXMLBase/TextureUtil.lua:476.
-- Numeric texture assets are accepted (embedded libraries use FileDataIDs), but
-- wrap/filter parameters must be strings/nil, never the old RGB overload.
-- All supported mock methods are explicitly enumerated below. State is stored;
-- scripts/hooks run on explicit events. Layout/font metrics are approximations.
assert(_VERSION == 'Lua 5.1', 'real Lua 5.1 required')
local root, selected = assert(arg[1]), arg[2]
local tests = {}
local function test(name, run) tests[#tests+1] = {name=name, run=run} end
local function eq(a,b) assert(a==b, 'expected '..tostring(b)..', got '..tostring(a)) end
local function signature(types, ...)
    eq(select('#', ...), #types)
    for i,t in ipairs(types) do eq(type(select(i,...)),t) end
end
local function rejects(fn, text)
    local ok, err = pcall(fn)
    assert(not ok, 'expected failure')
    assert(tostring(err):find(text,1,true), tostring(err))
end
local function harness(locale)
    locale=locale or arg[3] or 'enUS'
    assert(locale=='enUS' or locale=='zhCN', 'unsupported GUI test locale')
    local h = {objects={}, loaded={}, calls={}, combat=false, locale=locale}
    local env, addon = {}, {}
    h.env, h.addon = env, addon
    for _,key in ipairs({'assert','error','ipairs','next','pairs','pcall','xpcall','select','tonumber','tostring','type','unpack','setmetatable','getmetatable','rawget','rawset','rawequal'}) do env[key]=_G[key] end
    env.math, env.string, env.table = {}, {}, {}
    for k,v in pairs(math) do env.math[k]=v end
    for k,v in pairs(string) do env.string[k]=v end
    for k,v in pairs(table) do env.table[k]=v end
    env._G = env
    -- Some embedded libraries use getfenv(0); expose the sandbox, not host globals.
    env.getfenv = function(n) if n==0 then return env end; return getfenv(n) end
    env.wipe = function(t) signature({'table'},t); for k in pairs(t) do t[k]=nil end; return t end
    env.table.wipe = env.wipe
    env.format, env.ceil, env.floor, env.strmatch, env.gmatch = string.format, math.ceil, math.floor, string.match, string.gmatch
    env.GetBuildInfo = function() return '1.60.1','70862','',16001 end
    env.GetLocale = function() return locale end
    env.date = function(pattern) signature({'string'},pattern); return 'test' end
    env.max, env.min = math.max, math.min
    env.GetTime = function() return 0 end
    env.debugprofilestop = function() h.cpu=(h.cpu or 0)+1; return h.cpu end
    env.InCombatLockdown = function() return h.combat end
    env.IsLoggedIn = function() return false end
    env.C_XMLUtil = {GetTemplateInfo=function(name) eq(name,'CustomAuraContainerTemplate'); return {} end}
    env.C_Secrets = {ShouldAurasBeSecret=function() error('secret API outside GUI contract') end}
    env.C_UnitAuras = setmetatable({}, {__index=function() error('forbidden aura API') end})
    env.UnitAura = function() error('forbidden aura API') end
    env.C_Spell = {
        GetSpellInfo=function(id)
            assert(type(id)=='number' or type(id)=='string')
            if id==118 or id=='Polymorph' then return {name='Polymorph',spellID=118,iconID=136071} end
        end,
        GetSpellTexture=function(id) assert(type(id)=='number' or type(id)=='string'); return id==118 and 136071 or 134400 end,
    }
    env.C_Timer = {After=function(delay,fn) signature({'number','function'},delay,fn); h.calls.After=(h.calls.After or 0)+1 end}
    env.bit = {band=function(a,b)
        signature({'number','number'},a,b)
        local result, place = 0,1
        while a>0 and b>0 do if a%2==1 and b%2==1 then result=result+place end; a,b,place=math.floor(a/2),math.floor(b/2),place*2 end
        return result
    end}
    local clientText={UNKNOWN='未知',OKAY='确定',YES='是',NO='否',CLOSE='关闭',ACCEPT='接受',INFO='信息'}
    for _,k in ipairs({'UNKNOWN','OKAY','YES','NO','CLOSE','ACCEPT','INFO'}) do env[k]=locale=='zhCN' and clientText[k] or k end
    env.BackdropTemplateMixin = {}
    env.SOUNDKIT = {IG_MAINMENU_OPTION_CHECKBOX_ON=1}
    env.PlaySound = function(id) signature({'number'},id); h.calls.sound=(h.calls.sound or 0)+1 end
    env.StaticPopupDialogs, env.SlashCmdList = {}, {}
    env.StaticPopup_Show = function(key) signature({'string'},key); assert(env.StaticPopupDialogs[key]); h.popup=key end
    env.DEFAULT_CHAT_FRAME = {AddMessage=function(_,text,r,g,b) signature({'string','number','number','number'},text,r,g,b); h.message=text end}
    env.ChatEdit_InsertLink = function(link) signature({'string'},link) end
    env.geterrorhandler = function() return function(err) error(err) end end
    local methods, newObject = {}, nil
    local anchors = {TOPLEFT=true,TOP=true,TOPRIGHT=true,LEFT=true,CENTER=true,RIGHT=true,BOTTOMLEFT=true,BOTTOM=true,BOTTOMRIGHT=true}
    local function obj(o) assert(type(o)=='table' and o._kind, 'expected mock UI object'); return o end
    local function fire(o,script,...)
        if o._scripts[script] then o._scripts[script](o,...) end
        for _,fn in ipairs(o._hooks[script] or {}) do fn(o,...) end
    end
    h.fire = fire
    newObject = function(kind,parent,name)
        local o={_kind=kind,_parent=parent,_name=name,_shown=true,_enabled=true,_scripts={},_hooks={},_points={},_width=0,_height=0,_text='',_color={1,1,1,1}}
        setmetatable(o,{__index=methods}) -- Unknown methods remain nil and fail.
        h.objects[#h.objects+1]=o
        if name then env[name]=o end
        return o
    end
    -- State-only setters: each has an explicit signature, records every call,
    -- and never provides a fallback for unknown method names.
    local function setter(name, types)
        methods[name]=function(self,...)
            obj(self); signature(types,...); self['_last_'..name]={...}
            h.calls[name]=(h.calls[name] or 0)+1
        end
    end
    for _,name in ipairs({'SetAlpha','SetScale','SetFrameLevel','SetValueStep','SetMaxLetters','SetMaxBytes','SetCursorPosition','SetVerticalScroll'}) do setter(name,{'number'}) end
    for _,name in ipairs({'SetBackdrop','SetFontObject','SetNormalFontObject','SetHighlightFontObject'}) do setter(name,{'table'}) end
    for _,name in ipairs({'SetJustifyH','SetJustifyV','SetFrameStrata','SetOrientation','SetButtonState'}) do setter(name,{'string'}) end
    for _,name in ipairs({'SetAutoFocus','SetMultiLine','SetCountInvisibleLetters','SetDesaturated','SetObeyStepOnDrag','SetNumeric','SetFixedFrameStrata','SetFixedFrameLevel'}) do setter(name,{'boolean'}) end
    for _,name in ipairs({'EnableMouse','SetMovable','SetToplevel','SetClampedToScreen','SetResizable'}) do
        methods[name]=function(self,v) obj(self); assert(v==nil or type(v)=='boolean' or v==0 or v==1); self['_last_'..name]=v end
    end
    for _,name in ipairs({'ClearFocus','SetFocus','LockHighlight','UnlockHighlight','StartMoving','StopMovingOrSizing','ClearAllPoints'}) do
        methods[name]=function(self,...) signature({},...); self['_last_'..name]=true; if name=='ClearAllPoints' then self._points={} end end
    end
    setter('StartSizing',{'string'})
    setter('SetResizeBounds',{'number','number'})
    setter('SetHitRectInsets',{'number','number','number','number'})
    setter('SetTextInsets',{'number','number','number','number'})
    methods.SetWidth=function(self,w) signature({'number'},w); self._width=w end
    methods.SetHeight=function(self,v) signature({'number'},v); self._height=v end
    methods.SetSize=function(self,w,v) signature({'number','number'},w,v); self:SetWidth(w); self:SetHeight(v) end
    methods.GetWidth=function(self) return self._width end
    methods.GetHeight=function(self) return self._height end
    methods.GetParent=function(self) return self._parent end
    methods.GetName=function(self) return self._name end
    methods.SetParent=function(self,parent) obj(parent); self._parent=parent end
    methods.SetPoint=function(self,p,...)
        assert(anchors[p], 'invalid anchor')
        local values={...}; local n=select('#',...)
        if n==0 then
        elseif type(values[1])=='number' then signature({'number','number'},...)
        else
            if type(values[1])=='string' then assert(env[values[1]],'unknown relative frame') else obj(values[1]) end
            if n==1 then
            elseif type(values[2])=='number' then eq(n,3); signature({'number','number'},values[2],values[3])
            else assert(anchors[values[2]],'invalid relative anchor'); assert(n==2 or n==4); if n==4 then signature({'number','number'},values[3],values[4]) end end
        end
        self._points[#self._points+1]={p,...}
    end
    methods.GetPoint=function(self) return unpack(self._points[1] or {}) end
    methods.SetAllPoints=function(self,relative) if relative~=nil then obj(relative) end; self._allPoints=relative or self._parent end
    methods.SetScript=function(self,key,fn) signature({'string'},key); assert(fn==nil or type(fn)=='function'); self._scripts[key]=fn end
    methods.GetScript=function(self,key) signature({'string'},key); return self._scripts[key] end
    methods.HookScript=function(self,key,fn) signature({'string','function'},key,fn); self._hooks[key]=self._hooks[key] or {}; table.insert(self._hooks[key],fn) end
    -- OnShow/OnHide follow effective parent visibility, including descendants.
    local function visibility(self,shown,...)
        signature({},...)
        local before={}; for _,o in ipairs(h.objects) do before[o]=o:IsVisible() end
        self._shown=shown
        for _,o in ipairs(h.objects) do
            local now=o:IsVisible()
            if before[o]~=now then fire(o,now and 'OnShow' or 'OnHide') end
        end
    end
    methods.Show=function(self,...) visibility(self,true,...) end
    methods.Hide=function(self,...) visibility(self,false,...) end
    methods.IsShown=function(self) return self._shown end
    methods.IsVisible=function(self) return self._shown and (not self._parent or self._parent:IsVisible()) end
    methods.SetShown=function(self,v) signature({'boolean'},v); if v then self:Show() else self:Hide() end end
    methods.Enable=function(self) self._enabled=true end
    methods.Disable=function(self) self._enabled=false end
    methods.SetEnabled=function(self,v) signature({'boolean'},v); self._enabled=v end
    methods.IsEnabled=function(self) return self._enabled end
    methods.SetChecked=function(self,v) assert(v==nil or type(v)=='boolean' or v==0 or v==1,'invalid checked value'); self._checked=v==true or v==1 end
    methods.GetChecked=function(self) return self._checked or false end
    methods.Click=function(self,button) assert(button==nil or type(button)=='string'); if self._enabled then if self._kind=='CheckButton' then self._checked=not self:GetChecked() end; fire(self,'OnClick',button or 'LeftButton') end end
    methods.RegisterEvent=function(self,name) signature({'string'},name); self._events=self._events or {}; self._events[name]=true end
    methods.UnregisterEvent=function(self,name) signature({'string'},name); self._events[name]=nil end
    methods.SetText=function(self,text)
        assert(text==nil or type(text)=='string' or type(text)=='number')
        local old=self._text; self._text=text==nil and '' or tostring(text)
        if self._kind=='EditBox' then fire(self,'OnTextSet'); if old~=self._text then fire(self,'OnTextChanged',false) end end
    end
    methods.Insert=function(self,text)
        eq(self._kind,'EditBox'); signature({'string'},text)
        local range=self._highlight; local first=range and range[1] or 0; local last=range and range[2] or first
        self._text=self._text:sub(1,first)..text..self._text:sub(last+1); self._highlight=nil
        fire(self,'OnTextChanged',true)
    end
    methods.GetText=function(self) return self._text end
    methods.GetStringWidth=function(self) return #self._text*6 end
    methods.GetStringHeight=function(self) return 12 end
    methods.GetNumLetters=function(self) return #self._text end
    methods.GetMaxBytes=function(self) return 0 end
    methods.GetMaxLetters=function(self) return 0 end
    methods.GetCursorPosition=function(self) return 0 end
    methods.IsInIMECompositionMode=function() return false end
    methods.HighlightText=function(self,a,b) signature({'number','number'},a,b); self._highlight={a,b} end
    methods.SetFont=function(self,path,size,flags) signature({'string','number','string'},path,size,flags); self._font={path,size,flags}; return true end
    methods.GetFont=function(self) return unpack(self._font or {'test.ttf',12,''}) end
    methods.SetTextColor=function(self,r,g,b,a) signature({'number','number','number'},r,g,b); assert(a==nil or type(a)=='number'); self._textColor={r,g,b,a or 1} end
    methods.SetVertexColor=function(self,r,g,b,a) signature({'number','number','number'},r,g,b); assert(a==nil or type(a)=='number'); self._color={r,g,b,a or 1} end
    methods.GetVertexColor=function(self) return unpack(self._color) end
    methods.SetColorTexture=function(self,r,g,b,a) eq(self._kind,'Texture'); self:SetVertexColor(r,g,b,a); self._solid={r,g,b,a or 1}; h.calls.SetColorTexture=(h.calls.SetColorTexture or 0)+1 end
    methods.SetTexture=function(self,asset,hwrap,vwrap,filter,...)
        eq(self._kind,'Texture'); signature({},...)
        assert(asset==nil or type(asset)=='string' or type(asset)=='number','invalid texture asset')
        for _,v in pairs({hwrap=hwrap,vwrap=vwrap,filter=filter}) do assert(type(v)=='string','texture wrap/filter must be string') end
        self._asset=asset; h.calls.SetTexture=(h.calls.SetTexture or 0)+1; return true
    end
    methods.SetTexCoord=function(self,...) assert(select('#',...)==4 or select('#',...)==8); for _,v in ipairs({...}) do eq(type(v),'number') end; self._texCoord={...} end
    methods.SetBackdropColor=methods.SetVertexColor
    methods.SetBackdropBorderColor=methods.SetVertexColor
    methods.CreateTexture=function(self,name,layer,template,sublevel)
        assert(name==nil or type(name)=='string'); assert(layer==nil or type(layer)=='string'); assert(template==nil or type(template)=='string'); assert(sublevel==nil or type(sublevel)=='number')
        return newObject('Texture',self,name)
    end
    methods.CreateFontString=function(self,name,layer,template) assert(name==nil or type(name)=='string'); assert(layer==nil or type(layer)=='string'); assert(template==nil or type(template)=='string'); return newObject('FontString',self,name) end
    for _,slot in ipairs({'Normal','Pushed','Highlight','Disabled','Checked','DisabledChecked','Thumb'}) do
        methods['Set'..slot..'Texture']=function(self,asset)
            assert(type(asset)=='table' or type(asset)=='string' or type(asset)=='number')
            local tex=type(asset)=='table' and obj(asset) or self:CreateTexture()
            eq(tex._kind,'Texture'); if type(asset)~='table' then tex:SetTexture(asset) end
            self['_texture'..slot]=tex
        end
        methods['Get'..slot..'Texture']=function(self) return self['_texture'..slot] end
    end
    methods.SetMinMaxValues=function(self,a,b) signature({'number','number'},a,b); assert(a<=b); self._range={a,b} end
    methods.GetMinMaxValues=function(self) return unpack(self._range) end
    methods.SetValue=function(self,v) signature({'number'},v); if self._value~=v then self._value=v; fire(self,'OnValueChanged',v,false) end end
    methods.GetValue=function(self) return self._value or 0 end
    methods.SetScrollChild=function(self,child) obj(child); self._scrollChild=child end
    methods.GetVerticalScroll=function(self) return self._last_SetVerticalScroll and self._last_SetVerticalScroll[1] or 0 end
    env.CreateFrame=function(kind,name,parent,template)
        signature({'string'},kind); assert(name==nil or type(name)=='string'); if parent then obj(parent) end
        local templates={BackdropTemplate=true,InputBoxTemplate=true,UIPanelScrollFrameTemplate=true,UIPanelButtonTemplate=true,UIDropDownMenuTemplate=true,WowStyle1DropdownTemplate=true,GameTooltipTemplate=true,DialogBorderOpaqueTemplate=true}
        assert(template==nil or templates[template], 'unsupported template '..tostring(template))
        local kinds={frame='Frame',button='Button',checkbutton='CheckButton',editbox='EditBox',scrollframe='ScrollFrame',slider='Slider',dropdownbutton='DropdownButton',gametooltip='GameTooltip'}
        kind=assert(kinds[kind:lower()],'unsupported frame type '..kind)
        local o=newObject(kind,parent,name)
        if template=='UIPanelScrollFrameTemplate' then o.ScrollBar=newObject('Slider',o,name and name..'ScrollBar') end
        if template=='UIDropDownMenuTemplate' then assert(name); o.Text=newObject('FontString',o,name..'Text') end
        return o
    end
    env.UIParent=newObject('Frame'); env.UIParent:SetSize(1920,1080)
    for _,name in ipairs({'GameFontNormal','GameFontHighlight','GameFontHighlightSmall','ChatFontNormal'}) do env[name]=newObject('Font') end
    env.hooksecurefunc=function(a,b,c)
        local target,key,fn
        if type(a)=='string' then target,key,fn=env,a,b else target,key,fn=a,b,c end
        signature({'table','string','function'},target,key,fn)
        local original=assert(target[key], 'hook target missing: '..key)
        target[key]=function(...) local result={original(...)}; fn(...); return unpack(result) end
    end
    -- Modern menu descriptions execute generators, validate radios and retain callbacks.
    methods.SetupMenu=function(self,generator)
        eq(self._kind,'DropdownButton'); signature({'function'},generator)
        local description={entries={}}
        description.CreateTitle=function(s,text) signature({'string'},text); s.title=text end
        description.CreateRadio=function(s,text,isSelected,onSelect,data)
            signature({'string','function','function'},text,isSelected,onSelect)
            local entry={text=text,data=data,selected=isSelected(data),select=onSelect}
            signature({'boolean'},entry.selected)
            entry.SetEnabled=function(e,v) signature({'boolean'},v); e.enabled=v end
            s.entries[#s.entries+1]=entry; return entry
        end
        generator(self,description); self._menu=description
    end
    env.C_AddOns={IsAddOnLoaded=function(name) signature({'string'},name); return false,false end}
    env.UIDropDownMenu_SetWidth=function(frame,width) obj(frame); signature({'number'},width); frame:SetWidth(width) end
    env.UIDropDownMenu_SetText=function(frame,text) obj(frame); signature({'string'},text); frame._menuText=text end
    env.UIDropDownMenu_SetSelectedValue=function(frame,value) obj(frame); frame._selected=value end
    env.UIDropDownMenu_GetSelectedValue=function(frame) obj(frame); return frame._selected end
    env.UIDropDownMenu_CreateInfo=function() return {} end
    -- The client copies info fields onto buttons; reused info tables must not alias.
    -- Evidence: Blizzard_SharedXML/Mainline/UIDropDownMenu.lua:545-563.
    env.UIDropDownMenu_AddButton=function(info)
        signature({'table'},info); assert(h.menuTarget,'no menu initialization')
        local saved={}; for key,value in pairs(info) do saved[key]=value end
        table.insert(h.menuTarget._items,saved)
    end
    env.UIDropDownMenu_Initialize=function(frame,fn)
        obj(frame); signature({'function'},fn); frame._items={}; h.menuTarget=frame; fn(frame,1); h.menuTarget=nil
    end
    env.ColorPickerFrame = newObject('Frame',env.UIParent)
    local picker=env.ColorPickerFrame
    picker.SetupColorPickerAndShow=function(self,info)
        signature({'table'},info); for _,key in ipairs({'swatchFunc','opacityFunc','cancelFunc'}) do eq(type(info[key]),'function') end
        signature({'boolean','number','number','number','number'},info.hasOpacity,info.r,info.g,info.b,info.opacity)
        h.pickerInfo=info; self._color={info.r,info.g,info.b,info.opacity}; self:Show()
    end
    picker.GetColorRGB=function(self) return self._color[1],self._color[2],self._color[3] end
    picker.GetColorAlpha=function(self) return self._color[4] end
    function h.load(path)
        local chunk=assert(loadfile(root..'/'..path)); setfenv(chunk,env); chunk('NameplateAuras_Forever',addon); h.loaded[path]=true
    end
    for _,path in ipairs({'libs/LibStub/LibStub.lua','libs/CallbackHandler-1.0/CallbackHandler-1.0.lua','libs/AceLocale-3.0/AceLocale-3.0.lua','libs/LibSharedMedia-3.0/LibSharedMedia-3.0/LibSharedMedia-3.0.lua','libs/LibRedDropdown-1.0/libs/ForAllIndentsAndPurposes.lua','libs/LibRedDropdown-1.0/LibRedDropdown-1.0.lua'}) do h.load(path) end
    h.lib=env.LibStub('LibRedDropdown-Forever-1.0')
    return h
end

test('colorpicker_real_constructor_confirm_opacity_cancel', function()
    local h=harness(); local b=h.lib.CreateColorPicker()
    eq(select(2,h.env.LibStub:GetLibrary('LibRedDropdown-Forever-1.0')),25)
    eq(b.texture._solid[1],1); eq(b.texture._solid[4],1)
    assert(h.calls.SetTexture>=2 and h.calls.SetColorTexture>=1)
    b:SetColor(.2,.3,.4,.5); b:SetText('Color'); eq(b:GetText(),'Color')
    local calls={}
    b.func=function(self,r,g,blue,a) eq(self,b); signature({'number','number','number','number'},r,g,blue,a); calls[#calls+1]={r,g,blue,a} end
    b:Click(); local info=h.pickerInfo
    eq(info.r,.2); eq(info.opacity,.5)
    h.env.ColorPickerFrame._color={.8,.7,.6,.9}; info.swatchFunc()
    eq(calls[1][1],.8); eq(select(4,b:GetColor()),.9)
    h.env.ColorPickerFrame._color[4]=.1; info.opacityFunc(); eq(calls[2][4],.1)
    info.cancelFunc({}); eq(#calls,3); eq(calls[3][1],.2); eq(calls[3][4],.5)
    b:Click(); h.env.ColorPickerFrame._color={.9,.9,.9,1}; h.pickerInfo.swatchFunc()
    eq(select(1,b:GetColor()),.9)
end)

test('mock_rejects_rgb_texture_overload_and_missing_methods', function()
    local h=harness(); local tex=h.env.UIParent:CreateTexture()
    tex:SetTexture(134400,'CLAMP','CLAMP','LINEAR')
    rejects(function() tex:SetTexture(1,1,1,1) end,'wrap/filter')
    rejects(function() tex:SetTexture('asset',false) end,'wrap/filter')
    rejects(function() tex:UnspecifiedMethod() end,'UnspecifiedMethod')
    rejects(function() tex:SetColorTexture('red',0,0,1) end,'expected number')
    rejects(function() h.env.C_UnitAuras.GetAuraDataByIndex() end,'forbidden aura')
end)

test('checkbox_button_slider_real_constructors_and_callbacks', function()
    local h=harness(); local check=h.lib.CreateCheckBox()
    check:SetText('Check'); eq(check:GetText(),'Check'); check:SetChecked(false)
    check:SetOnClickHandler(function(self) eq(self,check); eq(self:GetChecked(),true) end)
    check:Click(); eq(check:GetChecked(),true)
    local enter=0; check:HookScript('OnEnter',function() enter=enter+1 end); h.fire(check.textFrame,'OnEnter'); eq(enter,1)
    local b=h.lib.CreateButton(); b:SetText('Run'); eq(b:GetText(),'Run'); b:SetGray(true); eq(b:IsGrayed(),true)
    b:SetGray(false); b:SetCheckBoxVisible(true); b:SetChecked(true); eq(b:GetChecked(),true)
    local clicked=0; b:SetScript('OnClick',function(self) eq(self,b); clicked=clicked+1 end); b:Click(); eq(clicked,1)
    local s=h.lib.CreateSlider(); local slider=s:GetBaseSliderObject()
    eq(slider._kind,'Slider'); eq(s:GetEditboxObject()._kind,'EditBox')
    slider:SetMinMaxValues(0,100); slider:SetValueStep(1)
    local value; slider:SetScript('OnValueChanged',function(self,v,user) eq(self,slider); signature({'number','boolean'},v,user); value=v end)
    slider:SetValue(25); eq(value,25); eq(slider:GetValue(),25)
    local combined=h.lib.CreateCheckBoxWithColorPicker(); combined:SetColor(.1,.2,.3,.4); eq(select(4,combined:GetColor()),.4)
end)

test('dropdown_real_list_search_selection_and_data_source', function()
    local h=harness(); eq(h.lib.Localization,nil)
    local menu=h.lib.CreateDropdownMenu(); local clicked=0
    local values={{text='Alpha',icon=134400,func=function(self) eq(self.text,'Alpha'); clicked=clicked+1 end},{text='Beta'}}
    menu:SetList(values); menu:Show(); menu:GetButtonByText('Alpha'):Click(); eq(clicked,1); eq(menu:IsShown(),false)
    menu:Show(); menu.searchBox:SetText('Beta'); eq(menu:GetButtonByText('Beta'):IsShown(),true); eq(menu:GetList(),values)
    menu:Hide(); eq(menu.searchBox:GetText(),'')
    local menu2=h.lib.CreateDropdownMenu2(); local updates=0
    menu2:SetDataSource(function(self) eq(self,menu2); updates=updates+1; return {{text='Gamma'}} end)
    menu2:Show(); eq(updates,1); eq(menu2:GetButtonByText('Gamma'):IsShown(),true)
    menu2:Update(); eq(updates,2)
    local dropdown=h.lib.CreateDropdown(); dropdown:SetSize(180,20)
    dropdown:SetList({{text='First',selected=true},{text='Second'}}); eq(dropdown:GetText(),'First')
    dropdown:Click(); dropdown.menu:GetButtonByText('Second'):Click(); eq(dropdown:GetText(),'Second')
end)

local function guiHarness(locale)
    local h=harness(locale); local env,addon=h.env,h.addon
    for _,path in ipairs({'locales/enUS.lua','locales/zhCN.lua','src/consts.lua','src/utils.lua','src/spells.lua','src/database.lua','libs/LibSerialize/LibSerialize.lua','libs/LibDeflate/LibDeflate.lua','libs/LibDataBroker-1.1/LibDataBroker-1.1.lua','src/options-dialog.lua','src/NameplateAuras.lua'}) do h.load(path) end
    -- Follow options-before-core TOC order, without login/event dispatch.
    -- Obtain real defaults; aura containers and database initialization stay out.
    addon.db={CustomSpells2={},IconGroups={addon.GetIconGroupDefaultOptions('Test Group')}}
    return h
end

test('gui_real_initialization_twelve_categories', function()
    local h=guiHarness(); h.addon.ShowGUI()
    local gui=h.addon.GUIFrame; eq(#gui.CategoryButtons,12); eq(#gui.Categories,12); eq(gui:IsShown(),true)
    for i=1,12 do assert(#gui.Categories[i]>0,'empty category '..i); gui.CategoryButtons[i]:Click(); eq(gui.ActiveCategory,i) end
    gui:Hide(); eq(gui:IsShown(),false); h.addon.ShowGUI(); eq(h.addon.GUIFrame,gui); eq(gui.ActiveCategory,12)
end)

local function findObject(h,predicate)
    for _,o in ipairs(h.objects) do if predicate(o) then return o end end
    error('expected GUI control not found')
end

test('gui_catalog_progress_ready_and_show_hide_lifecycle', function()
    local h=guiHarness(); local addon=h.addon
    addon.ShowGUI(); local gui=addon.GUIFrame
    local progress=findObject(h,function(o) return o._kind=='Frame' and o._parent==gui and o.text and o.text:GetText():find('静态法术目录索引',1,true) end)
    eq(addon.SpellCatalog.Running,true); assert(progress:GetScript('OnUpdate')); eq(progress:IsVisible(),true)
    addon.SpellCatalog.Progress=37; h.fire(progress,'OnUpdate',.1)
    assert(progress.text:GetText():find('37%',1,true))
    gui:Hide(); eq(progress:IsShown(),false); eq(progress:GetScript('OnUpdate'),nil)
    addon.ShowGUI(); assert(progress:GetScript('OnUpdate')); eq(progress:IsVisible(),true)
    addon.SpellCatalog.Ready=true; addon.SpellCatalog.Progress=100
    addon.OnSpellInfoCachesReady(); h.fire(progress,'OnUpdate',.1)
    eq(progress:IsShown(),false); eq(progress:GetScript('OnUpdate'),nil)
    gui:Hide(); addon.ShowGUI(); eq(progress:IsShown(),false); eq(progress:GetScript('OnUpdate'),nil)
    -- Actual GUI OnEvent path; no protected/secret execution is simulated.
    h.fire(gui,'OnEvent','PLAYER_REGEN_DISABLED'); eq(gui:IsShown(),false); eq(gui._events.PLAYER_REGEN_ENABLED,true)
    h.fire(gui,'OnEvent','PLAYER_REGEN_ENABLED'); eq(gui:IsShown(),true); eq(gui._events.PLAYER_REGEN_ENABLED,nil)
    gui:Hide(); h.combat=true; addon.ShowGUI(); eq(gui:IsShown(),false); assert(h.message)
end)

test('gui_unready_spell_rule_page_and_unresolved_name', function()
    local h=guiHarness(); local addon=h.addon
    -- Keep metadata absent, including a persisted rule not in the catalog.
    addon.db.CustomSpells2={{spellName='Unresolved',enabledState=addon.CONST_SPELL_MODE_ALL,iconGroups={[1]=true},
        iconSizeWidth=45,iconSizeHeight=45,auraType=addon.AURA_TYPE_ANY,glowType=addon.GLOW_TYPE_AUTOUSE,
        animationDisplayMode=addon.ICON_ANIMATION_DISPLAY_MODE_NONE,animationType=addon.ICON_ANIMATION_TYPE_ALPHA}}
    addon.ShowGUI(); local gui=addon.GUIFrame
    local addButton=findObject(h,function(o) return o._kind=='Button' and o.Text and o:GetText()==h.env.LibStub('AceLocale-3.0'):GetLocale('NameplateAuras_Forever')['options:spells:add-import-new-spell'] end)
    gui.CategoryButtons[7]:Click(); eq(addButton:IsEnabled(),false)
    eq(addon.SpellCatalog.Ready,false); eq(addon.SpellCatalog.ByName.Unresolved,nil)
    addButton:Click(); eq(#addon.db.CustomSpells2,1)
    local menu=findObject(h,function(o) return o.dataSource and o:GetButtonByText('Unresolved')~=nil end)
    assert(menu:GetButtonByText('Unresolved'))
    -- Exercises real GetCurrentlyEditingSpell's nil-safe catalog lookup.
    menu:GetButtonByText('Unresolved'):Click()
    local rule,id=addon.GetCurrentlyEditingSpell(); eq(rule,addon.db.CustomSpells2[1]); eq(id,nil)
    gui:Hide(); eq(addButton:IsEnabled(),false)
    addon.SpellCatalog.Ready=true; addon.OnSpellInfoCachesReady()
    addon.ShowGUI(); gui.CategoryButtons[7]:Click(); eq(addButton:IsEnabled(),true)
end)

test('gui_real_colorpicker_callback_updates_and_restores_profile', function()
    local h=guiHarness(); h.addon.ShowGUI()
    h.addon.GUIFrame.CategoryButtons[4]:Click()
    local button=findObject(h,function(o) return o.colorSwatch and o:GetText()=='0%' end)
    local original={button:GetColor()}
    button:Click(); h.env.ColorPickerFrame._color={.25,.5,.75,.8}
    h.pickerInfo.swatchFunc()
    local color=h.addon.db.IconGroups[1].TimerTextColorZeroPercent
    eq(color[1],.25); eq(color[2],.5); eq(color[3],.75); eq(color[4],.8)
    h.pickerInfo.cancelFunc()
    color=h.addon.db.IconGroups[1].TimerTextColorZeroPercent
    for i=1,4 do eq(color[i],original[i]) end
end)

local function controlByText(h,key)
    local text=h.env.LibStub('AceLocale-3.0'):GetLocale('NameplateAuras_Forever')[key]
    return findObject(h,function(o) return (o._kind=='Button' or o._kind=='CheckButton') and o.Text and o:GetText()==text end)
end

local function previewHarness(locale)
    local h=guiHarness(locale); local addon=h.addon
    h.refreshes,h.notifications=0,0
    local update,notify=addon.UpdateAllNameplates,addon.OnPreviewContextChanged
    addon.UpdateAllNameplates=function(...)
        assert(select('#',...)<=1); local force=...; assert(force==nil or type(force)=='boolean')
        h.refreshes=h.refreshes+1; update()
    end
    addon.OnPreviewContextChanged=function(...)
        signature({},...); h.notifications=h.notifications+1
        notify(); h.lastContext={addon.GetPreviewContext()}
    end
    return h
end

local function completeRule(addon,name)
    return {spellName=name or 'Polymorph',enabledState=addon.CONST_SPELL_MODE_ALL,iconGroups={[1]=true},
        iconSizeWidth=45,iconSizeHeight=45,auraType=addon.AURA_TYPE_ANY,
        showOnFriends=true,showOnEnemies=true,showOnPlayers=true,showOnNpcs=true,showOnPets=true,
        glowType=addon.GLOW_TYPE_AUTOUSE,animationType=addon.ICON_ANIMATION_TYPE_ALPHA,
        animationTimer=10,animationDisplayMode=addon.ICON_ANIMATION_DISPLAY_MODE_NONE,
        customBorderColor={1,.1,.1,1},customBorderSize=2,customBorderType=addon.BORDER_TYPE_DISABLED,customBorderPath=''}
end

local function selectRule(h,rule)
    local menu=findObject(h,function(o)
        if not o.dataSource then return false end
        for _,item in ipairs(o.list) do if item.info==rule then return true end end
        return false
    end)
    menu:Update()
    for _,item in ipairs(menu.list) do
        if item.info==rule then menu:GetButtonByText(item.text):Click(); return menu end
    end
    error('real rule dropdown entry missing')
end

local function backButton(h)
    return findObject(h,function(o)
        return o._kind=='Button' and o._parent and o._parent.SetSpell and o:GetScript('OnClick')
    end)
end

local function context(h,group,category,rule,id)
    eq(select('#',h.addon.GetPreviewContext()),4)
    local g,c,r,s=h.addon.GetPreviewContext(); eq(g,group); eq(c,category); eq(r,rule); eq(s,id)
end

local function initializeAuraMenu(h)
    local menu=h.env['NAurasForever.GUI.Cat4.DropdownSpellShowType']
    h.env.UIDropDownMenu_Initialize(menu,menu.initialize)
    return menu
end

local function auraMenuButton(h,item)
    local button=h.env.CreateFrame('Button'); button.value=item.value; button:SetText(item.text)
    button:SetScript('OnClick',item.func); return button
end

test('gui_page4_relative_toggles_refresh_after_write', function()
    local h=previewHarness(); local addon=h.addon; addon.ShowGUI(); addon.GUIFrame.CategoryButtons[4]:Click()
    local group=addon.db.IconGroups[1]
    for _,spec in ipairs({{'options:timer-text:scale-font-size','TimerTextUseRelativeScale'},
                         {'options:timer-text:relative-color','TimerTextUseRelativeColor'}}) do
        local button=controlByText(h,spec[1]); local initial=button:GetChecked()
        local before=h.refreshes; button:Click(); eq(group[spec[2]],not initial); eq(h.refreshes,before+1)
        button:Click(); eq(group[spec[2]],initial); eq(h.refreshes,before+2)
    end
    -- Execute only the two checkbox readbacks; other existing slider handlers refresh.
    for _,spec in ipairs({{'options:timer-text:scale-font-size','TimerTextUseRelativeScale'},
                         {'options:timer-text:relative-color','TimerTextUseRelativeColor'}}) do
        local button=controlByText(h,spec[1]); local found=false
        for _,fn in ipairs(addon.GUIFrame.OnDBChangedHandlers) do
            local index=1
            while true do
                local name,value=debug.getupvalue(fn,index); if not name then break end
                if value==button then
                    group[spec[2]]=not button:GetChecked(); local before=h.refreshes
                    fn(); eq(button:GetChecked(),group[spec[2]]); eq(h.refreshes,before); found=true; break
                end
                index=index+1
            end
        end
        assert(found,'checkbox readback missing')
    end
end)

test('gui_page7_aura_menu_copies_info_refreshes_and_guards_nil_selection', function()
    local h=previewHarness(); local addon=h.addon; local rule=completeRule(addon)
    addon.db.CustomSpells2={rule}; addon.ShowGUI(); addon.GUIFrame.CategoryButtons[7]:Click(); selectRule(h,rule)
    local menu=initializeAuraMenu(h); eq(#menu._items,3)
    eq(menu._items[1].value,addon.AURA_TYPE_BUFF); eq(menu._items[2].value,addon.AURA_TYPE_DEBUFF)
    assert(menu._items[1]~=menu._items[2])
    local button=auraMenuButton(h,menu._items[1]); local before=h.refreshes
    button:Click(); eq(rule.auraType,addon.AURA_TYPE_BUFF); eq(h.refreshes,before+1)
    eq(h.env[menu:GetName()..'Text']:GetText(),menu._items[1].text)
    backButton(h):Click(); before=h.refreshes
    button:Click(); eq(h.refreshes,before); eq(#initializeAuraMenu(h)._items,0)
    selectRule(h,rule)
    addon.db.CustomSpells2[1]=nil; before=h.refreshes
    button:Click(); eq(h.refreshes,before); eq(#initializeAuraMenu(h)._items,0)
    eq(addon.GetCurrentlyEditingSpell(),nil)
    addon.db=nil; button:Click(); eq(h.refreshes,before); eq(addon.GetCurrentlyEditingSpell(),nil)
end)

test('gui_preview_context_selection_reselection_back_hide_pages_and_group', function()
    local h=previewHarness(); local addon=h.addon
    context(h,1,nil,nil,nil)
    local rule=completeRule(addon); addon.db.CustomSpells2={rule}; addon.SpellCatalog.ByName.Polymorph={[118]=136071}
    addon.db.IconGroups[2]=addon.GetIconGroupDefaultOptions('Second Group')
    addon.ShowGUI(); local gui=addon.GUIFrame; context(h,1,1,nil,nil)
    local before=h.notifications; gui.CategoryButtons[7]:Click(); assert(h.notifications>before); context(h,1,7,nil,nil)
    before=h.notifications; local refresh=h.refreshes; selectRule(h,rule)
    eq(h.notifications,before+1); eq(h.refreshes,refresh); context(h,1,7,rule,118)
    before=h.notifications; refresh=h.refreshes; selectRule(h,rule)
    eq(h.notifications,before+1); eq(h.refreshes,refresh); context(h,1,7,rule,118)
    eq(h.lastContext[3],rule); eq(h.lastContext[4],118)
    before=h.notifications; refresh=h.refreshes
    local profile,spells,group=addon.db,addon.db.CustomSpells2,addon.db.IconGroups[1]
    context(h,1,7,rule,118); context(h,1,7,rule,118)
    eq(h.notifications,before); eq(h.refreshes,refresh)
    eq(addon.db,profile); eq(addon.db.CustomSpells2,spells); eq(addon.db.IconGroups[1],group)
    local editor=backButton(h)._parent._parent
    editor:Hide(); context(h,1,7,rule,118); eq(addon.GetCurrentlyEditingSpell(),nil)
    eq(addon.GetSelectedSpellForPreview(),rule); editor:Show(); context(h,1,7,rule,118)
    before=h.notifications; backButton(h):Click(); eq(h.notifications,before+1); context(h,1,7,nil,nil)
    selectRule(h,rule); context(h,1,7,rule,118)
    before=h.notifications; gui.CategoryButtons[6]:Click(); assert(h.notifications>before); context(h,1,6,nil,nil)
    gui.CategoryButtons[7]:Click(); context(h,1,7,nil,nil); selectRule(h,rule)
    before=h.notifications; gui:Hide(); assert(h.notifications>before); context(h,1,7,rule,118)
    eq(h.lastContext[2],7); eq(h.lastContext[3],rule); eq(addon.GetCurrentlyEditingSpell(),nil)
    refresh=h.refreshes; before=h.notifications
    local selectedRule,selectedID=addon.GetSelectedSpellForPreview(); eq(selectedRule,rule); eq(selectedID,118)
    eq(h.refreshes,refresh); eq(h.notifications,before)
    addon.ShowGUI(); context(h,1,7,rule,118); eq(addon.GetCurrentlyEditingSpell(),rule)
    local groups=findObject(h,function(o) return o._kind=='DropdownButton' and o._parent==gui and o._menu and o._menu.entries[2] end)
    before=h.notifications; groups._menu.entries[2].select(groups._menu.entries[2].data)
    assert(h.notifications>before); context(h,2,7,nil,nil)
    gui.CategoryButtons[9]:Click(); context(h,2,9,nil,nil)
    gui:Hide(); context(h,2,9,nil,nil)
    -- Optional notification remains safe if core has not supplied the interface yet.
    addon.OnPreviewContextChanged=nil; addon.ShowGUI(); gui.CategoryButtons[7]:Click(); selectRule(h,rule); backButton(h):Click(); gui:Hide()
end)

local function copyEntry(value)
    if type(value)~='table' then return value end
    local result={}; for key,item in pairs(value) do result[key]=copyEntry(item) end
    return result
end

local function equalEntry(actual,expected)
    eq(type(actual),type(expected))
    if type(expected)~='table' then eq(actual,expected); return end
    for key,value in pairs(expected) do equalEntry(actual[key],value) end
    for key in pairs(actual) do assert(expected[key]~=nil,'unexpected entry key: '..tostring(key)) end
end

local function spellSlider(h,key)
    local label=h.env.LibStub('AceLocale-3.0'):GetLocale('NameplateAuras_Forever')[key]
    return findObject(h,function(o) return o.slider and o.editbox and o.label and o.label:GetText()==label end)
end

test('gui_page7_float_first_selection_readonly_and_user_setters_write', function()
    for _,borderMode in ipairs({'BORDER_TYPE_BUILTIN','BORDER_TYPE_CUSTOM'}) do
        local h=previewHarness(); local addon=h.addon; local rule=completeRule(addon)
        rule.overrideSize=true; rule.iconSizeWidth=31.5; rule.iconSizeHeight=48.25
        rule.customBorderSize=2.5; rule.customBorderPath='Interface\\\\Icons\\\\Existing'
        rule.customBorderType=addon[borderMode]
        addon.db.CustomSpells2={rule}; addon.ShowGUI(); addon.GUIFrame.CategoryButtons[7]:Click()
        local saved=copyEntry(rule); local before=h.refreshes; local notifications=h.notifications
        selectRule(h,rule); equalEntry(rule,saved)
        eq(h.refreshes,before); eq(h.notifications,notifications+1)
        local width=spellSlider(h,'options:spells:icon-width')
        local height=spellSlider(h,'options:spells:icon-height')
        eq(width.editbox:GetText(),'31.5'); eq(height.editbox:GetText(),'48.25')
        local editor=backButton(h)._parent._parent
        local path=findObject(h,function(o)
            if o._kind~='EditBox' then return false end
            local parent=o._parent
            while parent and parent~=editor do parent=parent._parent end
            if parent~=editor then return false end
            for _,child in ipairs(h.objects) do
                if child._parent==o and child._kind=='FontString' and child:GetText()==h.env.LibStub('AceLocale-3.0'):GetLocale('NameplateAuras_Forever')['options:borders:border-file-path'] then return true end
            end
            return false
        end)
        local border=findObject(h,function(o) return o.slider and o.editbox and o._parent==path._parent end)
        if borderMode=='BORDER_TYPE_BUILTIN' then eq(border.slider:GetValue(),2.5) else eq(path:GetText(),saved.customBorderPath) end
        width.slider:SetValue(35.5); eq(rule.iconSizeWidth,36); eq(h.refreshes,before+1)
        height.editbox:SetText('52.25'); h.fire(height.editbox,'OnEnterPressed')
        eq(rule.iconSizeHeight,53); eq(h.refreshes,before+2)
        border.slider:SetValue(3.5); eq(rule.customBorderSize,4); eq(h.refreshes,before+3)
        path:HighlightText(0,#path:GetText()); path:Insert('Interface\\\\Icons\\\\Changed')
        eq(rule.customBorderPath,'Interface\\\\Icons\\\\Changed'); eq(h.refreshes,before+4)
        -- Exercise remaining rule overrides through real controls, not direct writes.
        local groupSaved=copyEntry(addon.db.IconGroups)
        local override=controlByText(h,'options:spells:override-size'); before=h.refreshes
        override:Click(); eq(rule.overrideSize,false); eq(h.refreshes,before+1)
        override:Click(); eq(rule.overrideSize,true); eq(h.refreshes,before+2)
        local borderToggle=findObject(h,function(o)
            return o.GetTriState and o.textEntries and o._parent==path._parent
        end)
        for _=1,3 do
            local mode=(borderToggle:GetTriState()+1)%3
            -- Builtin mode synchronizes the previously fractional slider to the committed integer.
            local sliderRefresh=mode==1 and border.slider:GetValue()~=rule.customBorderSize and 1 or 0
            before=h.refreshes; borderToggle:Click(); eq(borderToggle:GetTriState(),mode)
            eq(rule.customBorderType,mode==0 and addon.BORDER_TYPE_DISABLED or mode==1 and addon.BORDER_TYPE_BUILTIN or addon.BORDER_TYPE_CUSTOM)
            eq(h.refreshes,before+1+sliderRefresh)
        end
        -- Leave the real color control visible after testing the full cycle.
        if borderToggle:GetTriState()==0 then borderToggle:Click() end
        local color=findObject(h,function(o) return o.colorSwatch and o._parent==path._parent end)
        before=h.refreshes; color:Click(); h.env.ColorPickerFrame._color={.2,.4,.6,.8}; h.pickerInfo.swatchFunc()
        equalEntry(rule.customBorderColor,{.2,.4,.6,.8}); eq(h.refreshes,before+1)
        local ids=findObject(h,function(o)
            return o._kind=='EditBox' and o.text and o.text:GetText()==h.env.LibStub('AceLocale-3.0'):GetLocale('NameplateAuras_Forever')['Check spell ID']
        end)
        before=h.refreshes; ids:SetText('118, 119'); eq(h.refreshes,before)
        h.fire(ids,'OnEnterPressed'); equalEntry(rule.checkSpellID,{[118]=true,[119]=true}); eq(h.refreshes,before+1)
        before=h.refreshes; ids:SetText(''); h.fire(ids,'OnEnterPressed')
        eq(rule.checkSpellID,nil); eq(h.refreshes,before+1); equalEntry(addon.db.IconGroups,groupSaved)
        -- Hidden/profile-change callbacks still update labels, but cannot write missing rules.
        addon.GUIFrame:Hide(); before=h.refreshes; local persisted=copyEntry(rule)
        for _,missing in ipairs({'entry','list','db'}) do
            if missing=='entry' then addon.db.CustomSpells2[1]=nil
            elseif missing=='list' then addon.db.CustomSpells2=nil
            else addon.db=nil end
            width.slider:SetValue(width.slider:GetValue()+1)
            height.slider:SetValue(height.slider:GetValue()+1)
            border.slider:SetValue(border.slider:GetValue()+.1)
            path:SetText('hidden '..missing)
            eq(h.refreshes,before); equalEntry(rule,persisted)
            eq(width.editbox:GetText(),tostring(math.ceil(width.slider:GetValue())))
        end
    end
end)

test('gui_page7_permanent_glow_none_nil_defaults_only_on_click', function()
    for _,initial in ipairs({'none','nil','pixel'}) do
        local h=previewHarness(); local addon=h.addon; local rule=completeRule(addon)
        eq(addon.GLOW_TYPE_NONE,1)
        if initial=='none' then rule.glowType=addon.GLOW_TYPE_NONE
        elseif initial=='nil' then rule.glowType=nil
        else rule.glowType=addon.GLOW_TYPE_PIXEL end
        local original=rule.glowType; local saved=copyEntry(rule)
        addon.db.CustomSpells2={rule}; addon.ShowGUI(); addon.GUIFrame.CategoryButtons[7]:Click()
        local before=h.refreshes; local notifications=h.notifications
        selectRule(h,rule); equalEntry(rule,saved); eq(rule.glowType,original)
        eq(h.refreshes,before); eq(h.notifications,notifications+1)
        local glow=findObject(h,function(o) return o.GetTriState and o.textEntries and o.textEntries[1]=='永久发光：关闭' end)
        eq(glow:GetTriState(),0); glow:Click(); eq(glow:GetTriState(),2)
        eq(rule.showGlow,addon.GLOW_TIME_INFINITE)
        local expected=initial=='pixel' and addon.GLOW_TYPE_PIXEL or addon.GLOW_TYPE_AUTOUSE
        eq(rule.glowType,expected); eq(h.refreshes,before+1)
        eq(h.env['NAurasForeverGUI.Spell.dropdownGlowType']:IsVisible(),false)
        glow:Click(); eq(glow:GetTriState(),0); eq(rule.showGlow,nil)
        eq(rule.glowType,expected); eq(h.refreshes,before+2)
    end
end)

test('gui_preview_public_id_deterministic_constraints_and_unresolved', function()
    local h=previewHarness(); local addon=h.addon; local rule=completeRule(addon)
    addon.db.CustomSpells2={rule}; addon.SpellCatalog.ByName.Polymorph={[120]=136071,[118]=136071,[119]=136071}
    addon.ShowGUI(); addon.GUIFrame.CategoryButtons[7]:Click(); selectRule(h,rule)
    local ids=addon.SpellCatalog.ByName.Polymorph
    ids[0]=134400; ids[-1]=134400; ids[.5]=134400; ids['1']=134400; ids[math.huge]=134400
    context(h,1,7,rule,118)
    rule.checkSpellID={[120]=true,[119]=true,[118]=false,[1]=1,[0]=true,[-1]=true,[.5]=true,['2']=true,[math.huge]=true}
    local constraint=rule.checkSpellID; context(h,1,7,rule,119); eq(rule.checkSpellID,constraint); eq(constraint[118],false)
    rule.checkSpellID={[118]=false}; context(h,1,7,rule,nil)
    rule.checkSpellID={}; context(h,1,7,rule,nil)
    rule.checkSpellID=false; context(h,1,7,rule,nil)
    rule.checkSpellID=nil; context(h,1,7,rule,118)
    rule.spellName='Unresolved'; context(h,1,7,rule,nil)
    addon.db.CustomSpells2={}; context(h,1,7,nil,nil); eq(addon.GetCurrentlyEditingSpell(),nil)
    addon.db.CustomSpells2=nil; context(h,1,7,nil,nil)
    addon.db=nil; context(h,1,7,nil,nil)
end)

test('gui_rule_delete_batch_delete_and_stale_index_are_nil_safe', function()
    local h=previewHarness(); local addon=h.addon; local rule=completeRule(addon)
    addon.db.CustomSpells2={rule}; addon.ShowGUI(); local gui=addon.GUIFrame; gui.CategoryButtons[7]:Click(); selectRule(h,rule)
    local before=h.notifications; controlByText(h,'Delete spell'):Click()
    eq(addon.db.CustomSpells2[1],nil); assert(h.notifications>before); context(h,1,7,nil,nil)
    addon.db.CustomSpells2[1]=completeRule(addon,'Replacement'); context(h,1,7,nil,nil)
    gui.CategoryButtons[1]:Click(); gui.CategoryButtons[7]:Click()
    local replacement=addon.db.CustomSpells2[1]; selectRule(h,replacement)
    addon.db.CustomSpells2[1]=nil; context(h,1,7,nil,nil)
    backButton(h):Click(); context(h,1,7,nil,nil)
    addon.db.CustomSpells2={rule,completeRule(addon,'Other')}; gui.CategoryButtons[1]:Click(); gui.CategoryButtons[7]:Click()
    selectRule(h,rule); backButton(h):Click()
    controlByText(h,'options:spells:batch-actions'):Click()
    local delete=controlByText(h,'Delete all spells'); delete:Click(); eq(#addon.db.CustomSpells2,2)
    delete:Click(); eq(next(addon.db.CustomSpells2),nil); context(h,1,7,nil,nil)
end)

test('gui_second_group_add_rule_real_editbox_and_membership', function()
    local h=previewHarness(); local addon=h.addon
    addon.db.IconGroups[2]=addon.GetIconGroupDefaultOptions('Second Group'); addon.SpellCatalog.Ready=true
    local old=completeRule(addon,'Existing'); addon.db.CustomSpells2={old}
    addon.ShowGUI(); local gui=addon.GUIFrame
    local groups=findObject(h,function(o) return o._kind=='DropdownButton' and o._parent==gui and o._menu and o._menu.entries[2] end)
    groups._menu.entries[2].select(2); gui.CategoryButtons[7]:Click()
    local add=controlByText(h,'options:spells:add-import-new-spell'); eq(add:IsEnabled(),true)
    local edit=findObject(h,function(o)
        if o._kind~='EditBox' then return false end
        for _,p in ipairs(add._points) do if p[2]==o then return true end end
        return false
    end)
    edit:SetText('118'); add:Click()
    eq(#addon.db.CustomSpells2,2); local rule=addon.db.CustomSpells2[2]
    eq(rule.spellName,'Polymorph'); eq(rule.iconGroups[2],true); eq(rule.iconGroups[1],nil)
    eq(old.iconGroups[1],true); eq(old.iconGroups[2],nil); context(h,2,7,rule,118)
end)

test('gui_page9_blacklist_real_close_button_refreshes', function()
    local h=previewHarness(); local addon=h.addon; addon.SpellCatalog.Ready=true
    addon.db.IconGroups[1].Additions_DispellableSpells=true
    addon.db.IconGroups[1].Additions_DispellableSpells_Blacklist={Polymorph=true}
    addon.ShowGUI(); addon.GUIFrame.CategoryButtons[9]:Click()
    local button=controlByText(h,'options:apps:dispellable-spells:black-list-button')
    eq(button:IsEnabled(),true); button:Click()
    local menu=findObject(h,function(o) return o._parent==button and o.GetButtonByText and o:GetButtonByText('Polymorph') end)
    local item=menu:GetButtonByText('Polymorph'); assert(item.closeButton:IsVisible())
    local before=h.refreshes; item.closeButton:Click()
    eq(addon.db.IconGroups[1].Additions_DispellableSpells_Blacklist.Polymorph,nil); eq(h.refreshes,before+1)
end)

test('gui_test_button_documents_synthetic_preview_limits', function()
    local h=guiHarness(); h.addon.ShowGUI(); local button=assert(h.addon.GUIFrame.PreviewButton)
    eq(button:GetText(),'预览：关闭')
    for _,text in ipairs({'当前图标组','光环规则页','5 种减益','合成可驱散增益','使用增益边框色，不展示减益边框色',
        '公开目标','身份匹配、黑名单和真实光环数量无法通过合成预览验证','时间为合成','图标对齐方式',
        '混合尺寸示例','排序只在相同样式组内按时间','旧配置保留'}) do
        assert(button.LRDTooltipText:find(text,1,true),'missing tooltip contract: '..text)
    end
end)

local function tooltipContains(button,text,present)
    assert((button.LRDTooltipText:find(text,1,true)~=nil)==(present~=false),
        'tooltip contract '..(present==false and 'unexpected: ' or 'missing: ')..text)
end

test('gui_reopen_preserves_visible_rule_editor_and_no_overlay_on_other_pages', function()
    local h=previewHarness(); local addon=h.addon; local rule=completeRule(addon)
    rule.overrideSize=true; rule.iconSizeWidth=31; rule.iconSizeHeight=59
    addon.db.CustomSpells2={rule}; addon.ShowGUI(); local gui=addon.GUIFrame
    gui.CategoryButtons[7]:Click(); local menu=selectRule(h,rule); local editor=backButton(h)._parent._parent
    local saved=copyEntry(rule); eq(editor:IsVisible(),true); eq(menu:IsVisible(),false)
    for _=1,3 do
        gui:Hide(); eq(addon.GetCurrentlyEditingSpell(),nil); context(h,1,7,rule,118)
        addon.ShowGUI(); context(h,1,7,rule,118)
        eq(editor:IsVisible(),true); eq(menu:IsVisible(),false); equalEntry(rule,saved)
        eq(spellSlider(h,'options:spells:icon-width').editbox:GetText(),'31')
        tooltipContains(gui.PreviewButton,'光环规则：Polymorph（尺寸覆盖组设置）')
    end
    for _,page in ipairs({1,2,3,4,5,6,9,11,12}) do
        gui.CategoryButtons[page]:Click(); eq(menu:IsVisible(),false); eq(editor:IsVisible(),false)
        context(h,1,page,nil,nil)
    end
    gui.CategoryButtons[7]:Click(); eq(menu:IsVisible(),true); eq(editor:IsVisible(),false)
    context(h,1,7,nil,nil); equalEntry(rule,saved)
end)

test('gui_user_edits_automatically_refresh_preview_status_source', function()
    local h=previewHarness(); local addon=h.addon; local rule=completeRule(addon)
    addon.db.CustomSpells2={rule}; addon.ShowGUI(); local gui=addon.GUIFrame
    gui.CategoryButtons[7]:Click(); selectRule(h,rule)
    tooltipContains(gui.PreviewButton,'样式来源：光环规则：Polymorph')
    local override=controlByText(h,'options:spells:override-size')
    override:Click(); eq(rule.overrideSize,true); tooltipContains(gui.PreviewButton,'尺寸覆盖组设置')
    override:Click(); eq(rule.overrideSize,false); tooltipContains(gui.PreviewButton,'尺寸覆盖组设置',false)
    gui.CategoryButtons[6]:Click(); tooltipContains(gui.PreviewButton,'样式来源：增益与 5 种减益边框颜色')
    gui.CategoryButtons[2]:Click()
    local toggle=findObject(h,function(o) return o._kind=='CheckButton' and o.Text and o:GetText()=='预览：混合尺寸示例（不修改实际图标）' end)
    toggle:Click(); tooltipContains(gui.PreviewButton,'样式来源：混合尺寸示例，不代表实际图标尺寸')
    gui:Hide(); addon.ShowGUI(); tooltipContains(gui.PreviewButton,'样式来源：混合尺寸示例，不代表实际图标尺寸')
end)

local function groupMenu(h)
    return findObject(h,function(o) return o._kind=='DropdownButton' and o._parent==h.addon.GUIFrame and o._menu and o._menu.entries[2] end)
end

test('gui_hidden_rule_replacement_profile_reload_and_readonly_guards', function()
    local h=previewHarness(); local addon=h.addon; local rule=completeRule(addon)
    addon.db.CustomSpells2={rule}; addon.ShowGUI(); local gui=addon.GUIFrame
    gui.CategoryButtons[7]:Click(); selectRule(h,rule); gui:Hide()
    local saved=copyEntry(addon.db); local before,notifications=h.refreshes,h.notifications
    eq(addon.GetCurrentlyEditingSpell(),nil); eq(addon.GetSelectedSpellForPreview(),rule)
    context(h,1,7,rule,118); equalEntry(addon.db,saved)
    eq(h.refreshes,before); eq(h.notifications,notifications)
    local replacement=completeRule(addon,'Replacement'); addon.db.CustomSpells2[1]=replacement
    context(h,1,7,nil,nil); eq(addon.GetSelectedSpellForPreview(),nil)
    addon.ShowGUI(); context(h,1,7,nil,nil)
    selectRule(h,replacement); gui:Hide(); addon.GuiOnProfileChanged()
    context(h,1,7,nil,nil); eq(addon.GetSelectedSpellForPreview(),nil)
    addon.ShowGUI(); selectRule(h,replacement)
    addon.db.CustomSpells2=nil; context(h,1,7,nil,nil); eq(addon.GetSelectedSpellForPreview(),nil)
    addon.db=nil; context(h,1,7,nil,nil); eq(addon.GetSelectedSpellForPreview(),nil)
end)

test('gui_mixed_size_toggle_session_only_context_and_page_scope', function()
    local h=previewHarness(); local addon=h.addon; local rule=completeRule(addon)
    addon.db.CustomSpells2={rule}; addon.ShowGUI(); local gui=addon.GUIFrame
    gui.CategoryButtons[2]:Click()
    local toggle=findObject(h,function(o) return o._kind=='CheckButton' and o.Text and o:GetText()=='预览：混合尺寸示例（不修改实际图标）' end)
    eq(toggle:GetChecked(),false); eq(addon.PreviewMixedSizes,nil)
    local saved=copyEntry(addon.db); local before,notifications=h.refreshes,h.notifications
    toggle:Click(); eq(addon.PreviewMixedSizes,true); eq(toggle:GetChecked(),true)
    eq(h.refreshes,before); eq(h.notifications,notifications+1); equalEntry(addon.db,saved)
    context(h,1,2,nil,nil); addon.UpdatePreviewStatus()
    tooltipContains(gui.PreviewButton,'样式来源：混合尺寸示例，不代表实际图标尺寸')
    gui.CategoryButtons[7]:Click(); selectRule(h,rule); addon.UpdatePreviewStatus()
    context(h,1,7,rule,118); eq(addon.PreviewMixedSizes,true)
    tooltipContains(gui.PreviewButton,'样式来源：光环规则：Polymorph')
    tooltipContains(gui.PreviewButton,'样式来源：混合尺寸',false)
    gui.CategoryButtons[3]:Click(); addon.UpdatePreviewStatus(); context(h,1,3,nil,nil)
    tooltipContains(gui.PreviewButton,'样式来源：组默认外观')
    gui.CategoryButtons[2]:Click(); eq(toggle:GetChecked(),true)
    before,notifications=h.refreshes,h.notifications
    toggle:Click(); eq(addon.PreviewMixedSizes,false); eq(h.refreshes,before)
    eq(h.notifications,notifications+1); equalEntry(addon.db,saved)
    addon.UpdatePreviewStatus(); tooltipContains(gui.PreviewButton,'样式来源：组默认外观')
    -- A new GUI session never inherits the opt-in flag from SavedVariables.
    local fresh=previewHarness(); fresh.addon.db=copyEntry(addon.db); fresh.addon.ShowGUI()
    eq(fresh.addon.PreviewMixedSizes,nil)
end)

test('gui_preview_status_on_off_rule_override_and_target_prerequisites', function()
    local h=previewHarness(); local addon=h.addon; local rule=completeRule(addon)
    addon.db.CustomSpells2={rule}; addon.db.IconGroups[2]=addon.GetIconGroupDefaultOptions('Second Group')
    local active=false; addon.IsPreviewActive=function() return active end
    addon.ShowGUI(); local gui=addon.GUIFrame; local button=assert(gui.PreviewButton)
    local saved=copyEntry(addon.db); local before,notifications=h.refreshes,h.notifications
    for _,state in ipairs({true,false,true}) do
        active=state; addon.UpdatePreviewStatus(); eq(button:GetText(),state and '预览：开启' or '预览：关闭')
    end
    equalEntry(addon.db,saved); eq(h.refreshes,before); eq(h.notifications,notifications)
    gui.CategoryButtons[7]:Click(); selectRule(h,rule); addon.UpdatePreviewStatus()
    tooltipContains(button,'当前图标组：Test Group'); tooltipContains(button,'样式来源：光环规则：Polymorph')
    tooltipContains(button,'尺寸覆盖组设置',false); tooltipContains(button,'边框覆盖组设置',false)
    rule.overrideSize=true; rule.customBorderType=addon.BORDER_TYPE_CUSTOM; addon.UpdatePreviewStatus()
    tooltipContains(button,'光环规则：Polymorph（尺寸覆盖组设置）（边框覆盖组设置）')
    rule.overrideSize=false; rule.customBorderType=addon.BORDER_TYPE_DISABLED; addon.UpdatePreviewStatus()
    tooltipContains(button,'尺寸覆盖组设置',false); tooltipContains(button,'边框覆盖组设置',false)
    for _,text in ipairs({'目标缩放、透明度、层级仅在选中的姓名板生效','无目标透明度策略需取消目标',
        '身份匹配、黑名单和真实光环数量无法通过合成预览验证'}) do tooltipContains(button,text) end
    gui:Hide(); addon.UpdatePreviewStatus(); tooltipContains(button,'样式来源：光环规则：Polymorph')
    addon.ShowGUI(); groupMenu(h)._menu.entries[2].select(2); addon.UpdatePreviewStatus()
    tooltipContains(button,'当前图标组：Second Group'); tooltipContains(button,'样式来源：组默认外观')
    tooltipContains(button,'样式来源：法术规则',false)
    for _,spec in ipairs({{6,'样式来源：增益与 5 种减益边框颜色'},
        {9,'样式来源：驱散专用尺寸与永久发光（增益边框）'}}) do
        gui.CategoryButtons[spec[1]]:Click(); addon.UpdatePreviewStatus(); tooltipContains(button,spec[2])
    end
    active=false; addon.UpdatePreviewStatus(); eq(button:GetText(),'预览：关闭')
end)

local function visibleSlider(h,key)
    local label=h.env.LibStub('AceLocale-3.0'):GetLocale('NameplateAuras_Forever')[key]
    return findObject(h,function(o) return o.slider and o.editbox and o.label and o.label:GetText()==label and o:IsVisible() end)
end

local function modernMenu(h,key)
    local label=h.env.LibStub('AceLocale-3.0'):GetLocale('NameplateAuras_Forever')[key]
    return findObject(h,function(o)
        if o._kind~='DropdownButton' or not o._menu then return false end
        for _,child in ipairs(h.objects) do
            if child._parent==o and child._kind=='FontString' and child:GetText()==label then return true end
        end
        return false
    end)
end

local function selectLegacy(h,name,value)
    local menu=assert(h.env[name]); h.env.UIDropDownMenu_Initialize(menu,menu.initialize)
    for _,item in ipairs(menu._items) do
        if item.value==value then auraMenuButton(h,item):Click(); return end
    end
    error('legacy menu value missing: '..name)
end

local setterSpecs={
    {2,'slider','options:size-and-position:icon-width','DefaultIconSizeWidth',37.2,38},
    {2,'slider','options:size-and-position:icon-height','DefaultIconSizeHeight',51.2,52},
    {2,'slider','Space between icons','IconSpacing',9.2,10},
    {2,'slider','Icon X-coord offset','IconXOffset',-17.2,-17},
    {2,'slider','Icon Y-coord offset','IconYOffset',21.2,22},
    {2,'slider','options:size-and-position:icon-zoom','IconZoom',.234,.23},
    {2,'slider','options:size-and-position:scale-target','IconScaleTarget',2.34,2.3},
    {3,'slider','options:alpha:alpha','IconAlpha',.234,.23},
    {3,'slider','options:alpha:alpha-target','IconAlphaTarget',.674,.67},
    {4,'slider','Font scale','FontScale',1.74,1.7},
    {4,'slider','Font size','TimerTextSize',23.2,23},
    {4,'slider','X offset','TimerTextXOffset',12.2,12},
    {4,'slider','Y offset','TimerTextYOffset',-12.2,-12},
    {4,'slider','options:timer-text:min-duration-to-display-tenths-of-seconds','MinTimeToShowTenthsOfSeconds',3.24,3.2},
    {5,'slider','Font scale','StacksFontScale',1.84,1.8},
    {5,'slider','X offset','StacksTextXOffset',14.2,14},
    {5,'slider','Y offset','StacksTextYOffset',-14.2,-14},
    {6,'slider','Border thickness','BorderThickness',3.2,3},
    {9,'slider','options:spells:icon-width','DispelIconSizeWidth',39.2,40},
    {9,'slider','options:spells:icon-height','DispelIconSizeHeight',49.2,50},
    {2,'check','options:size-and-position:keep-aspect-ratio','KeepAspectRatio'},
    {2,'check','options:size-and-position:nameplate-is-parent','NameplateIsParent'},
    {2,'check','options:style-and-position:show-cooldown-swipe-edge','ShowCooldownSwipeEdge'},
    {3,'check','options:alpha:use-target-alpha-if-not-target-selected','UseTargetAlphaIfNotTargetSelected'},
    {4,'check','options:timer-text:scale-font-size','TimerTextUseRelativeScale'},
    {4,'check','options:timer-text:relative-color','TimerTextUseRelativeColor'},
    {4,'check','options:general:show-cooldown-text','ShowCooldownText'},
    {5,'check','options:general:show-stacks','ShowStacks'},
    {6,'check','Show border around debuff icons','ShowDebuffBorders'},
    {6,'check','Show border around buff icons','ShowBuffBorders'},
    {9,'check','options:apps:dispellable-spells','Additions_DispellableSpells'},
    {4,'color','< 5sec','TimerTextSoonToExpireColor'},
    {4,'color','< 1min','TimerTextUnderMinuteColor'},
    {4,'color','> 1min','TimerTextLongerColor'},
    {4,'color','0%','TimerTextColorZeroPercent'},
    {4,'color','100%','TimerTextColorHundredPercent'},
    {5,'color','Text color','StacksTextColor'},
    {6,'color','Magic','DebuffBordersMagicColor'},
    {6,'color','Curse','DebuffBordersCurseColor'},
    {6,'color','Disease','DebuffBordersDiseaseColor'},
    {6,'color','Poison','DebuffBordersPoisonColor'},
    {6,'color','Other','DebuffBordersOtherColor'},
    {6,'buffcolor','Show border around buff icons','BuffBordersColor'},
    {2,'menu','options:size-and-position:anchor-frame','AttachType','ATTACH_TYPE_HEALTHBAR'},
    {2,'menu','options:size-and-position:anchor-point-to-nameplate','FrameAnchorToNameplate',7,'TOPLEFT'},
    {2,'menu','options:size-and-position:anchor-point-of-frame','FrameAnchor',3,'BOTTOMRIGHT'},
    {2,'menu','options:size-and-position:icon-align','IconAnchor',2,'ICON_ALIGN_TOP_RIGHT'},
    {2,'menu','options:general:icon-grow-direction','IconGrowDirection',3,'ICON_GROW_DIRECTION_UP'},
    {2,'menu','Sort mode:','SortMode','AURA_SORT_MODE_ICONSIZE'},
    {2,'menu','options:size-and-position:target-strata','TargetStrata',4,'HIGH'},
    {2,'menu','options:size-and-position:non-target-strata','NonTargetStrata',2,'LOW'},
    {6,'legacy','NAurasForever.GUI.Border.dropdownBorderType','BorderType','BORDER_TYPE_CUSTOM'},
    {9,'legacy','NAurasForeverGUI.Dispel.dropdownGlowType','Additions_DispellableSpells_GlowType','GLOW_TYPE_PIXEL'},
}

local function exerciseSetters(groupIndex)
    local h=previewHarness(); local addon=h.addon
    addon.db.IconGroups[2]=addon.GetIconGroupDefaultOptions('Second Group'); addon.ShowGUI()
    if groupIndex==2 then groupMenu(h)._menu.entries[2].select(2) end
    local group=addon.db.IconGroups[groupIndex]; local other=addon.db.IconGroups[3-groupIndex]
    local untouched=copyEntry(other)
    for _,spec in ipairs(setterSpecs) do
        local page,kind,key,field=unpack(spec)
        -- Public mode switches make the actual controls visible before editing.
        group.ShowCooldownText=true; group.ShowStacks=true; group.NameplateIsParent=false
        group.Additions_DispellableSpells=true; group.BorderType=addon.BORDER_TYPE_BUILTIN
        group.TimerTextUseRelativeScale=key~='Font size'
        group.TimerTextUseRelativeColor=key=='0%' or key=='100%'
        addon.OnIconGroupChanged(); addon.GUIFrame.CategoryButtons[page]:Click()
        local before=h.refreshes; local expected=spec[6] or spec[5]
        local expectedGroup=copyEntry(group); local spellsSaved=copyEntry(addon.db.CustomSpells2)
        if type(expected)=='string' then expected=addon[expected] or expected end
        if kind=='slider' then
            local control=visibleSlider(h,key); assert(control.slider:GetValue()~=spec[5])
            control.slider:SetValue(spec[5]); eq(control.editbox:GetText(),tostring(expected))
        elseif kind=='check' then
            local control=controlByText(h,key); assert(control:IsVisible()); expected=not control:GetChecked(); control:Click()
        elseif kind=='color' or kind=='buffcolor' then
            local label=(key=='0%' or key=='100%') and key or h.env.LibStub('AceLocale-3.0'):GetLocale('NameplateAuras_Forever')[key]
            local control
            if kind=='buffcolor' then control=controlByText(h,key).ColorButton
            else control=findObject(h,function(o) return o.colorSwatch and o:GetText()==label and o:IsVisible() end) end
            assert(control:IsVisible()); control:Click(); expected={.21,.43,.65,.87}
            h.env.ColorPickerFrame._color=copyEntry(expected); h.pickerInfo.swatchFunc()
        elseif kind=='menu' then
            local menu=modernMenu(h,key); assert(menu:IsVisible())
            local value=type(spec[5])=='string' and addon[spec[5]] or spec[5]; local found=false
            for _,item in ipairs(menu._menu.entries) do
                if item.data==value then assert(item.enabled~=false); item.select(item.data); found=true; break end
            end
            assert(found,'modern menu value missing: '..key)
        else
            selectLegacy(h,key,addon[spec[5]])
        end
        equalEntry(group[field],expected); eq(h.refreshes,before+1)
        expectedGroup[field]=expected; equalEntry(group,expectedGroup)
        equalEntry(addon.db.CustomSpells2,spellsSaved)
        equalEntry(other,untouched); context(h,groupIndex,page,nil,nil)
    end
end

test('gui_visual_setters_table_driven_write_current_group_and_refresh', function() exerciseSetters(1) end)
test('gui_visual_setters_cross_group_write_second_not_first', function() exerciseSetters(2) end)

test('aceconfigdialog_real_parent_registration_and_wrong_parent_rejection', function()
    local h=harness(); local env=h.env
    env.CANCEL='Cancel'
    -- Load the entire unmodified AceConfigDialog chunk. Only its external
    -- AceGUI widget and registry dependencies are mocked, not AddToBlizOptions.
    local gui=env.LibStub:NewLibrary('AceGUI-3.0',1)
    gui.Create=function(_,kind)
        eq(kind,'BlizOptionsGroup')
        local group={frame=env.CreateFrame('Frame'),data={},callbacks={}}
        group.SetTitle=function(s,title) signature({'string'},title); s.title=title end
        group.SetUserData=function(s,key,value) signature({'string'},key); s.data[key]=value end
        group.SetCallback=function(s,event,fn) signature({'string','function'},event,fn); s.callbacks[event]=fn end
        group.SetName=function(s,id,parent) assert(type(id)=='string' or type(id)=='number'); s.frame.name=id; s.frame.parent=parent end
        return group
    end
    local reg=env.LibStub:NewLibrary('AceConfigRegistry-3.0',1)
    reg.RegisterCallback=function(target,event,method) signature({'table','string','string'},target,event,method); eq(event,'ConfigTableChange'); eq(type(target[method]),'function') end
    local categories,subcategories={},{}
    env.Settings={
        GetCategory=function(id) return categories[id] end,
        RegisterCanvasLayoutCategory=function(frame,name) signature({'table','string'},frame,name); local c={ID=name,frame=frame}; categories[name]=c; return c end,
        RegisterCanvasLayoutSubcategory=function(parent,frame,name) signature({'table','table','string'},parent,frame,name); local c={ID=name,frame=frame,parent=parent}; subcategories[#subcategories+1]=c; return c end,
        RegisterAddOnCategory=function(category) signature({'table'},category); eq(categories[category.ID],category) end,
    }
    h.load('src/consts.lua')
    h.load('libs/AceConfig-3.0/AceConfigDialog-3.0/AceConfigDialog-3.0.lua')
    local dialog=env.LibStub('AceConfigDialog-3.0')
    local frame,id=dialog:AddToBlizOptions('NameplateAuras_Forever',h.addon.DISPLAY_NAME)
    eq(id,h.addon.DISPLAY_NAME); eq(frame,categories[id].frame)
    local child=dialog:AddToBlizOptions('NameplateAuras_Forever.profiles','Profiles',h.addon.DISPLAY_NAME)
    eq(child,subcategories[1].frame); eq(subcategories[1].parent,categories[id])
    rejects(function() dialog:AddToBlizOptions('wrong.profiles','Profiles','NameplateAuras_Forever') end,'parent category')
end)

test('current_false_glow_import_rejects_before_real_gui_selection', function()
    local h=guiHarness(); local addon=h.addon
    local input={spellName='Polymorph',showGlow=false,enabledState=addon.CONST_SPELL_MODE_ALL,iconGroups={[1]=true}}
    local prepared,failure=addon.PrepareSpellImport(input)
    eq(prepared,nil); assert(type(failure)=='string'); eq(#addon.db.CustomSpells2,0)
    input.showGlow=nil; prepared=assert(addon.PrepareSpellImport(input))
    addon.db.CustomSpells2={prepared}; addon.ShowGUI(); addon.GUIFrame.CategoryButtons[7]:Click()
    local menu=findObject(h,function(o) return o.dataSource and o:GetButtonByText('Polymorph')~=nil end)
    menu:GetButtonByText('Polymorph'):Click()
    eq(addon.GetCurrentlyEditingSpell(),prepared)
end)
test('private_dropdown_library_cannot_replace_original_registration', function()
    local h=harness(); local stub=h.env.LibStub
    local original=stub:NewLibrary('LibRedDropdown-1.0',999)
    original.marker='original'
    local forever=stub('LibRedDropdown-Forever-1.0')
    assert(forever~=original); eq(stub('LibRedDropdown-1.0').marker,'original')
    h.load('libs/LibRedDropdown-1.0/LibRedDropdown-1.0.lua')
    eq(stub('LibRedDropdown-1.0').marker,'original')
    assert(forever.CreateColorPicker().texture._solid)
end)

local categoryKeys={'General','options:category:size-and-position','options:category:alpha','Timer text','Stack text',
    'Icon borders','Spells','options:category:interrupts','options:category:dispel','options:category:apps','options:category:icon-groups'}

local function chinese(text)
    -- Match UTF-8 CJK ideographs, not merely punctuation or a non-ASCII byte.
    return type(text)=='string' and text:find('[\228-\233][\128-\191][\128-\191]')~=nil
end

local function captureLocale(locale)
    local captured={}
    local ace={NewLocale=function(_,name,requested,default)
        eq(name,'NameplateAuras_Forever'); eq(requested,locale)
        eq(default,locale=='enUS' and true or nil); return captured
    end}
    local env={LibStub=function(name) eq(name,'AceLocale-3.0'); return ace end}
    local chunk=assert(loadfile(root..'/locales/'..locale..'.lua'))
    setfenv(chunk,env); chunk()
    return captured
end

local function formatTokens(text)
    local tokens={}; local pos=1
    while pos<=#text do
        local first=text:find('%',pos,true)
        if not first then break end
        if text:sub(first,first+1)=='%%' then tokens[#tokens+1]='%%'; pos=first+2
        else
            local token=text:sub(first):match('^%%[-+ #0]*%d*%.?%d*[cdiouxXeEfgGqs]')
            if token then tokens[#tokens+1]=token; pos=first+#token else pos=first+1 end
        end
    end
    return table.concat(tokens,'\n')
end

local function validateDictionary(default,translated)
    -- This ID-only format decorates a client-provided name; it is not prose.
    local technical={['options:spells:title-with-id']=true,['0%']=true,['100%']=true}
    local count=0
    for key,value in pairs(default) do
        count=count+1; local translation=rawget(translated,key)
        assert(type(translation)=='string' and translation:find('%S'), 'missing explicit translation: '..key)
        assert(not translation:find('Translation missing',1,true), 'missing translation warning: '..key)
        assert(chinese(translation) or technical[key], 'non-Chinese translation: '..key)
        eq(formatTokens(translation),formatTokens(value))
        for token in value:gmatch('#[a-z]+:?') do
            assert(translation:find(token,1,true), 'lost search token: '..token)
        end
        for escape in value:gmatch('|c%x%x%x%x%x%x%x%x') do assert(translation:find(escape,1,true), 'lost color escape') end
        if value:find('|r',1,true) then assert(translation:find('|r',1,true), 'lost color reset') end
    end
    assert(count>200,'unexpectedly empty locale capture')
    local seen={}
    for _,key in ipairs(categoryKeys) do assert(not seen[translated[key]], 'duplicate category: '..key); seen[translated[key]]=true end
end

test('locale_dictionary_explicit_coverage_format_tokens_and_negative_controls', function()
    local default,translated=captureLocale('enUS'),captureLocale('zhCN')
    validateDictionary(default,translated)
    for key,expected in pairs({Buff='增益',Debuff='减益',['Stack text']='层数文字',['Timer text']='倒计时文字',
        Profiles='配置方案',Spells='光环规则',['Frame strata']='框架层级',['options:size-and-position:icon-zoom']='材质裁切'}) do
        eq(translated[key],expected)
    end
    for _,key in ipairs({'options:general:only-show-my-auras','options:general:only-show-my-auras:tooltip',
        'options:preview:source-own','options:preview:source-rules','Always show auras cast by myself',
        'options:general:always-show-my-auras:tooltip','options:general:always-show-my-auras-blacklist:button:tooltip'}) do
        assert(type(rawget(default,key))=='string','missing own-aura default key: '..key)
        assert(chinese(rawget(translated,key)),'missing explicit own-aura Chinese translation: '..key)
        local missing=copyEntry(translated); missing[key]=nil; setmetatable(missing,{__index=default})
        rejects(function() validateDictionary(default,missing) end,'missing explicit translation: '..key)
    end
    eq(translated['options:general:only-show-my-auras'],'仅显示自己施放的光环')
    eq(translated['Always show auras cast by myself'],'补充显示自己施放的光环')
    assert(translated['Display auras on player\'s nameplate']:find('姓名板',1,true))
    local removed=copyEntry(translated); removed['General']=nil
    -- AceLocale fallback would still yield English; raw capture must reject it.
    setmetatable(removed,{__index=default})
    rejects(function() validateDictionary(default,removed) end,'missing explicit translation: General')
    local changed=copyEntry(translated)
    changed['options:auras:enabled-state:tooltip']=changed['options:auras:enabled-state:tooltip']:gsub('%%s','%%d',1)
    rejects(function() validateDictionary(default,changed) end,'expected')
    local english=copyEntry(translated); english.General='General'
    rejects(function() validateDictionary(default,english) end,'non-Chinese translation: General')
    local blank=copyEntry(translated); blank.General=' '
    rejects(function() validateDictionary(default,blank) end,'missing explicit translation: General')
    local duplicate=copyEntry(translated); duplicate['Stack text']=duplicate['Timer text']
    rejects(function() validateDictionary(default,duplicate) end,'duplicate category: Stack text')
    local lostToken=copyEntry(translated)
    lostToken['options:spells:filter-tooltip']=lostToken['options:spells:filter-tooltip']:gsub('#enabled','已启用')
    rejects(function() validateDictionary(default,lostToken) end,'lost search token: #enabled')
    eq(formatTokens('#group:2 |cffeda55fcolor|r'),'')
    eq(formatTokens('100% and no formatter'),'')
    eq(formatTokens('value %s: %d%%'),'%s\n%d\n%%')
    eq(formatTokens(default['options:auras:enabled-state:tooltip']),'%s\n%s\n%s')
    eq(formatTokens(translated['options:auras:enabled-state:tooltip']),'%s\n%s\n%s')
    local formatted=string.format(translated['options:auras:enabled-state:tooltip'],'禁用','仅自己','全部')
    for _,label in ipairs({'禁用','仅自己','全部'}) do assert(formatted:find(label,1,true)) end
    assert(string.format(translated['options:size-and-position:attach-to-addon-frame'],'Plater'):find('[Plater]',1,true))
    for _,locale in ipairs({'enUS','zhCN'}) do
        local h=guiHarness(locale); eq(h.locale,locale); eq(h.env.GetLocale(),locale)
        local actual=h.env.LibStub('AceLocale-3.0'):GetLocale('NameplateAuras_Forever')
        for key,value in pairs(locale=='zhCN' and translated or default) do eq(actual[key],value) end
        h.addon.ShowGUI(); eq(h.addon.GUIFrame.CategoryButtons[1].text:GetText(),actual.General)
    end
end)

local function localeTable(h) return h.env.LibStub('AceLocale-3.0'):GetLocale('NameplateAuras_Forever') end
local function searchPlaceholder(h,menu)
    return findObject(h,function(o) return o._kind=='FontString' and o._parent==menu.searchBox and o:GetText()~='' end)
end

test('gui_locale_categories_menu_titles_strata_search_and_storage_identifiers', function()
    local h=previewHarness(); local addon=h.addon; local L=localeTable(h)
    local buff=completeRule(addon,'Client Buff'); buff.auraType=addon.AURA_TYPE_BUFF
    local debuff=completeRule(addon,'Client Debuff'); debuff.auraType=addon.AURA_TYPE_DEBUFF; debuff.enabledState=addon.CONST_SPELL_MODE_DISABLED
    addon.db.CustomSpells2={buff,debuff}; addon.ShowGUI(); local gui=addon.GUIFrame
    local saved=copyEntry(addon.db)
    for i,key in ipairs(categoryKeys) do
        eq(gui.CategoryButtons[i].text:GetText(),L[key]); gui.CategoryButtons[i]:Click()
        assert(#gui.Categories[i]>0)
        if h.locale=='zhCN' then assert(chinese(gui.CategoryButtons[i].text:GetText())) end
    end
    eq(gui.CategoryButtons[12].text:GetText(),'Forever 限制'); gui.CategoryButtons[12]:Click()
    assert(#gui.Categories[12]>0); eq(controlByText(h,'Close'):GetText(),L.Close)
    local titleCount=0
    for _,o in ipairs(h.objects) do
        if o._menu and o._menu.title then
            titleCount=titleCount+1
            if h.locale=='zhCN' then assert(chinese(o._menu.title), 'English menu title: '..o._menu.title) end
        end
    end
    assert(titleCount>=8)
    gui.CategoryButtons[2]:Click()
    for _,key in ipairs({'options:size-and-position:target-strata','options:size-and-position:non-target-strata'}) do
        local menu=modernMenu(h,key); eq(menu._menu.title,L['Frame strata']); eq(#menu._menu.entries,8)
        for _,item in ipairs(menu._menu.entries) do
            eq(type(item.data),'number'); local enum=({'BACKGROUND','LOW','MEDIUM','HIGH','DIALOG','FULLSCREEN','FULLSCREEN_DIALOG','TOOLTIP'})[item.data]
            eq(item.text,L['strata:'..enum]); if h.locale=='zhCN' then assert(chinese(item.text)) end
        end
        menu._menu.entries[4].select(4)
        eq(addon.db.IconGroups[1][key:find('non-target',1,true) and 'NonTargetStrata' or 'TargetStrata'],'HIGH')
    end
    addon.db.IconGroups=saved.IconGroups
    gui.CategoryButtons[7]:Click(); local menu=selectRule(h,buff); backButton(h):Click()
    local cases={{'#group:1',2},{'#enabled',1,buff},{'#disabled',1,debuff},{'#buff',1,buff},{'#debuff',1,debuff}}
    for _,case in ipairs(cases) do
        menu.searchBox:SetText(case[1]); eq(menu:GetSearchText(),case[1]); eq(#menu.list,case[2])
        if case[3] then eq(menu.list[1].info,case[3]) end
    end
    menu.searchBox:SetText(''); equalEntry(addon.db,saved)
    for _,constructor in ipairs({'CreateDropdownMenu','CreateDropdownMenu2'}) do
        local dropdown=h.lib[constructor](); eq(searchPlaceholder(h,dropdown):GetText(),L['options:common:search'])
        if h.locale=='zhCN' then assert(chinese(searchPlaceholder(h,dropdown):GetText())) end
    end
    local editor=h.lib.CreateLuaEditor(); eq(editor:GetHeaderText(),L['options:common:editor'])
    eq(editor.CloseButton:GetText(),h.env.CLOSE); eq(editor.ApplyButton:GetText(),h.env.ACCEPT)
    local color=h.lib.CreateColorPicker(); color:SetColor(.2,.4,.6,.8)
    eq(color.LRDTooltipText,string.format(L['options:common:rgba'],51,102,153,204))
    if h.locale=='zhCN' then assert(chinese(color.LRDTooltipText)) end
    eq(addon.GetIconGroupDefaultOptions().IconGroupName,L['Icon group']..' test')
    eq(addon.GetIconGroupDefaultOptions('User Group').IconGroupName,'User Group')
    eq(addon.db.CustomSpells2[1].spellName,'Client Buff'); eq(addon.db.CustomSpells2[2].spellName,'Client Debuff')
    eq(addon.db.IconGroups[1].Font,'NAurasForever_TeenBold'); eq(addon.db.IconGroups[1].StacksFont,'NAurasForever_TeenBold')
    eq(h.env.SLASH_NAMEPLATEAURASFOREVER1,nil) -- Core initialization is deliberately outside this GUI harness.
end)

test('private_dropdown_uninjected_constructors_keep_english_fallback', function()
    local h=harness(); eq(h.lib.Localization,nil)
    for _,constructor in ipairs({'CreateDropdownMenu','CreateDropdownMenu2'}) do
        eq(searchPlaceholder(h,h.lib[constructor]()):GetText(),'Click to search...')
    end
    eq(h.lib.CreateLuaEditor():GetHeaderText(),'LuaEditor')
    local picker=h.lib.CreateColorPicker(); picker:SetColor(.2,.4,.6,.8)
    eq(picker.LRDTooltipText,'R: 51, G: 102, B: 153, A: 204')
    eq(select(2,h.env.LibStub:GetLibrary('LibRedDropdown-Forever-1.0')),25)
end)

local function serialization(h)
    local serialize,deflate=h.env.LibStub('LibSerialize'),h.env.LibStub('LibDeflate')
    local function encode(value) return deflate:EncodeForPrint(deflate:CompressDeflate(serialize:Serialize(value))) end
    local function decode(text)
        local ok,value=serialize:Deserialize(assert(deflate:DecompressDeflate(assert(deflate:DecodeForPrint(text)))))
        assert(ok); return value
    end
    return encode,decode,deflate
end

test('gui_localized_rule_title_source_dropdown_and_serialized_name_are_readonly', function()
    local h=previewHarness(); local addon=h.addon; local L=localeTable(h)
    local encode,decode=serialization(h)
    local unresolved=completeRule(addon,'Unknown spell #999999'); unresolved.unresolvedSpellID=999999
    local resolved=completeRule(addon,'Polymorph'); resolved.checkSpellID={[118]=true}
    addon.db.CustomSpells2={unresolved,resolved}; local saved=copyEntry(addon.db)
    addon.ShowGUI(); addon.GUIFrame.CategoryButtons[7]:Click()
    local menu=selectRule(h,unresolved); local display=string.format(L['Unknown spell #%s'],'999999')
    assert(menu:GetButtonByText(display)); eq(addon.GetSpellDisplayName(unresolved),display)
    local title=findObject(h,function(o) return o.SetSpell and o._parent==backButton(h)._parent._parent end)
    findObject(h,function(o) return o._parent==title and o._kind=='FontString' and o:GetText()==display end)
    tooltipContains(addon.GUIFrame.PreviewButton,'样式来源：光环规则：'..display)
    eq(unresolved.spellName,'Unknown spell #999999'); eq(unresolved.unresolvedSpellID,999999)
    equalEntry(addon.db,saved); equalEntry(decode(encode(addon.db)),saved)
    backButton(h):Click(); selectRule(h,resolved)
    local clientTitle=string.format(L['options:spells:title-with-id'],'Polymorph','118')
    findObject(h,function(o) return o._parent==title and o._kind=='FontString' and o:GetText()==clientTitle end)
    tooltipContains(addon.GUIFrame.PreviewButton,'样式来源：光环规则：Polymorph')
    eq(resolved.spellName,'Polymorph'); equalEntry(addon.db,saved)
    equalEntry(decode(encode(addon.db)),saved)
    controlByText(h,'options:spells:export-spell'):Click()
    local editor=findObject(h,function(o) return o.GetHeaderText and o:IsVisible() and o:GetHeaderText()==L['options:spells:export-spell'] end)
    equalEntry(decode(editor:GetText()),resolved); eq(editor.ApplyButton:IsShown(),false)
end)

test('gui_profile_export_import_headers_real_serialization_and_three_failure_messages', function()
    local h=guiHarness(); local addon=h.addon; local L=localeTable(h)
    local encode,decode,deflate=serialization(h); addon.ShowGUI()
    local original=addon.db; local saved=copyEntry(original)
    controlByText(h,'options:general:export-profile'):Click()
    local editor=findObject(h,function(o) return o.GetHeaderText and o:IsVisible() and o:GetHeaderText()==L['options:general:export-profile'] end)
    equalEntry(decode(editor:GetText()),saved); eq(editor.ApplyButton:IsShown(),false)
    local importedCalls=0
    -- Only the uninitialized core commit seam is mocked. Decode/decompress,
    -- Deserialize and PrepareProfileImport remain the real embedded functions.
    addon.ImportProfile=function(profile)
        importedCalls=importedCalls+1
        local candidate,failure=addon.PrepareProfileImport(profile)
        if not candidate then return false,failure end
        return true
    end
    local inputs={{'!', 'Import data decoding error'},
        {deflate:EncodeForPrint('not a deflate stream'),'Import data decompressing error'},
        {deflate:EncodeForPrint(deflate:CompressDeflate('not serialized')),'Import data deserialization error'}}
    for _,case in ipairs(inputs) do
        controlByText(h,'options:general:import-profile'):Click()
        eq(editor:GetHeaderText(),L['options:general:import-profile']); eq(editor.ApplyButton:IsShown(),true)
        editor.EditBox:Insert(case[1]); assert(editor.ApplyButton:IsEnabled()); h.popup=nil
        editor.ApplyButton:Click(); eq(h.popup,'NAURAS_FOREVER_MSG')
        eq(h.env.StaticPopupDialogs[h.popup].text,L[case[2]])
        if h.locale=='zhCN' then assert(chinese(h.env.StaticPopupDialogs[h.popup].text)) end
        eq(importedCalls,0); eq(addon.db,original); equalEntry(original,saved)
    end
    -- Exercise the genuine shape validator through the GUI seam, not a fake PrepareImport.
    controlByText(h,'options:general:import-profile'):Click(); editor.EditBox:Insert(encode({DBVersion=999999}))
    editor.ApplyButton:Click(); eq(importedCalls,1); eq(h.popup,'NAURAS_FOREVER_MSG')
    local _,failure=addon.PrepareProfileImport({DBVersion=999999})
    eq(h.env.StaticPopupDialogs[h.popup].text,failure); eq(addon.db,original); equalEntry(original,saved)
end)

test('profiles_real_embedded_acedboptions_shallow_copy_identity_and_behavior', function()
    local h=guiHarness(); local env,addon=h.env,h.addon; local L=localeTable(h)
    env.UnitClass=function(unit) eq(unit,'player'); return 'Priest','PRIEST',5 end
    env.NORMAL_FONT_COLOR_CODE='|cffffd100'; env.FONT_COLOR_CODE_CLOSE='|r'
    h.load('libs/AceDBOptions-3.0/AceDBOptions-3.0.lua')
    local library=env.LibStub('AceDBOptions-3.0')
    local function database()
        local db={keys={char='Tester - Realm',realm='Realm',class='PRIEST'},profiles={Default={},Existing={}},current='Default',calls={}}
        db.GetCurrentProfile=function(self) return self.current end
        db.GetProfiles=function(self,out) env.wipe(out); for name in pairs(self.profiles) do out[#out+1]=name end; return out end
        db.SetProfile=function(self,value) signature({'string'},value); self.current=value; self.profiles[value]=self.profiles[value] or {}; self.calls.set=value end
        db.ResetProfile=function(self) self.calls.reset=(self.calls.reset or 0)+1 end
        db.CopyProfile=function(self,value) assert(self.profiles[value]); self.calls.copy=value end
        db.DeleteProfile=function(self,value) assert(value~=self.current); assert(self.profiles[value]); self.profiles[value]=nil; self.calls.delete=value end
        return db
    end
    local db=database(); local shared=library:GetOptionsTable(db); local snapshot=copyEntry(shared.args)
    local sharedName,sharedDesc,sharedCurrent=shared.name,shared.desc,shared.args.current.name
    local other=library:GetOptionsTable(database()); eq(other.args,shared.args)
    local tree=addon.GetProfileOptions(db)
    local localizedFields={
        desc={name='profiles:intro'},descreset={name='profiles:reset-description'},
        reset={name='profiles:reset',desc='profiles:reset-tooltip'},
        choosedesc={name='profiles:choose-description'},new={name='profiles:new',desc='profiles:new-tooltip'},
        choose={name='profiles:choose',desc='profiles:choose-tooltip'},copydesc={name='profiles:copy-description'},
        copyfrom={name='profiles:copy',desc='profiles:copy-tooltip'},deldesc={name='profiles:delete-description'},
        delete={name='profiles:delete',desc='profiles:delete-tooltip',confirmText='profiles:delete-confirm'},
    }
    if h.locale=='zhCN' then
        for key,fields in pairs(localizedFields) do
            for field,localeKey in pairs(fields) do
                local actual=tree.args[key][field]
                eq(actual:match('^%s*(.-)%s*$'),L[localeKey])
            end
        end
    end
    eq(tree.handler,shared.handler); eq(tree.handler.db,db); eq(library.optionTables[db],shared)
    if h.locale=='zhCN' then
        assert(tree~=shared and tree.args~=shared.args); eq(tree.name,'配置方案'); eq(tree.desc,L['profiles:manage'])
        eq(tree.args.current.name({handler=tree.handler}),string.format(L['profiles:current'],'|cffffd100Default|r'))
    else eq(tree,shared); eq(tree.args,shared.args) end
    for key,source in pairs(shared.args) do
        local target=tree.args[key]
        if h.locale=='zhCN' then assert(target~=source,'option was not copied: '..key) end
        for field,value in pairs(source) do
            if field~='name' and field~='desc' and field~='confirmText' then eq(target[field],value) end
        end
        for _,field in ipairs({'func','set','get','values','handler','arg','confirm','disabled'}) do eq(target[field],source[field]) end
        if h.locale=='zhCN' then
            for _,field in ipairs({'name','desc','confirmText'}) do
                local text=target[field]
                if type(text)=='function' then text=text({handler=tree.handler}) end
                if text then assert(chinese(text),'English profile label: '..key..'.'..field)
                    assert(not text:find('配置文件',1,true),'old profile terminology: '..key) end
            end
        end
    end
    equalEntry(shared.args,snapshot); eq(shared.name,sharedName); eq(shared.desc,sharedDesc); eq(shared.args.current.name,sharedCurrent)
    local handler=tree.handler
    local function invoke(key,field,value)
        local option=tree.args[key]; local info={handler=handler,arg=option.arg}
        return handler[assert(option[field])](handler,info,value)
    end
    eq(invoke('choose','get'),'Default')
    local profiles=invoke('choose','values'); assert(profiles.Default); eq(profiles.Existing,'Existing')
    -- Default's storage key and current profile name must stay literal, even
    -- though AceDBOptions itself supplies a localized menu display alias.
    eq(db.current,'Default'); eq(profiles.Default,h.locale=='zhCN' and '默认' or 'Default')
    eq(tree.args.current.name({handler=handler}):find('|cffffd100Default|r',1,true)~=nil,true)
    invoke('new','set','User Profile'); eq(db.current,'User Profile'); eq(db.calls.set,'User Profile')
    invoke('reset','func'); eq(db.calls.reset,1)
    invoke('copyfrom','set','Existing'); eq(db.calls.copy,'Existing')
    local inactive=invoke('delete','values'); eq(inactive['User Profile'],nil); eq(inactive.Existing,'Existing')
    eq(invoke('delete','disabled'),false); invoke('delete','set','Existing'); eq(db.calls.delete,'Existing')
    local again=addon.GetProfileOptions(db); eq(again.handler,handler)
    eq(shared.args.current.name,sharedCurrent); equalEntry(shared.args,snapshot); eq(other.args,shared.args)
end)

test('gui_own_only_general_discovery_setters_and_group_isolation', function()
    local h=previewHarness(); local addon=h.addon; local L=localeTable(h)
    local group=addon.db.IconGroups[1]; eq(type(group.OnlyShowMyAuras),'boolean'); eq(group.OnlyShowMyAuras,false)
    addon.db.IconGroups[2]=addon.GetIconGroupDefaultOptions('Second Group')
    local all,mine,disabled=completeRule(addon),completeRule(addon,'Mine'),completeRule(addon,'Disabled')
    mine.enabledState=addon.CONST_SPELL_MODE_MYAURAS; disabled.enabledState=addon.CONST_SPELL_MODE_DISABLED
    all.iconSizeWidth=31.5; mine.customBorderSize=2.5
    addon.db.CustomSpells2={all,mine,disabled}; addon.ShowGUI(); local gui=addon.GUIFrame
    local only=controlByText(h,'options:general:only-show-my-auras')
    local always=controlByText(h,'Always show auras cast by myself')
    local player=controlByText(h,"Display auras on player's nameplate")
    eq(only._kind,'CheckButton'); eq(only:IsVisible(),true); eq(only:GetChecked(),false)
    eq(only:GetText(),L['options:general:only-show-my-auras']); assert(only:GetText()~=always:GetText())
    eq(only._points[1][2],player); eq(only._points[1][3],'BOTTOMLEFT')
    eq(always._points[1][2],only); eq(always._points[1][3],'BOTTOMLEFT')
    local order={}; for i,o in ipairs(gui.Categories[1]) do order[o]=i end
    eq(order[only],order[player]+1); eq(order[always],order[only]+1)
    -- This harness never initializes core preview resources. Reject restarts at the GUI seam.
    addon.SwitchTestMode=function() error('configuration must not restart preview') end
    local rulesSaved=copyEntry(addon.db.CustomSpells2)
    for _,index in ipairs({1,2}) do
        if index==2 then groupMenu(h)._menu.entries[2].select(2) end
        local current=addon.db.IconGroups[index]; local otherSaved=copyEntry(addon.db.IconGroups[3-index])
        for _,button in ipairs({only,always,only,always}) do
            local expected=copyEntry(current); local field=button==only and 'OnlyShowMyAuras' or 'AlwaysShowMyAuras'
            expected[field]=not button:GetChecked(); local before=h.refreshes
            button:Click(); eq(h.refreshes,before+1); eq(type(current[field]),'boolean')
            eq(button:GetChecked(),current[field]); equalEntry(current,expected)
            equalEntry(addon.db.IconGroups[3-index],otherSaved); equalEntry(addon.db.CustomSpells2,rulesSaved)
            context(h,index,1,nil,nil)
        end
    end
    gui.CategoryButtons[2]:Click(); eq(only:IsVisible(),false)
    gui.CategoryButtons[1]:Click(); eq(only:IsVisible(),true)
    eq(controlByText(h,'options:general:only-show-my-auras'),only)
end)

test('gui_own_only_readback_reuses_checkbox_without_writes_or_rounding', function()
    local h=previewHarness(); local addon=h.addon
    addon.db.IconGroups[2]=addon.GetIconGroupDefaultOptions('Second Group')
    local rule=completeRule(addon); rule.iconSizeWidth=31.5; rule.iconSizeHeight=48.25; rule.customBorderSize=2.5
    addon.db.CustomSpells2={rule}; addon.ShowGUI(); local gui=addon.GUIFrame
    local only=controlByText(h,'options:general:only-show-my-auras')
    local handler
    for _,fn in ipairs(gui.OnDBChangedHandlers) do
        local i=1
        while true do
            local name,value=debug.getupvalue(fn,i); if not name then break end
            if value==only then assert(not handler,'duplicate own-only readback'); handler=fn end
            i=i+1
        end
    end
    assert(handler,'own-only readback missing')
    for _,value in ipairs({true,false,true}) do
        addon.db.IconGroups[1].OnlyShowMyAuras=value
        local saved=copyEntry(addon.db); local before,notifications=h.refreshes,h.notifications
        handler(); handler(); eq(only:GetChecked(),value); equalEntry(addon.db,saved)
        eq(h.refreshes,before); eq(h.notifications,notifications)
        before=h.refreshes; addon.OnIconGroupChanged()
        eq(only:GetChecked(),value); equalEntry(addon.db,saved); eq(h.refreshes,before+1)
        eq(controlByText(h,'options:general:only-show-my-auras'),only)
    end
    addon.db.IconGroups[2].OnlyShowMyAuras=false
    groupMenu(h)._menu.entries[2].select(2); eq(only:GetChecked(),false); context(h,2,1,nil,nil)
    groupMenu(h)._menu.entries[1].select(1); eq(only:GetChecked(),true)
    groupMenu(h)._menu.entries[2].select(2)
    -- Profile UI reset is exercised directly; no AceDB/core initialization or migration claim.
    for _,value in ipairs({true,false}) do
        local profile={CustomSpells2={copyEntry(rule)},IconGroups={addon.GetIconGroupDefaultOptions('Replacement')}}
        profile.IconGroups[1].OnlyShowMyAuras=value; addon.db=profile
        local saved=copyEntry(profile); local before=h.refreshes
        addon.GuiOnProfileChanged(); context(h,1,1,nil,nil); eq(only:GetChecked(),value)
        eq(controlByText(h,'options:general:only-show-my-auras'),only)
        equalEntry(profile,saved); eq(h.refreshes,before+1)
    end
    local count=0; local L=localeTable(h)
    for _,o in ipairs(h.objects) do
        if o._kind=='CheckButton' and o.Text and o:GetText()==L['options:general:only-show-my-auras'] then count=count+1 end
    end
    eq(count,1)
end)

test('gui_own_only_localized_tooltips_and_synthetic_source_boundary', function()
    local h=guiHarness(); local addon=h.addon; local L=localeTable(h); addon.ShowGUI()
    local only=controlByText(h,'options:general:only-show-my-auras')
    local always=controlByText(h,'Always show auras cast by myself')
    eq(only.LRDTooltipText,L['options:general:only-show-my-auras:tooltip'])
    eq(always.LRDTooltipText,L['options:general:always-show-my-auras:tooltip'])
    local blacklist=controlByText(h,'options:general:always-show-my-auras-blacklist:button')
    eq(blacklist.LRDTooltipText,L['options:general:always-show-my-auras-blacklist:button:tooltip'])
    local fragments=h.locale=='zhCN' and {'宠物','载具','驱散/偷取','当前图标组','不自动添加','全部已启用规则','补充显示'}
        or {'pet','vehicle','dispel/steal','current icon group','does not add','all enabled rules','supplements','PLAYER'}
    for _,text in ipairs(fragments) do tooltipContains(only,text) end
    for _,text in ipairs(h.locale=='zhCN' and {'补充显示','不排除其他玩家'} or {'unlisted','does not exclude other players'}) do
        assert((always:GetText()..always.LRDTooltipText):find(text,1,true),'supplement terminology missing: '..text)
    end
    -- The existing synthetic-tooltip assertions remain intact; add the source boundary.
    tooltipContains(addon.GUIFrame.PreviewButton,'来源、身份匹配、黑名单和真实光环数量无法通过合成预览验证')
end)

test('gui_own_only_effective_preview_source_and_rule_tristate_contract', function()
    local h=previewHarness(); local addon=h.addon; local L=localeTable(h)
    local group=addon.db.IconGroups[1]; addon.db.IconGroups[2]=addon.GetIconGroupDefaultOptions('Second Group')
    local rule=completeRule(addon); rule.iconSizeWidth=31.5; rule.customBorderSize=2.5
    addon.db.CustomSpells2={rule}; addon.ShowGUI(); local gui=addon.GUIFrame
    addon.SwitchTestMode=function() error('source edit must not restart preview') end
    local only=controlByText(h,'options:general:only-show-my-auras')
    local function source(own)
        tooltipContains(gui.PreviewButton,'\n'..L[own and 'options:preview:source-own' or 'options:preview:source-rules']..'\n')
        tooltipContains(gui.PreviewButton,L[own and 'options:preview:source-rules' or 'options:preview:source-own'],false)
    end
    source(false); only:Click(); source(true); only:Click(); source(false)
    gui.CategoryButtons[7]:Click(); local saved=copyEntry(addon.db); local before=h.refreshes
    selectRule(h,rule); equalEntry(addon.db,saved); eq(h.refreshes,before); source(false)
    local tri=findObject(h,function(o)
        return o.GetTriState and o.textEntries and o.textEntries[2]==addon.ColorizeText(L['options:auras:enabled-state-mineonly'],0,1,1)
    end)
    local labels={addon.ColorizeText(L.Disabled,1,1,1),addon.ColorizeText(L['options:auras:enabled-state-mineonly'],0,1,1),
        addon.ColorizeText(L['options:auras:enabled-state-all'],0,1,0)}
    equalEntry(tri.textEntries,labels)
    eq(tri.LRDTooltipText,string.format(L['options:auras:enabled-state:tooltip'],unpack(labels)))
    -- ALL -> disabled -> MINE -> ALL uses the real legacy tri-state setter exactly once.
    local modes={addon.CONST_SPELL_MODE_DISABLED,addon.CONST_SPELL_MODE_MYAURAS,addon.CONST_SPELL_MODE_ALL}
    for i,mode in ipairs(modes) do
        local expected=copyEntry(addon.db); expected.CustomSpells2[1].enabledState=mode; before=h.refreshes
        tri:Click(); eq(tri:GetTriState(),i-1); eq(rule.enabledState,mode); eq(h.refreshes,before+1)
        equalEntry(addon.db,expected); source(mode==addon.CONST_SPELL_MODE_MYAURAS)
        before=h.refreshes; selectRule(h,rule); equalEntry(addon.db,expected); eq(h.refreshes,before)
    end
    gui.CategoryButtons[1]:Click(); only:Click(); source(true)
    gui.CategoryButtons[7]:Click(); saved=copyEntry(addon.db); before=h.refreshes; selectRule(h,rule)
    eq(tri:GetTriState(),2); eq(rule.enabledState,addon.CONST_SPELL_MODE_ALL)
    equalEntry(addon.db,saved); eq(h.refreshes,before); source(true)
    before=h.refreshes; tri:Click(); eq(rule.enabledState,addon.CONST_SPELL_MODE_DISABLED)
    eq(tri:GetTriState(),0); eq(group.OnlyShowMyAuras,true); eq(h.refreshes,before+1); source(true)
    for i,mode in ipairs({addon.CONST_SPELL_MODE_MYAURAS,addon.CONST_SPELL_MODE_ALL,addon.CONST_SPELL_MODE_DISABLED}) do
        local expected=copyEntry(addon.db); expected.CustomSpells2[1].enabledState=mode; before=h.refreshes
        tri:Click(); eq(tri:GetTriState(),i%3); eq(rule.enabledState,mode); eq(h.refreshes,before+1)
        equalEntry(addon.db,expected); source(true)
        before=h.refreshes; selectRule(h,rule); equalEntry(addon.db,expected); eq(h.refreshes,before)
    end
    gui.CategoryButtons[1]:Click(); only:Click(); source(false)
    gui.CategoryButtons[7]:Click(); before=h.refreshes; selectRule(h,rule)
    eq(rule.enabledState,addon.CONST_SPELL_MODE_DISABLED); eq(tri:GetTriState(),0); eq(h.refreshes,before); source(false)
    gui.CategoryButtons[1]:Click(); only:Click(); groupMenu(h)._menu.entries[2].select(2); source(false)
    groupMenu(h)._menu.entries[1].select(1); source(true)
    eq(rule.enabledState,addon.CONST_SPELL_MODE_DISABLED); eq(group.AlwaysShowMyAuras,false)
    context(h,1,1,nil,nil)
end)

test('gui_own_only_profile_export_and_import_submission_preserve_raw_booleans', function()
    local h=previewHarness(); local addon=h.addon; local L=localeTable(h); local encode,decode=serialization(h)
    addon.db.IconGroups[2]=addon.GetIconGroupDefaultOptions('Second Group'); addon.ShowGUI()
    local only=controlByText(h,'options:general:only-show-my-auras'); local submitted,calls=nil,0
    -- Capture only GUI submission, not core validation, commit, migration or live filtering.
    addon.ImportProfile=function(profile) calls=calls+1; submitted=profile; return true end
    for _,value in ipairs({true,false}) do
        if only:GetChecked()~=value then only:Click() end
        local saved=copyEntry(addon.db); local before=h.refreshes
        controlByText(h,'options:general:export-profile'):Click()
        local editor=findObject(h,function(o)
            return o.GetHeaderText and o:IsVisible() and o:GetHeaderText()==L['options:general:export-profile']
        end)
        local exported=decode(editor:GetText()); equalEntry(exported,saved)
        eq(type(exported.IconGroups[1].OnlyShowMyAuras),'boolean'); eq(exported.IconGroups[1].OnlyShowMyAuras,value)
        eq(type(exported.IconGroups[2].OnlyShowMyAuras),'boolean'); eq(exported.IconGroups[2].OnlyShowMyAuras,false)
        eq(exported.IconGroups[1].AlwaysShowMyAuras,false); eq(editor.ApplyButton:IsShown(),false)
        equalEntry(addon.db,saved); eq(h.refreshes,before)
        controlByText(h,'options:general:import-profile'):Click(); editor.EditBox:Insert(encode(exported))
        local previous=calls; editor.ApplyButton:Click(); eq(calls,previous+1); equalEntry(submitted,saved)
        eq(type(submitted.IconGroups[1].OnlyShowMyAuras),'boolean'); eq(submitted.IconGroups[1].OnlyShowMyAuras,value)
        -- Successful GUI submission invokes OnIconGroupChanged's existing refresh once.
        equalEntry(addon.db,saved); eq(h.refreshes,before+1)
    end
end)

local borderMenuName='NAurasForever.GUI.Border.dropdownBorderType'

local function borderControls(h)
    local menu=assert(h.env[borderMenuName])
    local path=findObject(h,function(o) return o._kind=='EditBox' and o._parent==menu end)
    local thickness=findObject(h,function(o) return o.slider and o.editbox and o._parent==menu end)
    return menu,path,thickness
end

local function borderVisibility(h,mode)
    local menu,path,thickness=borderControls(h)
    eq(menu:IsVisible(),true)
    eq(path:IsShown(),mode==h.addon.BORDER_TYPE_CUSTOM)
    eq(thickness:IsShown(),mode==h.addon.BORDER_TYPE_BUILTIN)
    eq(path:IsVisible(),mode==h.addon.BORDER_TYPE_CUSTOM)
    eq(thickness:IsVisible(),mode==h.addon.BORDER_TYPE_BUILTIN)
end

test('gui_blizzard_border_legacy_three_entries_current_group_exact_refresh', function()
    local h=previewHarness(); local addon=h.addon; local L=localeTable(h)
    eq(addon.BORDER_TYPE_BUILTIN,1); eq(addon.BORDER_TYPE_CUSTOM,2)
    eq(addon.BORDER_TYPE_DISABLED,3); eq(addon.BORDER_TYPE_BLIZZARD,4)
    eq(addon.db.IconGroups[1].BorderType,1)
    addon.db.IconGroups[2]=addon.GetIconGroupDefaultOptions('Second Group')
    local rule=completeRule(addon); rule.customBorderSize=2.5; rule.iconSizeWidth=31.5
    addon.db.CustomSpells2={rule}
    for i,group in ipairs(addon.db.IconGroups) do
        group.BorderFilePath='Interface\\Icons\\Stored'..i; group.BorderThickness=i+1
    end
    addon.ShowGUI(); local gui=addon.GUIFrame; gui.CategoryButtons[6]:Click()
    addon.SwitchTestMode=function() error('border edit must not restart preview') end
    for _,index in ipairs({1,2}) do
        if index==2 then groupMenu(h)._menu.entries[2].select(2) end
        for _,mode in ipairs({4,1,2,4}) do
            local menu=borderControls(h); local saved=copyEntry(addon.db); local before=h.refreshes
            h.env.UIDropDownMenu_Initialize(menu,menu.initialize)
            eq(#menu._items,3); local seen={}; local chosen
            local keys={[1]='BUILTIN',[2]='CUSTOM',[4]='BLIZZARD'}
            for _,item in ipairs(menu._items) do
                assert(keys[item.value] and not seen[item.value],'unexpected/duplicate border enum')
                seen[item.value]=true; eq(item.text,L['options:borders:BORDER_TYPE_'..keys[item.value]])
                eq(item.checked,item.value==saved.IconGroups[index].BorderType)
                eq(type(item.func),'function'); if item.value==mode then chosen=item end
            end
            assert(seen[1] and seen[2] and seen[4]); eq(seen[3],nil)
            assert(menu._items[1]~=menu._items[2] and menu._items[2]~=menu._items[3])
            equalEntry(addon.db,saved); eq(h.refreshes,before)
            auraMenuButton(h,assert(chosen)):Click()
            saved.IconGroups[index].BorderType=mode; equalEntry(addon.db,saved)
            eq(h.refreshes,before+1); eq(h.env[menu:GetName()..'Text']:GetText(),chosen.text)
            borderVisibility(h,mode); context(h,index,6,nil,nil)
            tooltipContains(gui.PreviewButton,'样式来源：增益与 5 种减益边框颜色')
            tooltipContains(gui.PreviewButton,L['options:preview:source-rules'])
        end
    end
end)

test('gui_blizzard_border_pages_reopen_group_profile_readback_visibility', function()
    local h=previewHarness(); local addon=h.addon
    addon.db.IconGroups[2]=addon.GetIconGroupDefaultOptions('Second Group')
    addon.ShowGUI(); local gui=addon.GUIFrame; gui.CategoryButtons[6]:Click()
    local menu,path,thickness=borderControls(h)
    addon.SwitchTestMode=function() error('border lifecycle must not restart preview') end
    for _,mode in ipairs({2,4,1,4}) do
        selectLegacy(h,borderMenuName,mode); local saved=copyEntry(addon.db); local before=h.refreshes
        for _,page in ipairs({1,2,7,9,12}) do
            gui.CategoryButtons[page]:Click(); eq(menu:IsVisible(),false)
            eq(path:IsVisible(),false); eq(thickness:IsVisible(),false)
            gui.CategoryButtons[6]:Click(); borderVisibility(h,mode)
        end
        for _=1,2 do
            gui:Hide(); eq(path:IsVisible(),false); eq(thickness:IsVisible(),false)
            addon.ShowGUI(); borderVisibility(h,mode)
        end
        equalEntry(addon.db,saved); eq(h.refreshes,before)
    end
    addon.db.IconGroups[1].BorderType=4; addon.db.IconGroups[2].BorderType=2
    addon.OnIconGroupChanged(); local saved=copyEntry(addon.db)
    for _,index in ipairs({2,1,2,1}) do
        groupMenu(h)._menu.entries[index].select(index)
        borderVisibility(h,addon.db.IconGroups[index].BorderType)
        local expected=localeTable(h)
        eq(h.env[menu:GetName()..'Text']:GetText(),expected['options:borders:BORDER_TYPE_'..(index==1 and 'BLIZZARD' or 'CUSTOM')])
        equalEntry(addon.db,saved)
    end
    for _,mode in ipairs({1,2,4,3,4}) do
        local profile={CustomSpells2={},IconGroups={addon.GetIconGroupDefaultOptions('Replacement')}}
        profile.IconGroups[1].BorderType=mode; profile.IconGroups[1].BorderFilePath='Interface\\Icons\\Retained'
        profile.IconGroups[1].BorderThickness=3; addon.db=profile; saved=copyEntry(profile)
        addon.GuiOnProfileChanged(); borderVisibility(h,mode); context(h,1,6,nil,nil)
        local keys={[1]='BUILTIN',[2]='CUSTOM',[4]='BLIZZARD'}
        eq(h.env[menu:GetName()..'Text']:GetText(),keys[mode] and localeTable(h)['options:borders:BORDER_TYPE_'..keys[mode]] or '')
        gui:Hide(); addon.ShowGUI(); borderVisibility(h,mode); equalEntry(profile,saved)
        local current,currentPath,currentThickness=borderControls(h)
        eq(current,menu); eq(currentPath,path); eq(currentThickness,thickness)
    end
end)

test('gui_blizzard_border_readonly_handlers_do_not_refresh_or_write', function()
    local h=previewHarness(); local addon=h.addon; addon.ShowGUI(); addon.GUIFrame.CategoryButtons[6]:Click()
    local menu,path,thickness=borderControls(h); local handlers={}
    for _,fn in ipairs(addon.GUIFrame.OnDBChangedHandlers) do
        local i=1
        while true do
            local name,value=debug.getupvalue(fn,i); if not name then break end
            if value==menu or value==path or value==thickness then handlers[#handlers+1]=fn; break end
            i=i+1
        end
    end
    eq(#handlers,3)
    local group=addon.db.IconGroups[1]; group.BorderType=4
    group.BorderFilePath='Interface\\Icons\\Readback'; group.BorderThickness=3
    local saved=copyEntry(addon.db); local before=h.refreshes
    for _,fn in ipairs(handlers) do fn() end
    equalEntry(addon.db,saved); eq(h.refreshes,before)
    eq(path:GetText(),group.BorderFilePath); eq(thickness.slider:GetValue(),3)
    borderVisibility(h,4)
end)

local function fractionalBorderReadback(profileChange)
    local h=previewHarness(); local addon=h.addon
    addon.db.IconGroups[2]=addon.GetIconGroupDefaultOptions('Second Group')
    addon.ShowGUI(); addon.GUIFrame.CategoryButtons[6]:Click()
    local rule=completeRule(addon); rule.iconSizeWidth=31.5; rule.iconSizeHeight=48.25; rule.customBorderSize=2.5
    local group=addon.GetIconGroupDefaultOptions('Fractional'); group.BorderType=4
    group.BorderThickness=2.5; group.BorderFilePath='Interface\\Icons\\Fractional'
    if profileChange then
        addon.db={CustomSpells2={rule},IconGroups={group}}
    else
        addon.db.CustomSpells2={rule}; addon.db.IconGroups[2]=group
    end
    local saved=copyEntry(addon.db)
    if profileChange then addon.GuiOnProfileChanged() else groupMenu(h)._menu.entries[2].select(2) end
    equalEntry(addon.db,saved); eq(group.BorderThickness,2.5)
    borderVisibility(h,4)
end

test('gui_blizzard_border_fractional_group_readback_preserves_records', function() fractionalBorderReadback(false) end)
test('gui_blizzard_border_fractional_profile_readback_preserves_records', function() fractionalBorderReadback(true) end)

test('gui_blizzard_border_locale_new_keys_coverage_and_tooltip_boundaries', function()
    local default,translated=captureLocale('enUS'),captureLocale('zhCN')
    validateDictionary(default,translated)
    for _,key in ipairs({'options:borders:BORDER_TYPE_BLIZZARD','options:borders:blizzard:tooltip'}) do
        assert(type(rawget(default,key))=='string' and default[key]:find('%S'))
        assert(chinese(rawget(translated,key))); eq(formatTokens(default[key]),formatTokens(translated[key]))
        local missing=copyEntry(translated); missing[key]=nil; setmetatable(missing,{__index=default})
        rejects(function() validateDictionary(default,missing) end,'missing explicit translation: '..key)
        local english=copyEntry(translated); english[key]=default[key]
        rejects(function() validateDictionary(default,english) end,'non-Chinese translation: '..key)
        local placeholder=copyEntry(translated); placeholder[key]=translated[key]..' %s'
        rejects(function() validateDictionary(default,placeholder) end,'expected')
    end
    eq(translated['options:borders:BORDER_TYPE_BLIZZARD'],'暴雪默认')
    local h=guiHarness(); h.addon.ShowGUI(); h.addon.GUIFrame.CategoryButtons[6]:Click()
    local menu=borderControls(h); local L=localeTable(h)
    eq(menu.LRDTooltipText,L['options:borders:blizzard:tooltip'])
    local fragments=h.locale=='zhCN' and {'姓名板光环','边框材质','着色','粗细由材质决定','随图标尺寸缩放',
        '自定义路径','不生效','规则','覆盖仍优先','只改变边框','不改变图标裁切','不添加暴雪的圆角遮罩'}
        or {'nameplate aura border artwork','tinted','thickness is fixed','scales with icon size','custom paths',
        'do not apply','Per-rule border overrides still take priority','only the border','not icon cropping','native rounded mask'}
    for _,fragment in ipairs(fragments) do tooltipContains(menu,fragment) end
end)

test('gui_blizzard_border_rule_tristate_open_color_nil_guards_and_source', function()
    local h=previewHarness(); local addon=h.addon; local L=localeTable(h)
    addon.db.IconGroups[1].BorderType=4
    local rule=completeRule(addon); rule.customBorderPath='Interface\\Icons\\Rule'
    rule.overrideSize=true; rule.iconSizeWidth=31.5; rule.iconSizeHeight=48.25
    rule.customBorderSize=2.5; rule.customBorderColor={.2,.4,.6,.8}
    addon.db.CustomSpells2={rule}; addon.ShowGUI(); local gui=addon.GUIFrame
    addon.SwitchTestMode=function() error('rule override must not restart preview') end
    for _,mode in ipairs({3,1,2}) do
        rule.customBorderType=mode; gui.CategoryButtons[7]:Click()
        local saved=copyEntry(addon.db); local before=h.refreshes
        selectRule(h,rule); equalEntry(addon.db,saved); eq(h.refreshes,before)
        local tri=findObject(h,function(o)
            return o.GetTriState and o.textEntries and o.textEntries[1]==addon.ColorizeText(L['options:spells:icon-border:disabled'],1,1,1)
        end)
        equalEntry(tri.textEntries,{addon.ColorizeText(L['options:spells:icon-border:disabled'],1,1,1),
            addon.ColorizeText(L['options:spells:icon-border:builtin'],0,1,1),addon.ColorizeText(L['options:spells:icon-border:custom'],0,1,0)})
        eq(tri:GetTriState(),mode==3 and 0 or mode)
        local area=tri._parent
        local path=findObject(h,function(o) return o._kind=='EditBox' and o._parent==area end)
        local thickness=findObject(h,function(o) return o.slider and o.editbox and o._parent==area end)
        local color=findObject(h,function(o) return o.colorSwatch and o._parent==area end)
        eq(path:IsVisible(),mode==2); eq(thickness:IsVisible(),mode==1); eq(color:IsVisible(),mode~=3)
        if mode~=3 then equalEntry({color:GetColor()},rule.customBorderColor) end
        tooltipContains(gui.PreviewButton,'边框覆盖组设置',mode~=3)
        tooltipContains(gui.PreviewButton,L['options:preview:source-rules'])
        context(h,1,7,rule,118)
        backButton(h):Click(); gui.CategoryButtons[6]:Click()
        selectLegacy(h,borderMenuName,1); selectLegacy(h,borderMenuName,4)
        gui.CategoryButtons[7]:Click(); before=h.refreshes; selectRule(h,rule)
        equalEntry(addon.db,saved); eq(h.refreshes,before); eq(tri:GetTriState(),mode==3 and 0 or mode)
        -- Existing guarded setters must remain safe with a missing entry/list/db.
        backButton(h):Click(); before=h.refreshes; local persisted=copyEntry(rule)
        for _,missing in ipairs({'entry','list','db'}) do
            if missing=='entry' then addon.db.CustomSpells2[1]=nil
            elseif missing=='list' then addon.db.CustomSpells2=nil else addon.db=nil end
            path:SetText('missing '..missing); thickness.slider:SetValue(thickness.slider:GetValue()+.1)
            eq(h.refreshes,before); equalEntry(rule,persisted)
        end
        addon.db=saved; rule=addon.db.CustomSpells2[1]
    end
    -- Integer values isolate real tri-state clicks from existing fractional synchronization.
    rule.customBorderSize=2; rule.customBorderPath=''; rule.customBorderType=3
    gui.CategoryButtons[7]:Click(); selectRule(h,rule)
    local tri=findObject(h,function(o) return o.GetTriState and o.textEntries and o.textEntries[1]==addon.ColorizeText(L['options:spells:icon-border:disabled'],1,1,1) end)
    for _,mode in ipairs({1,2,3,1,2,3}) do
        local expected=copyEntry(addon.db); expected.CustomSpells2[1].customBorderType=mode
        local path=findObject(h,function(o) return o._kind=='EditBox' and o._parent==tri._parent end)
        local thickness=findObject(h,function(o) return o.slider and o.editbox and o._parent==tri._parent end)
        local expectedRefresh=1+(mode==1 and thickness.slider:GetValue()~=rule.customBorderSize and 1 or 0)
            +(mode==2 and path:GetText()~=rule.customBorderPath and 1 or 0)
        local before=h.refreshes; tri:Click(); equalEntry(addon.db,expected)
        eq(tri:GetTriState(),mode==3 and 0 or mode); assert(rule.customBorderType~=4)
        eq(h.refreshes,before+expectedRefresh); eq(addon.db.IconGroups[1].BorderType,4)
    end
end)

test('gui_blizzard_border_profile_real_export_validation_and_invalid_enum_unchanged', function()
    local h=previewHarness(); local addon=h.addon; local L=localeTable(h); local encode,decode=serialization(h)
    addon.db.DBVersion=addon.DB_SCHEMA_VERSION
    addon.db.DefaultSpellsLastSetImported=#addon.DefaultSpells2
    addon.db.IconGroups[2]=addon.GetIconGroupDefaultOptions('Second Group')
    addon.db.IconGroups[1].BorderType=4; addon.db.IconGroups[1].BorderThickness=3
    addon.db.IconGroups[1].BorderFilePath='Interface\\Icons\\Keep'
    addon.db.CustomSpells2={completeRule(addon)}; addon.ShowGUI()
    local original=addon.db; local saved=copyEntry(original); local before=h.refreshes
    controlByText(h,'options:general:export-profile'):Click()
    local editor=findObject(h,function(o) return o.GetHeaderText and o:IsVisible() and o:GetHeaderText()==L['options:general:export-profile'] end)
    local exported=decode(editor:GetText()); equalEntry(exported,saved); eq(exported.IconGroups[1].BorderType,4)
    local input=decode(encode(exported)); local raw=copyEntry(input)
    local prepared=assert(addon.PrepareProfileImport(input)); assert(prepared~=input)
    eq(prepared.IconGroups[1].BorderType,4); eq(prepared.IconGroups[1].BorderFilePath,raw.IconGroups[1].BorderFilePath)
    eq(prepared.IconGroups[1].BorderThickness,3); eq(prepared.CustomSpells2[1].customBorderType,3)
    equalEntry(input,raw); eq(addon.db,original); equalEntry(original,saved); eq(h.refreshes,before)
    for _,kind in ipairs({'group','rule'}) do
        local invalid=copyEntry(exported)
        if kind=='group' then invalid.IconGroups[1].BorderType=5 else invalid.CustomSpells2[1].customBorderType=4 end
        local invalidSaved=copyEntry(invalid); local candidate,failure=addon.PrepareProfileImport(invalid)
        eq(candidate,nil); eq(type(failure),'string'); assert(failure:find('边框类型',1,true))
        equalEntry(invalid,invalidSaved); eq(addon.db,original); equalEntry(original,saved); eq(h.refreshes,before)
    end
end)

if selected=='--list' then for _,t in ipairs(tests) do print(t.name) end; return end
local passed,failed,total=0,0,0
for _,t in ipairs(tests) do
    if not selected or selected==t.name then
        total=total+1
        local ok,err=xpcall(t.run,debug.traceback)
        if ok then passed=passed+1; print('PASS '..t.name) else failed=failed+1; print('FAIL '..t.name..'\n'..err) end
    end
end
assert(total>0,'unknown test case')
print(string.format('RESULT: %d passed, %d failed, %d total',passed,failed,total))
os.exit(failed==0 and 0 or 1)
