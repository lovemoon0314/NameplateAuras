"""Read-only package tests for the Forever JSON runtime contract.

Run with python3 -B tests/test_package.py -v from the addon directory.
Lua is compiled, never executed. These tests do not establish game behavior.
"""

import json
import re
import shutil
import subprocess
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
from unittest.mock import patch


PACKAGE = Path(__file__).resolve().parents[1]
WOW_SOURCE = PACKAGE.parent / "wow-ui-source"
LEGACY = PACKAGE.parent / "NameplateAuras"


def read_utf8(path):
    data = path.read_bytes()
    if data.startswith(b"\xef\xbb\xbf"):
        raise ValueError("UTF-8 BOM: {}".format(path))
    return data.decode("utf-8", errors="strict")


def bounded_path(root, parent, reference):
    """Resolve Windows-style addon paths, including symlinks, inside root."""
    reference = reference.replace("\\", "/")
    if not reference or reference.startswith("/") or re.match(r"^[A-Za-z]:", reference):
        raise ValueError("Invalid relative path: {!r}".format(reference))
    root = root.resolve()
    result = (parent / reference).resolve()
    try:
        result.relative_to(root)
    except ValueError:
        raise ValueError("Path escapes {}: {!r}".format(root, reference)) from None
    return result


def parse_toc(text):
    metadata, entries = {}, []
    for number, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if line.startswith("##"):
            key, separator, value = line[2:].partition(":")
            if separator:
                metadata.setdefault(key.strip().lower(), []).append(value.strip())
        elif line and not line.startswith("#"):
            # Blizzard TOCs may specify per-file loading environment attributes.
            entry = re.sub(r"\s+\[[^\]]*\]\s*$", "", line)
            entries.append((number, entry))
    return metadata, entries


def metadata_values(metadata, *keys):
    return [value for key in keys for value in metadata.get(key.lower(), [])]


def names(values):
    return [name for value in values for name in re.split(r"[,\s]+", value) if name]


class LoadGraph:
    """TOC/XML reachability only; do not discover unloaded Lua by globbing."""

    def __init__(self, root, toc):
        self.root = root.resolve()
        self.files = []
        self.texts = {}
        self.inline = []
        self.errors = []
        self._active = set()
        self._seen = set()
        self._visit(bounded_path(self.root, self.root, toc))

    def _reference(self, owner, reference):
        try:
            self._visit(bounded_path(self.root, owner.parent, reference))
        except ValueError as error:
            self.errors.append("{}: {}".format(owner, error))

    def _visit(self, path):
        if path in self._active:
            self.errors.append("Load cycle: {}".format(path))
            return
        if path in self._seen:
            return
        self._seen.add(path)
        self.files.append(path)
        try:
            text = read_utf8(path)
        except (OSError, UnicodeError, ValueError) as error:
            self.errors.append("{}: {}".format(path, error))
            return
        self.texts[path] = text
        self._active.add(path)
        try:
            if path.suffix.lower() == ".toc":
                for _, reference in parse_toc(text)[1]:
                    self._reference(path, reference)
            elif path.suffix.lower() == ".xml":
                tree = ET.fromstring(text)
                self._xml(path, tree)
            elif path.suffix.lower() != ".lua":
                self.errors.append("Unsupported loaded file: {}".format(path))
        except ET.ParseError as error:
            self.errors.append("{}: {}".format(path, error))
        finally:
            self._active.remove(path)

    def _xml(self, path, element, in_scripts=False):
        tag = element.tag.rsplit("}", 1)[-1]
        reference = element.get("file")
        if tag in ("Include", "Script") and reference is not None:
            self._reference(path, reference)
        elif tag == "Include":
            self.errors.append("Include without file: {}".format(path))
        elif tag == "Script" or in_scripts:
            body = element.text or ""
            if body.strip():
                # XML callbacks are function bodies, not top-level Lua chunks.
                code = "function(self, ...)\n{}\nend".format(body) if in_scripts else body
                if in_scripts:
                    code = "local callback = " + code
                self.inline.append(("{} <{}>".format(path, tag), code))
        for child in element:
            self._xml(path, child, tag == "Scripts")


def lua_tokens(text):
    """Small lexer for static policy checks; luac is the syntax authority.

    Comments are discarded; string literals remain separate from identifiers.
    This is deliberately not a Lua evaluator or semantic analyzer.
    """
    tokens = []
    index = 0
    while index < len(text):
        if text[index].isspace():
            index += 1
            continue
        comment = text.startswith("--", index)
        start = index + 2 if comment else index
        long_open = re.match(r"\[(=*)\[", text[start:])
        if long_open:
            close = "]" + long_open.group(1) + "]"
            body_start = start + len(long_open.group())
            end = text.find(close, body_start)
            if end < 0:
                raise ValueError("Unclosed Lua long string/comment")
            if not comment:
                tokens.append(("string", text[body_start:end]))
            index = end + len(close)
        elif comment:
            end = text.find("\n", index)
            index = len(text) if end < 0 else end + 1
        elif text[index] in "\"'":
            quote = text[index]
            index += 1
            value = []
            while index < len(text) and text[index] != quote:
                if text[index] == "\\":
                    index += 1
                    if index == len(text):
                        raise ValueError("Unclosed Lua string escape")
                    # Namespace/path checks need quotes and backslashes decoded.
                    value.append({"n": "\n", "r": "\r", "t": "\t"}.get(text[index], text[index]))
                else:
                    value.append(text[index])
                index += 1
            if index == len(text):
                raise ValueError("Unclosed Lua string")
            tokens.append(("string", "".join(value)))
            index += 1
        else:
            identifier = re.match(r"[A-Za-z_][A-Za-z_0-9]*", text[index:])
            value = identifier.group() if identifier else text[index]
            tokens.append(("identifier" if identifier else "symbol", value))
            index += len(value)
    return tokens


class PackageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.contract = json.loads(read_utf8(PACKAGE / "tests" / "runtime_contract.json"))
        cls.package_contract = cls.contract["package"]
        cls.toc = bounded_path(PACKAGE, PACKAGE, cls.package_contract["toc"])
        cls.metadata, cls.entries = parse_toc(read_utf8(cls.toc))
        cls.graph = LoadGraph(PACKAGE, cls.package_contract["toc"])

    def test_loaded_files_exist_utf8_without_bom(self):
        self.assertTrue(self.entries, "Empty TOC load list")
        self.assertFalse(self.graph.errors, "\n".join(self.graph.errors))
        self.assertIn(PACKAGE / "src" / "NameplateAuras.lua", self.graph.files)
        for path in self.graph.files:
            with self.subTest(file=str(path.relative_to(PACKAGE))):
                self.assertTrue(path.is_file())
                read_utf8(path)

    def test_lua51_syntax_loaded_graph_only(self):
        compiler = shutil.which("luac5.1")
        self.assertIsNotNone(compiler, "INCONCLUSIVE: luac5.1 is required on PATH")
        result = subprocess.run([compiler, "-v"], capture_output=True, text=True, timeout=15)
        version = result.stdout + result.stderr
        self.assertEqual(result.returncode, 0, version)
        self.assertRegex(version, r"\bLua 5\.1(?:\.|\s|$)", "Not a real Lua 5.1 compiler")
        print("\nLua compiler: {} | {}".format(compiler, version.strip()), flush=True)
        self.assertFalse(self.graph.errors, "\n".join(self.graph.errors))
        lua_files = [path for path in self.graph.files if path.suffix.lower() == ".lua"]
        self.assertTrue(lua_files, "No loaded Lua files")
        for path in lua_files:
            with self.subTest(file=str(path.relative_to(PACKAGE))):
                result = subprocess.run([compiler, "-p", str(path)], capture_output=True, text=True, timeout=30)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        for location, body in self.graph.inline:
            with self.subTest(inline=location):
                result = subprocess.run([compiler, "-p", "-"], input=body, capture_output=True, text=True, timeout=30)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        print("Compiled {} loaded Lua files, {} inline XML scripts (no execution).".format(
            len(lua_files), len(self.graph.inline)), flush=True)

    def test_runtime_version_interface_and_git_branch(self):
        source = self.contract["source"]
        version = read_utf8(WOW_SOURCE / "version.txt").strip()
        self.assertRegex(version, r"^\d+\.\d+\.\d+\.\d+$")
        major, minor, patch_version, _ = map(int, version.split("."))
        interface = major * 10000 + minor * 100 + patch_version
        self.assertEqual(version, source["version"])
        self.assertEqual(interface, source["interface"])
        self.assertEqual(names(metadata_values(self.metadata, "interface")), [str(interface)])
        result = subprocess.run(["git", "-C", str(WOW_SOURCE), "branch", "--show-current"],
                                capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(source["branch"], "forever")
        self.assertEqual(result.stdout.strip(), source["branch"], "Wrong branch or detached HEAD")

    def test_blizzard_dependency_and_no_plater(self):
        required = names(metadata_values(self.metadata, "dependencies", "dependency", "deps", "dep", "requireddeps"))
        optional = names(metadata_values(self.metadata, "optionaldeps", "optionaldependencies"))
        self.assertIn("Blizzard_AuraContainer", required)
        self.assertIs(self.package_contract["plater_dependency"], False)
        self.assertFalse(any("plater" in name.lower() for name in required + optional))
        source_root = WOW_SOURCE / "Interface" / "AddOns"
        dependency = source_root / "Blizzard_AuraContainer" / "Blizzard_AuraContainer.toc"
        metadata, entries = parse_toc(read_utf8(dependency))
        self.assertEqual(metadata_values(metadata, "usesecureenvironment"), ["1"])
        self.assertTrue(entries, "Empty Blizzard dependency TOC")
        for filename in ("Blizzard_CustomAuraContainer.xml", "Blizzard_CustomAuraButton.xml"):
            with self.subTest(template=filename):
                self.assertIn(filename, [entry for _, entry in entries])
                path = bounded_path(source_root, dependency.parent, filename)
                tree = ET.fromstring(read_utf8(path))
                expected = filename.replace("Blizzard_", "").replace(".xml", "Template")
                templates = [element for element in tree.iter() if element.get("name") == expected]
                self.assertEqual(len(templates), 1)
                inbound = [element for element in templates[0].iter()
                           if element.get("key") == expected.replace("Template", "InboundMixin")]
                self.assertEqual(len(inbound), 1)
                self.assertEqual(inbound[0].get("secureDelegates"), "true")
                self.assertEqual(inbound[0].get("source"), "secure")
        for path, text in self.graph.texts.items():
            if path.suffix.lower() == ".lua" and "libs" not in path.relative_to(PACKAGE).parts:
                with self.subTest(file=str(path)):
                    self.assertFalse(any(kind == "identifier" and value.lower() == "plater"
                                         for kind, value in lua_tokens(text)), "Plater runtime coupling")

    def test_every_api_source_evidence_range_and_literal_token(self):
        evidence = self.contract["source_evidence"]
        self.assertTrue(evidence, "Empty API source evidence")
        root = WOW_SOURCE / "Interface" / "AddOns"
        for item in evidence:
            with self.subTest(file=item.get("file"), start=item.get("start"), end=item.get("end")):
                path = bounded_path(root, root, item["file"])
                lines = read_utf8(path).splitlines()
                start, end = item["start"], item["end"]
                self.assertIs(type(start), int)
                self.assertIs(type(end), int)
                self.assertGreaterEqual(start, 1)
                self.assertGreaterEqual(end, start)
                self.assertLessEqual(end, len(lines), "Evidence range exceeds source")
                excerpt = "\n".join(lines[start - 1:end])
                self.assertTrue(item["tokens"], "Evidence needs literal tokens")
                for token in item["tokens"]:
                    with self.subTest(token=token):
                        self.assertIsInstance(token, str)
                        self.assertTrue(token)
                        # Literal containment: true is not normalized to 1.
                        self.assertIn(token, excerpt)

    def test_core_forbidden_events_and_apis(self):
        path = PACKAGE / "src" / "NameplateAuras.lua"
        self.assertIn(path, self.graph.texts)
        tokens = lua_tokens(read_utf8(path))
        forbidden = {"C_UnitAuras", "UnitGUID", "GetCurrentEventInfo", "loadstring", "setfenv"}
        for kind, value in tokens:
            if kind == "identifier":
                with self.subTest(api=value):
                    # Reject references too: this also catches local aliases.
                    self.assertNotIn(value, forbidden)
            elif kind == "string":
                with self.subTest(event=value):
                    # Handler tables may register through a loop rather than a literal call.
                    self.assertNotIn(value, {"UNIT_AURA", "COMBAT_LOG", "COMBAT_LOG_EVENT_UNFILTERED"})
                    self.assertNotIn(value, forbidden, "Indirect forbidden API lookup")

    def test_saved_variables_slash_locale_and_media_isolation(self):
        contract = self.package_contract
        self.assertEqual(PACKAGE.name, contract["folder"])
        legacy_meta, _ = parse_toc(read_utf8(LEGACY / "NameplateAuras.toc"))
        old_sv = names(metadata_values(legacy_meta, "savedvariables", "savedvariablespercharacter"))
        new_sv = names(metadata_values(self.metadata, "savedvariables", "savedvariablespercharacter"))
        self.assertEqual(new_sv, [contract["saved_variables"]])
        self.assertFalse(set(old_sv) & set(new_sv))
        self.assertEqual(contract["locale"], contract["folder"])
        self.assertNotEqual(contract["slash"].lower(), "/nauras")
        slash_values, locale_values, sv_values, media_paths = [], [], [], []
        for path, text in self.graph.texts.items():
            relative = path.relative_to(PACKAGE)
            if path.suffix.lower() != ".lua" or "libs" in relative.parts:
                continue
            tokens = lua_tokens(text)
            values = [value for _, value in tokens]
            with self.subTest(file=str(relative)):
                for index, (kind, value) in enumerate(tokens):
                    if kind == "identifier":
                        self.assertNotIn(value, old_sv)
                        if value.startswith("SLASH_"):
                            self.assertTrue(value.startswith("SLASH_NAMEPLATEAURASFOREVER"), value)
                            if values[index + 1:index + 2] == ["="]:
                                self.assertEqual(tokens[index + 2][0], "string")
                                slash_values.append(values[index + 2])
                        if value == "SlashCmdList":
                            if values[index + 1:index + 2] == ["."]:
                                self.assertEqual(values[index + 2], "NAMEPLATEAURASFOREVER")
                            elif values[index + 1:index + 2] == ["["]:
                                self.assertEqual(values[index + 2], "NAMEPLATEAURASFOREVER")
                    elif kind == "string":
                        self.assertNotIn(value, old_sv)
                        normalized = value.replace("\\", "/")
                        old_path = "Interface/AddOns/NameplateAuras/"
                        if old_path in normalized:
                            # Only an explicit database gsub old -> new path migration is exempt.
                            prefix = values[max(0, index - 3):index]
                            following = tokens[index + 1:index + 3]
                            self.assertEqual(relative.as_posix(), "src/database.lua")
                            self.assertEqual(prefix, [":", "gsub", "("])
                            self.assertEqual(following[0], ("symbol", ","))
                            self.assertEqual(following[1][0], "string")
                            self.assertIn("Interface/AddOns/{}/".format(contract["folder"]),
                                          following[1][1].replace("\\", "/"))
                        if value.startswith("NAuras_"):
                            self.assertEqual(relative.as_posix(), "src/database.lua",
                                             "Legacy media name outside migration")
                            # A comparison may read an old font key, but assignments must use the new key.
                            self.assertEqual(values[max(0, index - 2):index], ["=", "="])
                            self.assertIn(("string", value.replace("NAuras_", "NAurasForever_", 1)),
                                          tokens[index + 1:index + 12])
                        media_prefix = "Interface/AddOns/{}/media/".format(contract["folder"])
                        if normalized.startswith(media_prefix):
                            media_paths.append(normalized[len(media_prefix):])
                    if (value in ("NewLocale", "GetLocale")
                            and values[max(0, index - 1):index] == [":"]
                            and values[index + 1:index + 2] == ["("]):
                        argument = tokens[index + 2]
                        if argument[0] == "string":
                            self.assertEqual(argument[1], contract["locale"])
                            locale_values.append(argument[1])
                        else:
                            self.assertEqual(argument, ("identifier", "addonName"))
                            self.assertRegex(text, r"local\s+addonName\s*,\s*addonTable\s*=\s*\.\.\.")
                    if value == "New" and values[max(0, index - 1):index] == [":"]:
                        if values[index + 1:index + 2] == ["("] and tokens[index + 2][0] == "string":
                            sv_values.append(values[index + 2])
        self.assertIn(contract["slash"], slash_values)
        self.assertTrue(all(value.lower() not in ("/nauras", "/nameplateauras") for value in slash_values))
        self.assertTrue(locale_values, "No locale namespace registrations")
        self.assertIn(contract["saved_variables"], sv_values)
        self.assertTrue(media_paths, "No independent media references")
        icon = metadata_values(self.metadata, "icontexture")
        self.assertEqual(len(icon), 1)
        self.assertTrue(icon[0].replace("\\", "/").startswith(
            "Interface/AddOns/{}/media/".format(contract["folder"])))
        for reference in media_paths + [icon[0].replace("\\", "/").split("/media/", 1)[1]]:
            with self.subTest(media=reference):
                path = bounded_path(PACKAGE, PACKAGE / "media", reference)
                self.assertTrue(path.is_file() or (not path.suffix and path.with_suffix(".tga").is_file()),
                                "Missing media: {}".format(path))

    def test_copied_libraries_and_media_byte_identical(self):
        for directory in ("libs", "media"):
            copied = PACKAGE / directory
            original = LEGACY / directory
            self.assertTrue(copied.is_dir())
            files = sorted(path for path in copied.rglob("*") if path.is_file())
            self.assertTrue(files, "No copied {} files".format(directory))
            for path in files:
                relative = path.relative_to(copied)
                with self.subTest(directory=directory, file=str(relative)):
                    bounded_path(PACKAGE, copied, relative.as_posix())
                    baseline = bounded_path(LEGACY, original, relative.as_posix())
                    self.assertTrue(baseline.is_file(), "No original copy: {}".format(baseline))
                    if relative.as_posix() == "LibRedDropdown-1.0/LibRedDropdown-1.0.lua":
                        expected = read_utf8(baseline).replace('local LIB_NAME = "LibRedDropdown-1.0";', 'local LIB_NAME = "LibRedDropdown-Forever-1.0";')
                        expected = expected.replace("LibStub:NewLibrary(LIB_NAME, 23)", "LibStub:NewLibrary(LIB_NAME, 25)")
                        expected = expected.replace("colorButton.texture:SetTexture(1, 1, 1);", "colorButton.texture:SetColorTexture(1, 1, 1, 1);")
                        expected = expected.replace(
                            "local BUTTON_COLOR_NORMAL = {0.38, 0, 0, 1};",
                            "local BUTTON_COLOR_NORMAL = {0.38, 0, 0, 1};\r\n\r\n"
                            "local function LocalizedText(key, fallback)\r\n"
                            "\treturn lib.Localization and lib.Localization[key] or fallback;\r\nend",
                        )
                        expected = expected.replace('searchBoxText:SetText("Click to search...");',
                            'searchBoxText:SetText(LocalizedText("options:common:search", "Click to search..."));')
                        expected = expected.replace('ColorizeText("Spell ID: " .. spellID, 91/255, 165/255, 249/255)',
                            'ColorizeText(string_format(LocalizedText("options:common:spell-id", "Spell ID: %s"), tostring(spellID)), 91/255, 165/255, 249/255)')
                        expected = expected.replace('lib.SetTooltip(self, string_format("R: %d, G: %d, B: %d, A: %d", r*255, g*255, b*255, a*255));',
                            'lib.SetTooltip(self, string_format(LocalizedText("options:common:rgba", "R: %d, G: %d, B: %d, A: %d"), r*255, g*255, b*255, a*255));')
                        expected = expected.replace('frame.Header.text:SetText("LuaEditor");',
                            'frame.Header.text:SetText(LocalizedText("options:common:editor", "LuaEditor"));')
                        self.assertEqual(read_utf8(path), expected, "Unexpected private dropdown changes")
                    else:
                        self.assertEqual(path.read_bytes(), baseline.read_bytes(), "Copied bytes changed")
            if directory == "media":
                self.assertEqual({path.relative_to(copied) for path in files},
                                 {path.relative_to(original) for path in original.rglob("*") if path.is_file()})
        # Unloaded AceComm/DRList copies are still compared above, not syntax checked.


class ParserTests(unittest.TestCase):
    """Exercise parser boundaries in memory, without temporary/helper files."""

    def test_toc_comments_metadata_and_environment_attributes(self):
        metadata, entries = parse_toc("## Interface: 16001\n# ignored\n\nfile.xml [LoadIntoEnvironment global]\n")
        self.assertEqual(metadata, {"interface": ["16001"]})
        self.assertEqual(entries, [(4, "file.xml")])

    def test_nested_xml_relative_scripts_and_unloaded_exclusion(self):
        root = PACKAGE
        fixture = {
            root / "fixture.toc": "nested/root.xml\n",
            root / "nested/root.xml": '<Ui xmlns="urn:wow"><Include file="child/inner.xml"/></Ui>',
            root / "nested/child/inner.xml": '<Ui><Script file="../loaded.lua"/><Scripts><OnLoad>return self</OnLoad></Scripts></Ui>',
            root / "nested/loaded.lua": "local value = true",
            root / "unloaded_test.lua": "this is not Lua",
        }
        with patch(__name__ + ".read_utf8", side_effect=lambda path: fixture[path]):
            graph = LoadGraph(root, "fixture.toc")
        self.assertFalse(graph.errors)
        self.assertEqual(graph.files, list(fixture)[:-1])
        self.assertEqual(len(graph.inline), 1)
        self.assertIn("return self", graph.inline[0][1])

    def test_root_escape_absolute_paths_and_load_cycles(self):
        for reference in ("../outside.lua", "..\\outside.lua", "/tmp/outside.lua", "C:\\outside.lua"):
            with self.subTest(reference=reference), self.assertRaises(ValueError):
                bounded_path(PACKAGE, PACKAGE, reference)
        fixture = {
            PACKAGE / "fixture.toc": "cycle.xml\n../outside.lua\n",
            PACKAGE / "cycle.xml": '<Ui><Include file="cycle.xml"/></Ui>',
        }
        with patch(__name__ + ".read_utf8", side_effect=lambda path: fixture[path]):
            graph = LoadGraph(PACKAGE, "fixture.toc")
        self.assertEqual(len(graph.errors), 2)
        self.assertTrue(any("Load cycle" in error for error in graph.errors))
        self.assertTrue(any("escapes" in error for error in graph.errors))

    def test_lexer_distinguishes_client_locale_query_and_library_lookup(self):
        tokens = lua_tokens('local locale = GetLocale(); local text = lib:GetLocale("NameplateAuras_Forever")')
        values = [value for _, value in tokens]
        queries = [index for index, value in enumerate(values) if value == "GetLocale"]
        self.assertEqual(len(queries), 2)
        self.assertEqual(values[queries[0] - 1], "=")
        self.assertEqual(tokens[queries[0] + 2], ("symbol", ")"))
        self.assertEqual(values[queries[1] - 1], ":")
        self.assertEqual(tokens[queries[1] + 2], ("string", "NameplateAuras_Forever"))

    def test_lexer_comments_long_strings_and_literal_true(self):
        tokens = lua_tokens('-- UnitGUID()\n--[=[loadstring()]=]\nlocal s = [=[true]=]; f("a\\\\b", true)')
        self.assertNotIn(("identifier", "UnitGUID"), tokens)
        self.assertNotIn(("identifier", "loadstring"), tokens)
        self.assertIn(("string", "true"), tokens)
        self.assertIn(("identifier", "true"), tokens)
        self.assertIn(("string", "a\\b"), tokens)


if __name__ == "__main__":
    unittest.main(verbosity=2)
